<?php
// Check if cURL is able to access the CA file
echo "cURL CA info: " . phpinfo();
?>
