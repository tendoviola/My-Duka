<?php
// password_change.php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
require_login();

$user = current_user();
$forced = (int)$user['must_change_password'] === 1;
$back = match ($user['role_name']) {
    'admin'    => 'admin/dashboard.php',
    'owner'    => 'owner/dashboard.php',
    'employee' => 'employee/dashboard.php',
    default    => 'index.php',
};

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $current = post('current_password');
    $new     = post('new_password');
    $confirm = post('confirm_password');

    if (!$forced) {
        if ($current === '') {
            $errors[] = 'Current password is required.';
        } elseif (!password_verify($current, $user['password_hash'])) {
            $errors[] = 'Current password is incorrect.';
        }
    }
    if (strlen($new) < PASSWORD_MIN_LEN) {
        $errors[] = 'New password must be at least ' . PASSWORD_MIN_LEN . ' characters.';
    }
    if ($new !== $confirm) {
        $errors[] = 'New passwords do not match.';
    }

    if (!$errors) {
        $hash = password_hash($new, PASSWORD_DEFAULT);
        db()->prepare(
            "UPDATE users SET password_hash = ?, must_change_password = 0 WHERE id = ?"
        )->execute([$hash, $user['id']]);
        audit_log('user.password_changed', 'users', (int)$user['id']);

        unset($_SESSION['user_id']);
        $_SESSION['user_id'] = (int)$user['id'];

        flash('success', 'Password updated successfully.');
        redirect($back);
    }
}

$pageTitle = $forced ? 'Set a New Password' : 'Change Password';
require __DIR__ . '/includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  
  /* Center the card nicely within the dashboard content area */
  .settings-wrapper {
    min-height: calc(100vh - 140px);
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
    padding: 2rem 1rem;
    background-color: #f8fafc;
    border-radius: 16px;
  }

  .settings-card {
    background: #fff;
    width: 100%;
    max-width: 480px;
    border-radius: 16px;
    box-shadow: 0 10px 30px -10px rgba(15, 23, 42, 0.08);
    border: 1px solid #e2e8f0;
    overflow: hidden;
  }

  /* A clean accent line at the top of the card */
  .card-accent {
    height: 4px;
    background: linear-gradient(90deg, #2563eb, #1d4ed8);
    width: 100%;
  }

  .card-header {
    padding: 2rem 2rem 1.5rem;
    text-align: center;
    border-bottom: 1px solid #f1f5f9;
  }

  .card-icon {
    width: 48px; height: 48px;
    background: #eff6ff;
    color: #2563eb;
    border-radius: 12px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
    margin-bottom: 1rem;
  }

  .card-header h4 {
    font-weight: 800;
    font-size: 1.3rem;
    color: #0f172a;
    margin-bottom: 0.25rem;
    letter-spacing: -0.02em;
  }

  .card-header p {
    font-size: 0.85rem;
    color: #64748b;
    margin: 0;
  }

  .card-body { padding: 1.5rem 2rem 2rem; }

  /* Form Controls */
  .form-group { margin-bottom: 1.25rem; }
  .form-group label {
    display: block; font-size: 0.8rem; font-weight: 700; color: #334155; margin-bottom: 0.4rem;
  }

  .input-wrapper { position: relative; }
  .input-wrapper input {
    width: 100%;
    padding: 0.75rem 1rem;
    padding-right: 2.75rem;
    border-radius: 10px;
    border: 1px solid #cbd5e1;
    font-size: 0.95rem;
    font-weight: 500;
    color: #0f172a;
    background: #f8fafc;
    transition: all 0.2s;
  }
  .input-wrapper input:focus {
    outline: none; background: #fff; border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
  }
  .input-wrapper input.is-invalid { border-color: #ef4444; }

  .toggle-password {
    position: absolute; right: 0.75rem; top: 50%; transform: translateY(-50%);
    background: none; border: none; color: #94a3b8; cursor: pointer; padding: 0.25rem;
    font-size: 1rem; transition: color 0.2s;
  }
  .toggle-password:hover { color: #475569; }

  /* Strength Meter */
  .strength-track { height: 6px; background: #e2e8f0; border-radius: 10px; overflow: hidden; margin-top: 0.5rem; }
  .strength-fill { height: 100%; width: 0%; border-radius: 10px; transition: all 0.3s ease; }
  
  .strength-label { display: flex; justify-content: space-between; font-size: 0.7rem; font-weight: 700; margin-top: 0.3rem; color: #94a3b8; }

  /* Vertical Checklist */
  .requirements { list-style: none; padding: 0; margin: 1rem 0 0 0; }
  .requirements li {
    font-size: 0.8rem; font-weight: 600; color: #94a3b8; margin-bottom: 0.4rem;
    display: flex; align-items: center; gap: 0.5rem; transition: all 0.2s ease;
  }
  .requirements li i { font-size: 0.9rem; color: #cbd5e1; transition: all 0.2s ease; }
  
  .requirements li.met { color: #16a34a; }
  .requirements li.met i { color: #16a34a; transform: scale(1.1); }

  /* Alerts */
  .alert-custom {
    background: #fef2f2; color: #991b1b; border: 1px solid #fecaca;
    border-radius: 10px; padding: 0.75rem 1rem; font-size: 0.85rem; font-weight: 600;
    margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.5rem;
  }
  .alert-info-custom {
    background: #eff6ff; color: #1e40af; border: 1px solid #bfdbfe;
    border-radius: 10px; padding: 0.85rem 1rem; font-size: 0.85rem; font-weight: 500;
    margin-bottom: 1.5rem; display: flex; align-items: flex-start; gap: 0.75rem;
  }

  /* Submit Button */
  .btn-submit {
    width: 100%; background: #2563eb; color: #fff; border: none;
    border-radius: 10px; padding: 0.85rem; font-weight: 700; font-size: 1rem;
    transition: all 0.2s; margin-top: 1rem; display: flex; justify-content: center; align-items: center; gap: 0.5rem;
  }
  .btn-submit:hover:not(:disabled) {
    background: #1d4ed8; transform: translateY(-1px); box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
  }
  .btn-submit:disabled { background: #cbd5e1; cursor: not-allowed; }
</style>

<div class="settings-wrapper">
  <div class="settings-card">
    <div class="card-accent"></div>
    
    <div class="card-header">
      <div class="card-icon">
        <i class="fa-solid fa-lock"></i>
      </div>
      <h4><?= e($pageTitle) ?></h4>
      <p>Ensure your account stays secure.</p>
    </div>

    <div class="card-body">
      <?php if ($forced): ?>
        <div class="alert-info-custom">
          <i class="fa-solid fa-circle-info mt-1 fs-6"></i>
          <div>
            <strong>First Time Login</strong><br>
            Your account was created by your employer. Please choose a personal password.
          </div>
        </div>
      <?php endif; ?>

      <?php foreach ($errors as $er): ?>
        <div class="alert-custom">
          <i class="fa-solid fa-circle-exclamation fs-5"></i> <?= e($er) ?>
        </div>
      <?php endforeach; ?>

      <form method="post" id="passwordForm">
        <?= csrf_field() ?>
        
        <?php if (!$forced): ?>
          <div class="form-group">
            <label for="current_password">Current Password</label>
            <div class="input-wrapper">
              <input type="password" name="current_password" id="current_password" required placeholder="Enter current password">
              <button type="button" class="toggle-password" data-target="current_password">
                <i class="fa-regular fa-eye"></i>
              </button>
            </div>
          </div>
        <?php endif; ?>

        <div class="form-group">
          <label for="new_password">New Password</label>
          <div class="input-wrapper">
            <input type="password" name="new_password" id="new_password" minlength="<?= PASSWORD_MIN_LEN ?>" required placeholder="Enter new password">
            <button type="button" class="toggle-password" data-target="new_password">
              <i class="fa-regular fa-eye"></i>
            </button>
          </div>
          
          <!-- Progress Bar -->
          <div class="strength-track">
            <div class="strength-fill" id="strengthFill"></div>
          </div>
          <div class="strength-label">
            <span id="strengthText">Enter a password</span>
            <span id="strengthPercent"></span>
          </div>

          <!-- Checklist -->
          <ul class="requirements" id="reqList">
            <li id="req-length"><i class="fa-solid fa-circle"></i> At least <?= PASSWORD_MIN_LEN ?> characters</li>
            <li id="req-upper"><i class="fa-solid fa-circle"></i> Contains upper & lowercase letters</li>
            <li id="req-number"><i class="fa-solid fa-circle"></i> Contains at least one number</li>
            <li id="req-match"><i class="fa-solid fa-circle"></i> Passwords match</li>
          </ul>
        </div>

        <div class="form-group">
          <label for="confirm_password">Confirm New Password</label>
          <div class="input-wrapper">
            <input type="password" name="confirm_password" id="confirm_password" required placeholder="Confirm new password">
            <button type="button" class="toggle-password" data-target="confirm_password">
              <i class="fa-regular fa-eye"></i>
            </button>
          </div>
        </div>

        <button type="submit" class="btn-submit" id="submitBtn" disabled>
          <span>Update Password</span>
          <i class="fa-solid fa-arrow-right"></i>
        </button>
      </form>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  // Toggle Password Visibility
  document.querySelectorAll('.toggle-password').forEach(btn => {
    btn.addEventListener('click', function() {
      const input = document.getElementById(this.dataset.target);
      const icon = this.querySelector('i');
      
      if (input.type === 'password') {
        input.type = 'text';
        icon.classList.replace('fa-eye', 'fa-eye-slash');
        this.style.color = '#2563eb';
      } else {
        input.type = 'password';
        icon.classList.replace('fa-eye-slash', 'fa-eye');
        this.style.color = '#94a3b8';
      }
    });
  });

  // Live Validation Logic
  const newPass = document.getElementById('new_password');
  const confirmPass = document.getElementById('confirm_password');
  const currentPass = document.getElementById('current_password'); // May be null if forced
  const submitBtn = document.getElementById('submitBtn');
  const isForced = <?= $forced ? 'true' : 'false' ?>;

  const strengthFill = document.getElementById('strengthFill');
  const strengthText = document.getElementById('strengthText');
  const strengthPercent = document.getElementById('strengthPercent');

  const reqLength = document.getElementById('req-length');
  const reqUpper = document.getElementById('req-upper');
  const reqNumber = document.getElementById('req-number');
  const reqMatch = document.getElementById('req-match');

  function validate() {
    const val = newPass.value;
    const confirmVal = confirmPass.value;
    
    // Checks
    const isLength = val.length >= <?= PASSWORD_MIN_LEN ?>;
    const isUpper = /[A-Z]/.test(val) && /[a-z]/.test(val);
    const isNumber = /[0-9]/.test(val);
    const isMatch = val.length > 0 && val === confirmVal;

    // Update UI Checklist
    reqLength.classList.toggle('met', isLength);
    reqUpper.classList.toggle('met', isUpper);
    reqNumber.classList.toggle('met', isNumber);
    reqMatch.classList.toggle('met', isMatch);

    // Update Icons
    [reqLength, reqUpper, reqNumber, reqMatch].forEach(li => {
      const icon = li.querySelector('i');
      if (li.classList.contains('met')) {
        icon.classList.replace('fa-circle', 'fa-circle-check');
      } else {
        icon.classList.replace('fa-circle-check', 'fa-circle');
      }
    });

    // Strength Meter Logic
    let score = 0;
    if (val.length > 0) score += 25;
    if (isLength) score += 25;
    if (isUpper) score += 25;
    if (isNumber) score += 25;

    strengthFill.style.width = score + '%';
    strengthPercent.textContent = score + '%';

    if (val.length === 0) {
      strengthText.textContent = 'Enter a password';
      strengthFill.style.background = '#e2e8f0';
      strengthPercent.style.color = '#94a3b8';
    } else if (score < 75) {
      strengthText.textContent = 'Weak Password';
      strengthFill.style.background = '#ef4444';
      strengthPercent.style.color = '#ef4444';
    } else if (score < 100) {
      strengthText.textContent = 'Good Password';
      strengthFill.style.background = '#f59e0b';
      strengthPercent.style.color = '#f59e0b';
    } else {
      strengthText.textContent = 'Strong Password';
      strengthFill.style.background = '#16a34a';
      strengthPercent.style.color = '#16a34a';
    }

    // Button Gate
    let allValid = isLength && isUpper && isNumber && isMatch;
    if (!isForced && currentPass) {
      allValid = allValid && currentPass.value.length > 0;
    }
    
    submitBtn.disabled = !allValid;
  }

  newPass.addEventListener('input', validate);
  confirmPass.addEventListener('input', validate);
  if (currentPass) currentPass.addEventListener('input', validate);
});
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>