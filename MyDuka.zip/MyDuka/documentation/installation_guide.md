# RetailPro Installation Guide

## Requirements

- PHP 8.2 or later (with `pdo_mysql`, `fileinfo`, `mbstring` extensions)
- MySQL 8.0+ or MariaDB 10.6+
- Apache (with `mod_rewrite` optional — not required) or Nginx
- Composer **not** required (no dependencies)

## Local install (XAMPP / WAMP / MAMP)

1. **Copy the project** into your web root:
   - XAMPP: `C:\xampp\htdocs\retailpro`
   - WAMP:  `C:\wamp64\www\retailpro`
   - MAMP:  `/Applications/MAMP/htdocs/retailpro`

2. **Create the database**

   Open phpMyAdmin → New → name it `retailpro` → Create.
   Select the database → Import → choose `database/retailpro.sql` → Go.

   Or via CLI:

   ```bash
   mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS retailpro CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
   mysql -u root -p retailpro < database/retailpro.sql