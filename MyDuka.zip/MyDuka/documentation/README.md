# RetailPro — Retail Inventory & Business Management System

A complete, ready-to-deploy inventory & POS platform for Ugandan retail shops,
supermarkets, and wholesale businesses. Built with vanilla PHP 8, MySQL 8,
Bootstrap 5, and Chart.js — no frameworks.

## Features

- Three role tiers: **Admin**, **Owner**, **Employee** (least-privilege by default)
- Multi-business / multi-branch isolation with per-branch inventory
- Weighted-average cost tracking with immutable sale/cost snapshots
- Server-authoritative POS (browser cannot tamper with prices or totals)
- Stock ledger — every change writes an append-only `stock_movements` row
- Purchase → receive → pay-supplier workflow with drafts
- Sales → cancel → return workflows (full audit, no hard deletes)
- Stock transfers between branches with proper in-transit semantics
- Expense tracking with categories
- Reports & CSV export — sales, profit, inventory, low stock, branch comparison
- Notification bell for low-stock / out-of-stock events
- Immutable audit log (business-scoped for owners, system-wide for admins)
- Forced password change for owner-created employees

## Tech stack

| Layer | Technology |
|-------|------------|
| Frontend | HTML5, CSS3, Bootstrap 5.3, Chart.js 4, Font Awesome 6 |
| Backend | PHP 8.2+, PDO, PHP sessions |
| Database | MySQL 8.0 / MariaDB 10.6+, InnoDB, utf8mb4 |

## Quick start

See `documentation/installation_guide.md`.

## Project structure

retailpro/
├── index.php # role-based redirect
├── login.php
├── register.php # public owner self-registration
├── logout.php
├── password_change.php # forced for owner-created employees
├── receipt.php
├── notifications.php
├── config/
│ ├── app.php
│ └── database.php
├── includes/
│ ├── auth.php
│ ├── csrf.php (implicit — helpers live in functions.php)
│ ├── functions.php
│ ├── header.php
│ ├── sidebar.php
│ ├── footer.php
│ ├── stock.php # weighted-average + ledger engine
│ └── uploads.php
├── admin/
│ ├── dashboard.php
│ ├── businesses.php
│ ├── users.php
│ ├── branches.php
│ ├── categories.php
│ ├── activity.php
│ └── settings.php
├── owner/
│ ├── dashboard.php
│ ├── products.php
│ ├── categories.php
│ ├── inventory.php
│ ├── purchases.php
│ ├── sales.php
│ ├── pos.php
│ ├── suppliers.php
│ ├── customers.php
│ ├── expenses.php
│ ├── employees.php
│ ├── branches.php
│ ├── transfers.php
│ ├── reports.php
│ ├── activity.php
│ └── settings.php
├── employee/
│ ├── dashboard.php
│ ├── pos.php
│ ├── products.php
│ ├── sales_history.php
│ ├── stock_info.php
│ └── profile.php
├── assets/
│ ├── css/
│ │ ├── style.css
│ │ └── dashboard.css
│ ├── js/
│ │ ├── main.js
│ │ ├── dashboard.js
│ │ ├── pos.js
│ │ ├── products.js
│ │ └── purchases.js
│ └── uploads/
├── database/
│ ├── retailpro.sql
│ └── seed.sql
└── documentation/
├── README.md
└── installation_guide.md


## Account creation rules

| Role | Created by |
|------|-----------|
| **Admin** | Direct DB insert (`database/retailpro.sql`) — no public signup path |
| **Owner** | `register.php` (public self-registration) |
| **Employee** | `owner/employees.php` (only way) |

## Default demo admin

- Email: `admin@retailpro.local`
- Password: `Password123!` — **change immediately after first login.**

## License

Proprietary. All rights reserved.