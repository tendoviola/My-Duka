<?php
// admin/dashboard.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

$pdo = db();

$businesses       = (int)$pdo->query("SELECT COUNT(*) FROM businesses")->fetchColumn();
$activeBusinesses = (int)$pdo->query("SELECT COUNT(*) FROM businesses WHERE status='active'")->fetchColumn();
$suspended        = (int)$pdo->query("SELECT COUNT(*) FROM businesses WHERE status='suspended'")->fetchColumn();
$pending          = (int)$pdo->query("SELECT COUNT(*) FROM businesses WHERE status='pending'")->fetchColumn();
$usersTotal       = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$branchesTotal    = (int)$pdo->query("SELECT COUNT(*) FROM branches WHERE status='active'")->fetchColumn();

$recentBusinesses = $pdo->query(
    "SELECT b.id, b.name, b.status, b.created_at, u.full_name AS owner
     FROM businesses b LEFT JOIN users u ON u.id = b.owner_id
     ORDER BY b.created_at DESC LIMIT 5"
)->fetchAll();

$recentActivity = $pdo->query(
    "SELECT a.action, a.created_at, u.full_name, a.business_id
     FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
     ORDER BY a.created_at DESC LIMIT 8"
)->fetchAll();

$pageTitle = 'Admin Dashboard';
$breadcrumbs = ['Admin' => null, 'Dashboard' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .dashboard-canvas {
    background-color: #f8fafc;
    padding: 2rem 2rem 3rem;
    margin: -1.5rem;
    min-height: calc(100vh - 72px);
    font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
  }

  /* Hero */
  .hero-banner {
    background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%);
    border-radius: 20px;
    padding: 2.5rem 2rem;
    position: relative;
    overflow: hidden;
    box-shadow: 0 10px 30px -10px rgba(15, 23, 42, 0.5);
    margin-bottom: 2rem;
  }
  .hero-banner::before {
    content: '';
    position: absolute; inset: 0;
    background-image: linear-gradient(rgba(255, 255, 255, 0.05) 1px, transparent 1px),
                      linear-gradient(90deg, rgba(255, 255, 255, 0.05) 1px, transparent 1px);
    background-size: 20px 20px;
    mask-image: linear-gradient(to bottom, black, transparent);
    -webkit-mask-image: linear-gradient(to bottom, black, transparent);
  }
  .hero-banner::after {
    content: '';
    position: absolute; top: -50%; right: -10%;
    width: 400px; height: 400px;
    background: radial-gradient(circle, rgba(59, 130, 246, 0.4) 0%, transparent 70%);
    filter: blur(40px);
    border-radius: 50%;
  }
  .hero-banner h2 { font-weight: 800; letter-spacing: -0.02em; color: #fff; margin-bottom: 0.5rem; }
  .hero-banner p { color: #94a3b8; font-weight: 500; margin-bottom: 0; }
  .hero-badge {
    display: inline-block; background: #2563eb; color: #fff;
    font-size: 0.75rem; font-weight: 800; letter-spacing: 0.05em;
    padding: 0.4rem 0.85rem; border-radius: 8px; margin-bottom: 1rem; text-transform: uppercase;
  }

  /* KPI Cards */
  .kpi-card {
    background: #fff; border: 1px solid #e2e8f0; border-radius: 16px;
    padding: 1.5rem; height: 100%; position: relative; overflow: hidden;
    box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); transition: transform 0.2s ease;
  }
  .kpi-card:hover { transform: translateY(-2px); }
  .kpi-label { font-size: 0.8rem; font-weight: 600; color: #64748b; margin-bottom: 0.5rem; }
  .kpi-value { font-size: 1.75rem; font-weight: 800; color: #0f172a; line-height: 1.1; letter-spacing: -0.03em; margin-bottom: 0.25rem; }
  .kpi-sub { font-size: 0.75rem; font-weight: 500; color: #94a3b8; }
  .kpi-blob { position: absolute; top: -20px; right: -20px; width: 80px; height: 80px; border-radius: 50%; opacity: 0.1; }
  .kpi-blob.blue { background: #3b82f6; }
  .kpi-blob.green { background: #10b981; }
  .kpi-blob.purple { background: #8b5cf6; }
  .kpi-blob.orange { background: #f59e0b; }

  /* Panels */
  .dash-panel {
    background: #ffffff; border-radius: 16px; border: 1px solid #e2e8f0;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.02); height: 100%; display: flex; flex-direction: column;
  }
  .dash-panel-head {
    padding: 1.25rem 1.5rem; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #f1f5f9;
  }
  .dash-panel-title { font-size: 1rem; font-weight: 700; color: #0f172a; margin: 0; }

  /* Elegant Lists */
  .elegant-list { list-style: none; margin: 0; padding: 0; flex: 1; }
  .elegant-item { display: flex; align-items: center; padding: 1rem 1.5rem; border-bottom: 1px solid #f8fafc; }
  .elegant-item:last-child { border-bottom: none; }
  .elegant-icon { width: 40px; height: 40px; border-radius: 10px; background: #f1f5f9; color: #475569; display: flex; align-items: center; justify-content: center; margin-right: 1rem; flex-shrink: 0; font-size: 1rem; }
  .elegant-icon.blue { background: #eff6ff; color: #2563eb; }
  .elegant-content { flex: 1; min-width: 0; }
  .elegant-title { font-size: 0.875rem; font-weight: 700; color: #0f172a; margin-bottom: 0.15rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .elegant-sub { font-size: 0.75rem; font-weight: 500; color: #64748b; }
  .elegant-value { font-weight: 800; font-size: 0.9rem; color: #0f172a; text-align: right; }

  /* Timeline */
  .timeline { position: relative; padding-left: 1.5rem; margin: 0; list-style: none; padding-top: 1rem; padding-bottom: 1rem;}
  .timeline::before { content: ''; position: absolute; top: 1rem; bottom: 1rem; left: 1.5rem; width: 2px; background: #e2e8f0; }
  .timeline-item { position: relative; margin-bottom: 1.25rem; padding-left: 1.5rem; }
  .timeline-item:last-child { margin-bottom: 0; }
  .timeline-marker { position: absolute; left: -5px; top: 0.25rem; width: 12px; height: 12px; border-radius: 50%; background: #fff; border: 2px solid #3b82f6; }
  .timeline-title { font-weight: 700; font-size: 0.85rem; color: #0f172a; margin: 0; }
  .timeline-date { font-size: 0.7rem; font-weight: 600; color: #94a3b8; }
</style>

<div class="dashboard-canvas">
  
  <!-- HERO BANNER -->
  <div class="hero-banner d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-4">
    <div style="position: relative; z-index: 2;">
      <span class="hero-badge">Platform Administration</span>
      <h2>Welcome back, Admin.</h2>
      <p>Here is a bird's-eye view of your entire retail ecosystem.</p>
    </div>
  </div>

  <!-- KPI CARDS -->
  <div class="row g-4 mb-4">
    <div class="col-md-6 col-xl-3">
      <div class="kpi-card">
        <div class="kpi-blob blue"></div>
        <div class="kpi-label">Registered Businesses</div>
        <div class="kpi-value"><?= $businesses ?></div>
        <div class="kpi-sub"><?= $activeBusinesses ?> currently active</div>
      </div>
    </div>
    <div class="col-md-6 col-xl-3">
      <div class="kpi-card">
        <div class="kpi-blob green"></div>
        <div class="kpi-label">Total Users</div>
        <div class="kpi-value"><?= $usersTotal ?></div>
        <div class="kpi-sub">Across all roles</div>
      </div>
    </div>
    <div class="col-md-6 col-xl-3">
      <div class="kpi-card">
        <div class="kpi-blob purple"></div>
        <div class="kpi-label">Active Branches</div>
        <div class="kpi-value"><?= $branchesTotal ?></div>
        <div class="kpi-sub">Serving customers</div>
      </div>
    </div>
    <div class="col-md-6 col-xl-3">
      <div class="kpi-card">
        <div class="kpi-blob orange"></div>
        <div class="kpi-label">Pending / Suspended</div>
        <div class="kpi-value"><?= $pending ?> <span style="font-size:1rem; color:#94a3b8;">/ <?= $suspended ?></span></div>
        <div class="kpi-sub">Requires attention</div>
      </div>
    </div>
  </div>

  <!-- MAIN LISTS -->
  <div class="row g-4">
    
    <!-- Recent Businesses -->
    <div class="col-lg-6">
      <div class="dash-panel">
        <div class="dash-panel-head">
          <h3 class="dash-panel-title">Recent Registrations</h3>
          <a href="<?= e(APP_URL) ?>/admin/businesses.php" class="text-decoration-none small fw-bold" style="color: var(--rp-blue);">Manage All</a>
        </div>
        <ul class="elegant-list">
          <?php if (!$recentBusinesses): ?>
            <li class="p-4 text-center text-muted">No businesses registered yet.</li>
          <?php else: foreach ($recentBusinesses as $b): ?>
            <li class="elegant-item">
              <div class="elegant-icon <?= $b['status']==='active' ? 'blue' : '' ?>">
                <i class="fa-solid fa-building"></i>
              </div>
              <div class="elegant-content">
                <div class="elegant-title"><?= e($b['name']) ?></div>
                <div class="elegant-sub">Owner: <?= e($b['owner'] ?? '—') ?></div>
              </div>
              <div class="text-end">
                <div class="elegant-value" style="font-size: 0.75rem; color: #64748b; font-weight:600;"><?= human_date($b['created_at']) ?></div>
                <span class="badge <?= $b['status']==='active' ? 'bg-success-subtle text-success' : ($b['status']==='suspended' ? 'bg-danger-subtle text-danger' : 'bg-warning-subtle text-warning') ?> mt-1">
                  <?= e(ucfirst($b['status'])) ?>
                </span>
              </div>
            </li>
          <?php endforeach; endif; ?>
        </ul>
      </div>
    </div>

    <!-- System Activity Timeline -->
    <div class="col-lg-6">
      <div class="dash-panel">
        <div class="dash-panel-head">
          <h3 class="dash-panel-title">System Activity</h3>
        </div>
        <div style="padding: 0 1.5rem;">
          <ul class="timeline">
            <?php if (!$recentActivity): ?>
              <li class="text-center py-4 text-muted small">No activity recorded yet.</li>
            <?php else: foreach ($recentActivity as $a): ?>
              <li class="timeline-item">
                <div class="timeline-marker"></div>
                <div class="timeline-content">
                  <div class="d-flex justify-content-between align-items-start mb-1">
                    <h6 class="timeline-title"><?= e($a['action']) ?></h6>
                    <span class="timeline-date"><?= human_datetime($a['created_at']) ?></span>
                  </div>
                  <div class="text-muted small">
                    User: <span class="fw-bold text-dark"><?= e($a['full_name'] ?? 'System') ?></span>
                  </div>
                </div>
              </li>
            <?php endforeach; endif; ?>
          </ul>
        </div>
      </div>
    </div>

  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>