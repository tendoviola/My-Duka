<?php
// admin/businesses.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post('action');
    $id = post_int('id');

    if (in_array($action, ['activate','suspend'], true)) {
        $new = $action === 'activate' ? 'active' : 'suspended';
        $pdo->prepare("UPDATE businesses SET status = ? WHERE id = ?")->execute([$new, $id]);
        audit_log('admin.business.'.$action, 'businesses', $id);
        flash('success', 'Business status updated.');
        redirect('businesses.php');
    }
}

$search = get('q');
$status = get('status', '');
$where = "1=1";
$params = [];
if (in_array($status, ['active','suspended','pending'], true)) {
    $where .= " AND b.status = ?";
    $params[] = $status;
}
if ($search !== '') {
    $where .= " AND (b.name LIKE ? OR b.email LIKE ?)";
    $params[] = "%{$search}%"; $params[] = "%{$search}%";
}

$stmt = $pdo->prepare(
    "SELECT b.*, u.full_name AS owner_name, u.email AS owner_email,
            (SELECT COUNT(*) FROM branches br WHERE br.business_id = b.id) AS branch_count,
            (SELECT COUNT(*) FROM users usr WHERE usr.business_id = b.id AND usr.role_id = 3) AS employee_count
     FROM businesses b LEFT JOIN users u ON u.id = b.owner_id
     WHERE {$where} ORDER BY b.created_at DESC"
);
$stmt->execute($params);
$businesses = $stmt->fetchAll();

$pageTitle = 'Businesses';
$breadcrumbs = ['Admin' => null, 'Businesses' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; }
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }

  .filter-form { display: flex; gap: 0.5rem; background: #fff; padding: 0.35rem; border-radius: 10px; border: 1px solid #cbd5e1; margin-bottom: 1rem; flex-wrap: wrap; align-items: center; }
  .filter-form input, .filter-form select { border: none; border-radius: 6px; padding: 0.35rem 0.5rem; font-size: 0.8rem; font-weight: 500; color: #0f172a; background: transparent; }
  .filter-form input:focus, .filter-form select:focus { outline: none; background: #f8fafc; }

  .list-panel { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
  .list-item { display: flex; align-items: center; padding: 1.25rem 1.5rem; border-bottom: 1px solid #f1f5f9; transition: background 0.15s; flex-wrap: wrap; gap: 1rem; }
  .list-item:last-child { border-bottom: none; }
  .list-item:hover { background: #f8fafc; }
  
  .list-icon { width: 44px; height: 44px; border-radius: 12px; background: #eff6ff; color: #2563eb; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0; }
  .list-content { flex: 1; min-width: 200px; }
  .list-title { font-weight: 700; font-size: 0.95rem; color: #0f172a; margin-bottom: 0.15rem; }
  .list-sub { font-size: 0.75rem; color: #64748b; font-weight: 500; display: flex; gap: 0.75rem; align-items: center; }
  
  .list-meta { display: flex; gap: 1.5rem; text-align: right; align-items: center; }
  .meta-item { text-align: right; }
  .meta-val { font-weight: 700; font-size: 0.9rem; color: #0f172a; }
  .meta-lbl { font-size: 0.65rem; color: #94a3b8; font-weight: 600; text-transform: uppercase; }
  
  .list-actions { display: flex; gap: 0.5rem; align-items: center; }
  .btn-action { padding: 0.35rem 0.75rem; font-size: 0.75rem; font-weight: 600; border-radius: 6px; border: 1px solid #cbd5e1; background: #fff; color: #475569; transition: all 0.15s; text-decoration: none; display: inline-flex; align-items: center; gap: 0.25rem; }
  .btn-action:hover { background: #f1f5f9; color: #0f172a; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>Registered Businesses</h1>
      <p>View and manage all businesses on the platform.</p>
    </div>
  </div>

  <form class="filter-form" method="get">
    <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search name or email...">
    <select name="status" onchange="this.form.submit()">
      <option value="">All statuses</option>
      <option value="active" <?= $status==='active' ? 'selected':'' ?>>Active</option>
      <option value="suspended" <?= $status==='suspended' ? 'selected':'' ?>>Suspended</option>
      <option value="pending" <?= $status==='pending' ? 'selected':'' ?>>Pending</option>
    </select>
    <button type="submit" class="btn btn-sm btn-dark">Search</button>
  </form>

  <div class="list-panel">
    <?php if (!$businesses): ?>
      <div class="text-center py-5">
        <i class="fa-solid fa-building text-muted mb-3" style="font-size: 3rem; opacity: 0.3;"></i>
        <h5 class="fw-bold text-dark">No businesses found</h5>
        <p class="text-muted small">There are no businesses matching your filters.</p>
      </div>
    <?php else: foreach ($businesses as $b): ?>
      <?php $statusColors = ['active'=>'bg-success-subtle text-success', 'suspended'=>'bg-danger-subtle text-danger', 'pending'=>'bg-warning-subtle text-warning']; ?>
      <div class="list-item">
        <div class="list-icon"><i class="fa-solid fa-store"></i></div>
        
        <div class="list-content">
          <div class="list-title">
            <?= e($b['name']) ?>
            <span class="badge <?= $statusColors[$b['status']] ?> ms-2" style="font-size:0.6rem; letter-spacing:0.05em;"><?= strtoupper($b['status']) ?></span>
          </div>
          <div class="list-sub">
            <span><i class="fa-regular fa-envelope me-1"></i><?= e($b['email'] ?: 'No email') ?></span>
            <span class="text-muted">•</span>
            <span><i class="fa-solid fa-user me-1"></i><?= e($b['owner_name'] ?: 'Unknown Owner') ?></span>
          </div>
        </div>

        <div class="list-meta d-none d-md-flex">
          <div class="meta-item">
            <div class="meta-val"><?= (int)$b['branch_count'] ?></div>
            <div class="meta-lbl">Branches</div>
          </div>
          <div class="meta-item">
            <div class="meta-val"><?= (int)$b['employee_count'] ?></div>
            <div class="meta-lbl">Employees</div>
          </div>
        </div>

        <div class="list-actions">
          <?php if ($b['status'] === 'active'): ?>
            <form method="post" class="m-0" onsubmit="return confirm('Suspend this business? Its users will be locked out.');">
              <?= csrf_field() ?><input type="hidden" name="action" value="suspend"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
              <button type="submit" class="btn-action text-danger border-danger-subtle bg-danger-subtle">Suspend</button>
            </form>
          <?php else: ?>
            <form method="post" class="m-0">
              <?= csrf_field() ?><input type="hidden" name="action" value="activate"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
              <button type="submit" class="btn-action text-success border-success-subtle bg-success-subtle">Activate</button>
            </form>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>