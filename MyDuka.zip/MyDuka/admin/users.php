<?php
// admin/users.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (post('action') === 'toggle') {
        $id = post_int('id');
        $chk = $pdo->prepare("SELECT status FROM users WHERE id = ? AND role_id <> 1");
        $chk->execute([$id]);
        $cur = $chk->fetchColumn();
        if ($cur) {
            $new = $cur === 'active' ? 'inactive' : 'active';
            $pdo->prepare("UPDATE users SET status = ? WHERE id = ?")->execute([$new, $id]);
            audit_log('admin.user.toggle', 'users', $id, ['new_status' => $new]);
            flash('success', 'User status updated.');
        }
        redirect('users.php');
    }
}

$roleFilter = get('role', '');
$search = get('q');
$where = "1=1";
$params = [];
if (in_array($roleFilter, ['owner','employee','admin'], true)) {
    $where .= " AND r.name = ?";
    $params[] = $roleFilter;
}
if ($search !== '') {
    $where .= " AND (u.full_name LIKE ? OR u.email LIKE ?)";
    $params[] = "%{$search}%"; $params[] = "%{$search}%";
}

$stmt = $pdo->prepare(
    "SELECT u.*, r.name AS role_name, b.name AS business_name
     FROM users u JOIN roles r ON r.id = u.role_id
     LEFT JOIN businesses b ON b.id = u.business_id
     WHERE {$where} ORDER BY u.created_at DESC LIMIT 500"
);
$stmt->execute($params);
$users = $stmt->fetchAll();

$pageTitle = 'Users';
$breadcrumbs = ['Admin' => null, 'Users' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; }
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }

  .filter-form { display: flex; gap: 0.5rem; background: #fff; padding: 0.35rem; border-radius: 10px; border: 1px solid #cbd5e1; margin-bottom: 1rem; flex-wrap: wrap; align-items: center; }
  .filter-form input, .filter-form select { border: none; border-radius: 6px; padding: 0.35rem 0.5rem; font-size: 0.8rem; font-weight: 500; color: #0f172a; background: transparent; }
  .filter-form input:focus, .filter-form select:focus { outline: none; background: #f8fafc; }

  .list-panel { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
  .list-item { display: flex; align-items: center; padding: 1.25rem 1.5rem; border-bottom: 1px solid #f1f5f9; transition: background 0.15s; flex-wrap: wrap; gap: 1rem; }
  .list-item:last-child { border-bottom: none; }
  .list-item:hover { background: #f8fafc; }
  
  .avatar-initials {
    width: 44px; height: 44px; border-radius: 12px;
    display: flex; align-items: center; justify-content: center;
    font-weight: 800; font-size: 1rem; color: #fff;
    background: linear-gradient(135deg, #3b82f6, #2563eb);
    flex-shrink: 0;
  }
  
  .list-content { flex: 1; min-width: 200px; }
  .list-title { font-weight: 700; font-size: 0.95rem; color: #0f172a; margin-bottom: 0.15rem; }
  .list-sub { font-size: 0.75rem; color: #64748b; font-weight: 500; display: flex; gap: 0.75rem; align-items: center; }
  
  .list-meta { display: flex; gap: 1.5rem; text-align: right; align-items: center; }
  .meta-item { text-align: right; }
  .meta-val { font-weight: 700; font-size: 0.9rem; color: #0f172a; }
  .meta-lbl { font-size: 0.65rem; color: #94a3b8; font-weight: 600; text-transform: uppercase; }
  
  .btn-icon { width: 32px; height: 32px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; border: 1px solid #cbd5e1; background: #fff; color: #475569; cursor: pointer; transition: all 0.15s; }
  .btn-icon:hover { background: #f8fafc; color: #0f172a; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>System Users</h1>
      <p>Manage all registered accounts across the platform.</p>
    </div>
  </div>

  <form class="filter-form" method="get">
    <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search name or email...">
    <select name="role" onchange="this.form.submit()">
      <option value="">All roles</option>
      <option value="admin" <?= $roleFilter==='admin' ? 'selected':'' ?>>Admin</option>
      <option value="owner" <?= $roleFilter==='owner' ? 'selected':'' ?>>Owner</option>
      <option value="employee" <?= $roleFilter==='employee' ? 'selected':'' ?>>Employee</option>
    </select>
    <button type="submit" class="btn btn-sm btn-dark">Search</button>
  </form>

  <div class="list-panel">
    <?php if (!$users): ?>
      <div class="text-center py-5">
        <i class="fa-solid fa-users text-muted mb-3" style="font-size: 3rem; opacity: 0.3;"></i>
        <h5 class="fw-bold text-dark">No users found</h5>
        <p class="text-muted small">There are no users matching your filters.</p>
      </div>
    <?php else: foreach ($users as $u): ?>
      <?php
        $initials = '';
        foreach (array_slice(explode(' ', $u['full_name']), 0, 2) as $part) $initials .= mb_strtoupper(mb_substr($part, 0, 1));
        
        $roleColors = ['admin'=>'bg-danger-subtle text-danger', 'owner'=>'bg-primary-subtle text-primary', 'employee'=>'bg-secondary-subtle text-secondary'];
      ?>
      <div class="list-item">
        <div class="avatar-initials"><?= e($initials) ?></div>
        
        <div class="list-content">
          <div class="list-title">
            <?= e($u['full_name']) ?>
            <span class="badge <?= $roleColors[$u['role_name']] ?> ms-2" style="font-size:0.6rem; letter-spacing:0.05em;"><?= strtoupper($u['role_name']) ?></span>
            <?php if ($u['status'] !== 'active'): ?>
              <span class="badge bg-secondary-subtle text-secondary ms-1" style="font-size:0.6rem; letter-spacing:0.05em;">INACTIVE</span>
            <?php endif; ?>
          </div>
          <div class="list-sub">
            <span><i class="fa-regular fa-envelope me-1"></i><?= e($u['email']) ?></span>
            <?php if ($u['business_name']): ?>
              <span class="text-muted">•</span>
              <span><i class="fa-solid fa-store me-1"></i><?= e($u['business_name']) ?></span>
            <?php endif; ?>
          </div>
        </div>

        <div class="list-meta d-none d-md-flex">
          <div class="meta-item">
            <div class="meta-val" style="font-size:0.8rem;"><?= $u['last_login_at'] ? human_date($u['last_login_at']) : 'Never' ?></div>
            <div class="meta-lbl">Last Login</div>
          </div>
        </div>

        <div class="list-actions">
          <?php if ((int)$u['role_id'] !== 1): ?>
            <form method="post" class="m-0" onsubmit="return confirm('Toggle user status?');">
              <?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
              <button type="submit" class="btn-icon" title="Toggle Status"><i class="fa-solid fa-power-off"></i></button>
            </form>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>