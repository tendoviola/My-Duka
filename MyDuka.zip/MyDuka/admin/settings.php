<?php
// admin/settings.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

$pdo = db();
$userId = (int)current_user()['id'];

/* ------------------------------------------------------------------
 |  Handle Password Change
 * ------------------------------------------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && post('action') === 'password') {
    verify_csrf();
    $current = post('current_password');
    $new     = post('new_password');
    $confirm = post('confirm_password');

    $errors = [];
    $u = current_user();
    if (!password_verify($current, $u['password_hash'])) $errors[] = 'Current password is incorrect.';
    if (strlen($new) < PASSWORD_MIN_LEN) $errors[] = 'New password too short.';
    if ($new !== $confirm) $errors[] = 'Passwords do not match.';

    if ($errors) { 
        foreach ($errors as $e) flash('danger', $e); 
    } else {
        $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?")
            ->execute([password_hash($new, PASSWORD_DEFAULT), $userId]);
        audit_log('admin.password_changed', 'users', $userId);
        flash('success', 'Password updated successfully.');
    }
    redirect('settings.php?tab=security');
}

/* ------------------------------------------------------------------
 |  Load Data
 * ------------------------------------------------------------------ */
$stats = [
    'roles'       => (int)$pdo->query("SELECT COUNT(*) FROM roles")->fetchColumn(),
    'permissions' => (int)$pdo->query("SELECT COUNT(*) FROM permissions")->fetchColumn(),
    'businesses'  => (int)$pdo->query("SELECT COUNT(*) FROM businesses")->fetchColumn(),
    'users'       => (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
    'products'    => (int)$pdo->query("SELECT COUNT(*) FROM products")->fetchColumn(),
    'sales'       => (int)$pdo->query("SELECT COUNT(*) FROM sales")->fetchColumn(),
];

// Global settings (if you add a system_settings table later, query it here)
$sysSettings = [
    'app_name'      => APP_NAME,
    'app_env'       => APP_ENV,
    'timezone'      => APP_TIMEZONE,
    'session_life'  => (string)(SESSION_LIFETIME / 3600) . ' hours',
    'password_min'  => PASSWORD_MIN_LEN . ' characters',
];

$tab = get('tab', 'overview');
if (!in_array($tab, ['overview', 'security', 'defaults'], true)) $tab = 'overview';

$pageTitle = 'System Settings';
$breadcrumbs = ['Admin' => null, 'Settings' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; max-width: 1000px; margin: 0 auto; }
  
  .page-header { margin-bottom: 2rem; text-align: center; }
  .page-header h1 { font-weight: 800; font-size: 1.75rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.95rem; color: #64748b; font-weight: 500; margin-top: 0.5rem; }

  /* Tabs */
  .settings-tabs { display: flex; justify-content: center; gap: 1rem; border-bottom: 2px solid #e2e8f0; margin-bottom: 2rem; }
  .settings-tab {
    padding: 0.75rem 1rem; font-weight: 600; font-size: 0.9rem; color: #64748b;
    text-decoration: none; border-bottom: 2px solid transparent; margin-bottom: -2px;
    transition: all 0.15s; cursor: pointer;
  }
  .settings-tab:hover { color: #0f172a; }
  .settings-tab.active { color: #2563eb; border-bottom-color: #2563eb; }

  /* KPI Cards */
  .kpi-card {
    background: #fff; border: 1px solid #e2e8f0; border-radius: 16px;
    padding: 1.5rem; height: 100%; position: relative; overflow: hidden;
    box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02);
  }
  .kpi-label { font-size: 0.8rem; font-weight: 600; color: #64748b; margin-bottom: 0.5rem; }
  .kpi-value { font-size: 1.75rem; font-weight: 800; color: #0f172a; line-height: 1.1; letter-spacing: -0.03em; }
  .kpi-blob { position: absolute; top: -20px; right: -20px; width: 80px; height: 80px; border-radius: 50%; opacity: 0.1; }
  .kpi-blob.blue { background: #3b82f6; }
  .kpi-blob.green { background: #10b981; }
  .kpi-blob.purple { background: #8b5cf6; }
  .kpi-blob.orange { background: #f59e0b; }

  /* Panels */
  .settings-card { background: #fff; border: 1px solid #e2e8f0; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); margin-bottom: 1.5rem; }
  .settings-header { padding: 1.5rem; border-bottom: 1px solid #f1f5f9; display: flex; align-items: center; gap: 0.75rem; }
  .settings-header h3 { font-size: 1.1rem; font-weight: 700; color: #0f172a; margin: 0; }
  .settings-header .icon { width: 36px; height: 36px; border-radius: 10px; background: #eff6ff; color: #2563eb; display: flex; align-items: center; justify-content: center; font-size: 1rem; }
  .settings-body { padding: 1.5rem; }
  
  .form-label { font-size: 0.85rem; font-weight: 700; color: #334155; margin-bottom: 0.4rem; }
  .form-control { border-radius: 10px; border: 1px solid #cbd5e1; padding: 0.75rem 1rem; font-size: 0.95rem; font-weight: 500; background: #f8fafc; transition: all 0.2s; }
  .form-control:focus { border-color: #3b82f6; background: #fff; box-shadow: 0 0 0 3px rgba(59,130,246,0.1); outline: none; }
  
  /* Password specific */
  .input-wrapper { position: relative; }
  .toggle-password { position: absolute; right: 0.85rem; top: 50%; transform: translateY(-50%); background: none; border: none; color: #94a3b8; cursor: pointer; padding: 0.25rem; font-size: 1rem; transition: color 0.2s; }
  .toggle-password:hover { color: #475569; }
  
  .requirements { list-style: none; padding: 0; margin: 1rem 0 0 0; }
  .requirements li { font-size: 0.8rem; font-weight: 500; color: #94a3b8; margin-bottom: 0.4rem; display: flex; align-items: center; gap: 0.5rem; transition: all 0.2s ease; }
  .requirements li i { font-size: 0.9rem; color: #cbd5e1; }
  .requirements li.met { color: #16a34a; }
  .requirements li.met i { color: #16a34a; }

  .btn-save { background: #0f172a; color: #fff; font-weight: 700; padding: 0.75rem 1.5rem; border-radius: 10px; transition: all 0.2s; border: none; }
  .btn-save:hover { background: #1e293b; }
  .btn-save:disabled { background: #cbd5e1; cursor: not-allowed; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <h1>System Settings</h1>
    <p>Manage platform configuration, view statistics, and update your security.</p>
  </div>

  <div class="settings-tabs">
    <a class="settings-tab <?= $tab === 'overview' ? 'active' : '' ?>" href="?tab=overview">Overview</a>
    <a class="settings-tab <?= $tab === 'security' ? 'active' : '' ?>" href="?tab=security">Security</a>
    <a class="settings-tab <?= $tab === 'defaults' ? 'active' : '' ?>" href="?tab=defaults">Platform Defaults</a>
  </div>

  <?php if ($tab === 'overview'): ?>
    
    <div class="row g-4 mb-4">
      <div class="col-md-6 col-xl-3">
        <div class="kpi-card">
          <div class="kpi-blob blue"></div>
          <div class="kpi-label">Registered Businesses</div>
          <div class="kpi-value"><?= $stats['businesses'] ?></div>
        </div>
      </div>
      <div class="col-md-6 col-xl-3">
        <div class="kpi-card">
          <div class="kpi-blob green"></div>
          <div class="kpi-label">Total Users</div>
          <div class="kpi-value"><?= $stats['users'] ?></div>
        </div>
      </div>
      <div class="col-md-6 col-xl-3">
        <div class="kpi-card">
          <div class="kpi-blob purple"></div>
          <div class="kpi-label">Global Products</div>
          <div class="kpi-value"><?= $stats['products'] ?></div>
        </div>
      </div>
      <div class="col-md-6 col-xl-3">
        <div class="kpi-card">
          <div class="kpi-blob orange"></div>
          <div class="kpi-label">Total Sales Recorded</div>
          <div class="kpi-value"><?= $stats['sales'] ?></div>
        </div>
      </div>
    </div>

    <div class="row g-4">
      <div class="col-lg-5">
        <div class="settings-card h-100">
          <div class="settings-header">
            <div class="icon"><i class="fa-solid fa-shield-halved"></i></div>
            <h3>Access Control</h3>
          </div>
          <div class="settings-body">
            <div class="d-flex justify-content-between align-items-center mb-3">
              <span class="text-muted fw-semibold">Roles defined</span>
              <span class="fw-bold fs-5 text-dark"><?= $stats['roles'] ?></span>
            </div>
            <div class="d-flex justify-content-between align-items-center">
              <span class="text-muted fw-semibold">Permissions defined</span>
              <span class="fw-bold fs-5 text-dark"><?= $stats['permissions'] ?></span>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-7">
        <div class="settings-card h-100">
          <div class="settings-header">
            <div class="icon"><i class="fa-solid fa-circle-info"></i></div>
            <h3>Architecture Notes</h3>
          </div>
          <div class="settings-body">
            <p class="text-muted small mb-3">System configuration (tax defaults, negative stock, receipt footer) is managed <strong>per business</strong> by its owner, not globally.</p>
            <p class="text-muted small mb-3">The permission catalogue is seeded in the database schema. Adding new permissions requires a schema change.</p>
            <p class="text-muted small mb-0">Subscription and billing modules are reserved for a future release.</p>
          </div>
        </div>
      </div>
    </div>

  <?php elseif ($tab === 'security'): ?>
    
    <div class="settings-card">
      <div class="settings-header">
        <div class="icon"><i class="fa-solid fa-key"></i></div>
        <h3>Change Admin Password</h3>
      </div>
      <div class="settings-body">
        <form method="post" id="passwordForm">
          <?= csrf_field() ?><input type="hidden" name="action" value="password">
          
          <div class="row g-4">
            <div class="col-12">
              <label class="form-label">Current Password</label>
              <div class="input-wrapper">
                <input type="password" name="current_password" id="current_password" class="form-control" required>
                <button type="button" class="toggle-password" data-target="current_password"><i class="fa-regular fa-eye"></i></button>
              </div>
            </div>
            
            <div class="col-md-6">
              <label class="form-label">New Password</label>
              <div class="input-wrapper">
                <input type="password" name="new_password" id="new_password" class="form-control" minlength="<?= PASSWORD_MIN_LEN ?>" required>
                <button type="button" class="toggle-password" data-target="new_password"><i class="fa-regular fa-eye"></i></button>
              </div>
            </div>
            
            <div class="col-md-6">
              <label class="form-label">Confirm New Password</label>
              <div class="input-wrapper">
                <input type="password" name="confirm_password" id="confirm_password" class="form-control" required>
                <button type="button" class="toggle-password" data-target="confirm_password"><i class="fa-regular fa-eye"></i></button>
              </div>
            </div>

            <div class="col-12 mt-3">
              <ul class="requirements" id="reqList">
                <li id="req-length"><i class="fa-solid fa-circle"></i> At least <?= PASSWORD_MIN_LEN ?> characters</li>
                <li id="req-upper"><i class="fa-solid fa-circle"></i> Contains upper & lowercase letters</li>
                <li id="req-number"><i class="fa-solid fa-circle"></i> Contains at least one number</li>
                <li id="req-match"><i class="fa-solid fa-circle"></i> Passwords match</li>
              </ul>
            </div>
          </div>

          <div class="mt-5 pt-3 border-top">
            <button type="submit" class="btn-save" id="submitBtn" disabled>Update Password</button>
          </div>
        </form>
      </div>
    </div>

  <?php elseif ($tab === 'defaults'): ?>
    
    <div class="settings-card">
      <div class="settings-header">
        <div class="icon"><i class="fa-solid fa-sliders"></i></div>
        <h3>Global Platform Defaults</h3>
      </div>
      <div class="settings-body">
        <div class="alert alert-info border-0 small mb-4" style="background-color: #eff6ff; color: #1e40af;">
          <i class="fa-solid fa-circle-info me-2"></i> These settings are controlled by the <code>config/app.php</code> file on the server. To change them, update the file and refresh.
        </div>

        <div class="row g-4">
          <div class="col-md-6">
            <label class="form-label">Application Name</label>
            <input type="text" class="form-control" value="<?= e($sysSettings['app_name']) ?>" disabled>
          </div>
          <div class="col-md-6">
            <label class="form-label">Environment</label>
            <input type="text" class="form-control" value="<?= e($sysSettings['app_env']) ?>" disabled>
          </div>
          <div class="col-md-6">
            <label class="form-label">Timezone</label>
            <input type="text" class="form-control" value="<?= e($sysSettings['timezone']) ?>" disabled>
          </div>
          <div class="col-md-6">
            <label class="form-label">Session Lifetime</label>
            <input type="text" class="form-control" value="<?= e($sysSettings['session_life']) ?>" disabled>
          </div>
          <div class="col-md-6">
            <label class="form-label">Minimum Password Length</label>
            <input type="text" class="form-control" value="<?= e($sysSettings['password_min']) ?>" disabled>
          </div>
        </div>
      </div>
    </div>

  <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  // Toggle Password Visibility
  document.querySelectorAll('.toggle-password').forEach(btn => {
    btn.addEventListener('click', function() {
      const input = document.getElementById(this.dataset.target);
      const icon = this.querySelector('i');
      if (input.type === 'password') {
        input.type = 'text';
        icon.classList.replace('fa-eye', 'fa-eye-slash');
        this.style.color = '#2563eb';
      } else {
        input.type = 'password';
        icon.classList.replace('fa-eye-slash', 'fa-eye');
        this.style.color = '#94a3b8';
      }
    });
  });

  // Live Password Validation
  const newPass = document.getElementById('new_password');
  if (!newPass) return; 

  const confirmPass = document.getElementById('confirm_password');
  const currentPass = document.getElementById('current_password');
  const submitBtn = document.getElementById('submitBtn');
  
  const reqLength = document.getElementById('req-length');
  const reqUpper = document.getElementById('req-upper');
  const reqNumber = document.getElementById('req-number');
  const reqMatch = document.getElementById('req-match');

  function validate() {
    const val = newPass.value;
    const confirmVal = confirmPass.value;
    
    const isLength = val.length >= <?= PASSWORD_MIN_LEN ?>;
    const isUpper = /[A-Z]/.test(val) && /[a-z]/.test(val);
    const isNumber = /[0-9]/.test(val);
    const isMatch = val.length > 0 && val === confirmVal;

    reqLength.classList.toggle('met', isLength);
    reqUpper.classList.toggle('met', isUpper);
    reqNumber.classList.toggle('met', isNumber);
    reqMatch.classList.toggle('met', isMatch);

    [reqLength, reqUpper, reqNumber, reqMatch].forEach(li => {
      const icon = li.querySelector('i');
      if (li.classList.contains('met')) icon.classList.replace('fa-circle', 'fa-circle-check');
      else icon.classList.replace('fa-circle-check', 'fa-circle');
    });

    let allValid = isLength && isUpper && isNumber && isMatch;
    if (currentPass) allValid = allValid && currentPass.value.length > 0;
    submitBtn.disabled = !allValid;
  }

  newPass.addEventListener('input', validate);
  confirmPass.addEventListener('input', validate);
  if (currentPass) currentPass.addEventListener('input', validate);
});
</script>

<?php require __DIR__ . '/../includes/footer.php'; ?>