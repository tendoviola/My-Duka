<?php
// admin/activity.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

$pdo = db();

$from   = get('from', date('Y-m-01'));
$to     = get('to',   date('Y-m-d'));
$search = get('q');

$where = "DATE(a.created_at) BETWEEN ? AND ?";
$params = [$from, $to];
if ($search !== '') {
    $where .= " AND a.action LIKE ?";
    $params[] = "%{$search}%";
}

// Fetch the logs and join the entity_user to get the name of the user being acted upon
$stmt = $pdo->prepare(
    "SELECT a.*, 
            u.full_name AS user_name, 
            b.name AS business_name,
            -- Try to resolve the entity name based on entity type
            CASE 
                WHEN a.entity = 'users' THEN (SELECT full_name FROM users WHERE id = a.entity_id LIMIT 1)
                WHEN a.entity = 'businesses' THEN (SELECT name FROM businesses WHERE id = a.entity_id LIMIT 1)
                WHEN a.entity = 'products' THEN (SELECT name FROM products WHERE id = a.entity_id LIMIT 1)
                WHEN a.entity = 'sales' THEN (SELECT sale_number FROM sales WHERE id = a.entity_id LIMIT 1)
                WHEN a.entity = 'purchases' THEN (SELECT purchase_number FROM purchases WHERE id = a.entity_id LIMIT 1)
                WHEN a.entity = 'expenses' THEN (SELECT description FROM expenses WHERE id = a.entity_id LIMIT 1)
                WHEN a.entity = 'customers' THEN (SELECT name FROM customers WHERE id = a.entity_id LIMIT 1)
                WHEN a.entity = 'suppliers' THEN (SELECT name FROM suppliers WHERE id = a.entity_id LIMIT 1)
                WHEN a.entity = 'categories' THEN (SELECT name FROM categories WHERE id = a.entity_id LIMIT 1)
                WHEN a.entity = 'employees' THEN (SELECT full_name FROM users WHERE id = a.entity_id LIMIT 1)
                ELSE NULL
            END AS entity_name
     FROM audit_logs a
     LEFT JOIN users u ON u.id = a.user_id
     LEFT JOIN businesses b ON b.id = a.business_id
     WHERE {$where}
     ORDER BY a.created_at DESC LIMIT 500"
);
$stmt->execute($params);
$logs = $stmt->fetchAll();

$pageTitle = 'System Activity';
$breadcrumbs = ['Admin' => null, 'Activity' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; max-width: 1000px; margin: 0 auto; }
  
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }

  /* Filter Bar */
  .filter-bar { display: flex; gap: 0.5rem; background: #fff; padding: 0.35rem; border-radius: 10px; border: 1px solid #cbd5e1; margin-bottom: 1.5rem; flex-wrap: wrap; align-items: center; }
  .filter-bar input { border: none; border-radius: 6px; padding: 0.35rem 0.5rem; font-size: 0.8rem; font-weight: 500; color: #0f172a; background: transparent; }
  .filter-bar input:focus { outline: none; background: #f8fafc; }

  /* Timeline Container */
  .timeline-panel { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; padding: 1.5rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
  
  .timeline { position: relative; padding-left: 2rem; margin: 0; list-style: none; }
  .timeline::before { content: ''; position: absolute; top: 0; bottom: 0; left: 7px; width: 2px; background: #e2e8f0; }
  
  .timeline-item { position: relative; margin-bottom: 1.5rem; }
  .timeline-item:last-child { margin-bottom: 0; }
  
  .timeline-marker { 
    position: absolute; left: -2rem; top: 0.25rem; 
    width: 16px; height: 16px; border-radius: 50%; 
    background: #fff; border: 3px solid #3b82f6; 
    box-shadow: 0 0 0 4px #fff;
  }
  
  /* Different colors for different actions */
  .timeline-marker.danger { border-color: #ef4444; }
  .timeline-marker.success { border-color: #10b981; }
  
  .timeline-content { 
    background: #f8fafc; border: 1px solid #e2e8f0; 
    border-radius: 12px; padding: 1rem 1.25rem; 
    transition: all 0.2s ease;
  }
  .timeline-content:hover { border-color: #cbd5e1; background: #fff; box-shadow: 0 4px 12px rgba(0,0,0,0.03); }

  .timeline-title { font-weight: 700; font-size: 0.95rem; color: #0f172a; margin: 0 0 0.25rem 0; display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;}
  .timeline-action-code { font-family: monospace; background: #e2e8f0; color: #475569; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.75rem; }
  .timeline-entity-name { font-weight: 700; color: #0f172a; }
  
  .timeline-meta { display: flex; flex-wrap: wrap; gap: 1rem; font-size: 0.8rem; color: #64748b; font-weight: 500; margin-top: 0.5rem; }
  .timeline-meta span { display: flex; align-items: center; gap: 0.35rem; }
  .timeline-meta i { color: #94a3b8; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>System Activity</h1>
      <p>Immutable audit trail of all actions across the platform.</p>
    </div>
  </div>

  <form class="filter-bar" method="get">
    <input type="date" name="from" value="<?= e($from) ?>" class="form-control form-control-sm" style="width: auto;">
    <input type="date" name="to" value="<?= e($to) ?>" class="form-control form-control-sm" style="width: auto;">
    <input type="text" name="q" value="<?= e($search) ?>" placeholder="Filter by action code (e.g. sale.create)..." class="form-control form-control-sm flex-grow-1" style="max-width: 300px;">
    <button type="submit" class="btn btn-sm btn-dark fw-bold px-3">Filter</button>
  </form>

  <div class="timeline-panel">
    <?php if (!$logs): ?>
      <div class="text-center py-5">
        <i class="fa-solid fa-shield-halved text-muted mb-3" style="font-size: 3rem; opacity: 0.3;"></i>
        <h5 class="fw-bold text-dark">No activity found</h5>
        <p class="text-muted small">There are no audit logs for this period.</p>
      </div>
    <?php else: ?>
      <ul class="timeline">
        <?php foreach ($logs as $l): ?>
          <?php 
            // Assign colors to specific actions
            $markerClass = '';
            if (str_contains($l['action'], 'delete') || str_contains($l['action'], 'cancel') || str_contains($l['action'], 'suspend')) {
                $markerClass = 'danger';
            } elseif (str_contains($l['action'], 'create') || str_contains($l['action'], 'receive') || str_contains($l['action'], 'activate')) {
                $markerClass = 'success';
            }
          ?>
          <li class="timeline-item">
            <div class="timeline-marker <?= $markerClass ?>"></div>
            <div class="timeline-content">
              <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                <h6 class="timeline-title">
                  <span class="timeline-action-code"><?= e($l['action']) ?></span>
                  
                  <?php if (!empty($l['entity_name'])): ?>
                    <span class="text-muted small">—</span>
                    <span class="timeline-entity-name">
                      <?= e($l['entity_name']) ?>
                    </span>
                  <?php elseif (!empty($l['entity']) && !empty($l['entity_id'])): ?>
                    <span class="text-muted small">—</span>
                    <span class="timeline-entity-name text-muted">
                      <?= e(ucfirst($l['entity'])) ?> #<?= (int)$l['entity_id'] ?>
                    </span>
                  <?php endif; ?>
                </h6>
                <small class="text-muted fw-bold" style="font-size: 0.75rem;"><i class="fa-regular fa-clock me-1"></i><?= human_datetime($l['created_at']) ?></small>
              </div>
              
              <div class="timeline-meta">
                <span>
                  <i class="fa-solid fa-user"></i> 
                  <?= e($l['user_name'] ?: 'System / Automated') ?>
                </span>
                
                <?php if ($l['business_name']): ?>
                  <span>
                    <i class="fa-solid fa-building"></i> 
                    <?= e($l['business_name']) ?>
                  </span>
                <?php endif; ?>

                <?php if ($l['ip_address']): ?>
                  <span>
                    <i class="fa-solid fa-network-wired"></i> 
                    <?= e($l['ip_address']) ?>
                  </span>
                <?php endif; ?>
              </div>
            </div>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>