<?php
// admin/branches.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

$pdo = db();
$search = get('q');
$where = "1=1";
$params = [];
if ($search !== '') {
    $where .= " AND (b.name LIKE ? OR bu.name LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

$stmt = $pdo->prepare(
    "SELECT b.*, bu.name AS business_name,
            (SELECT COUNT(*) FROM user_branch_assignments uba WHERE uba.branch_id = b.id) AS staff
     FROM branches b JOIN businesses bu ON bu.id = b.business_id
     WHERE {$where} ORDER BY bu.name, b.name LIMIT 500"
);
$stmt->execute($params);
$branches = $stmt->fetchAll();

$pageTitle = 'All Branches';
$breadcrumbs = ['Admin' => null, 'Branches' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; }
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }

  .filter-form { display: flex; gap: 0.5rem; background: #fff; padding: 0.35rem; border-radius: 10px; border: 1px solid #cbd5e1; margin-bottom: 1rem; flex-wrap: wrap; align-items: center; }
  .filter-form input, .filter-form select { border: none; border-radius: 6px; padding: 0.35rem 0.5rem; font-size: 0.8rem; font-weight: 500; color: #0f172a; background: transparent; }
  .filter-form input:focus { outline: none; background: #f8fafc; }

  .list-panel { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
  .list-item { display: flex; align-items: center; padding: 1.25rem 1.5rem; border-bottom: 1px solid #f1f5f9; transition: background 0.15s; flex-wrap: wrap; gap: 1rem; }
  .list-item:last-child { border-bottom: none; }
  .list-item:hover { background: #f8fafc; }
  
  .list-icon { width: 44px; height: 44px; border-radius: 12px; background: #f1f5f9; color: #475569; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0; }
  .list-icon.main { background: #eff6ff; color: #2563eb; }
  
  .list-content { flex: 1; min-width: 200px; }
  .list-title { font-weight: 700; font-size: 0.95rem; color: #0f172a; margin-bottom: 0.15rem; }
  .list-sub { font-size: 0.75rem; color: #64748b; font-weight: 500; display: flex; gap: 0.75rem; align-items: center; }
  
  .list-meta { display: flex; gap: 1.5rem; text-align: right; align-items: center; }
  .meta-item { text-align: right; }
  .meta-val { font-weight: 700; font-size: 0.9rem; color: #0f172a; }
  .meta-lbl { font-size: 0.65rem; color: #94a3b8; font-weight: 600; text-transform: uppercase; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>All Branches</h1>
      <p>View all physical locations across all businesses.</p>
    </div>
  </div>

  <form class="filter-form" method="get">
    <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search branch or business...">
    <button type="submit" class="btn btn-sm btn-dark">Search</button>
  </form>

  <div class="list-panel">
    <?php if (!$branches): ?>
      <div class="text-center py-5">
        <i class="fa-solid fa-store text-muted mb-3" style="font-size: 3rem; opacity: 0.3;"></i>
        <h5 class="fw-bold text-dark">No branches found</h5>
        <p class="text-muted small">There are no branches matching your search.</p>
      </div>
    <?php else: foreach ($branches as $b): ?>
      <div class="list-item">
        <div class="list-icon <?= $b['is_main'] ? 'main' : '' ?>">
          <i class="fa-solid fa-store"></i>
        </div>
        
        <div class="list-content">
          <div class="list-title">
            <?= e($b['name']) ?>
            <?php if ($b['is_main']): ?>
              <span class="badge bg-primary-subtle text-primary ms-2" style="font-size:0.6rem; letter-spacing:0.05em;">MAIN</span>
            <?php endif; ?>
          </div>
          <div class="list-sub">
            <span><i class="fa-solid fa-building me-1"></i><?= e($b['business_name']) ?></span>
            <?php if ($b['address']): ?>
              <span class="text-muted">•</span>
              <span><i class="fa-solid fa-location-dot me-1"></i><?= e($b['address']) ?></span>
            <?php endif; ?>
          </div>
        </div>

        <div class="list-meta d-none d-md-flex">
          <div class="meta-item">
            <div class="meta-val"><?= (int)$b['staff'] ?></div>
            <div class="meta-lbl">Staff Assigned</div>
          </div>
          <div class="meta-item">
            <span class="badge <?= $b['status']==='active' ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary' ?>">
              <?= e(ucfirst($b['status'])) ?>
            </span>
          </div>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>