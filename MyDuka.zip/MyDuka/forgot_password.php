<?php
// forgot_password.php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/mailer.php';

if (is_logged_in()) redirect('index.php');

$message = '';
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = post('email');

    if (!valid_email($email)) {
        $error = 'Please enter a valid email address.';
    } else {
        $stmt = db()->prepare("SELECT id, full_name FROM users WHERE email = ? AND status = 'active' LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user) {
            $token   = bin2hex(random_bytes(32));
            $expiry  = date('Y-m-d H:i:s', strtotime('+1 hour'));

            db()->prepare("UPDATE users SET reset_token = ?, reset_expires_at = ? WHERE id = ?")
                ->execute([$token, $expiry, $user['id']]);

            $resetUrl = APP_URL . '/reset_password.php?token=' . $token;

            $htmlBody = "
                <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 30px; background: #f8fafc; border-radius: 12px;'>
                    <h2 style='color: #0f172a;'>Hello " . htmlspecialchars($user['full_name']) . ",</h2>
                    <p style='color: #475569; font-size: 15px; line-height: 1.6;'>We received a request to reset the password for your <strong>My Duka</strong> account.</p>
                    <p style='color: #475569; font-size: 15px; line-height: 1.6;'>Click the button below to set a new password. This link will expire in <strong>1 hour</strong>.</p>
                    <div style='text-align: center; margin: 30px 0;'>
                        <a href='$resetUrl' style='background: #2563eb; color: #fff; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;'>Reset My Password</a>
                    </div>
                    <p style='color: #94a3b8; font-size: 13px;'>If you did not request this, you can safely ignore this email. Your password will not change.</p>
                    <hr style='border: none; border-top: 1px solid #e2e8f0; margin: 20px 0;'>
                    <p style='color: #94a3b8; font-size: 12px; text-align: center;'>&copy; " . date('Y') . " My Duka. All rights reserved.</p>
                </div>
            ";

            try {
                send_email($email, $user['full_name'], 'Reset Your Password · My Duka', $htmlBody);
                audit_log('user.password_reset_requested', 'users', (int)$user['id']);
                $message = "A password reset link has been sent to <strong>$email</strong>. Please check your inbox.";
            } catch (Throwable $ex) {
                $error = "Could not send the email. Please try again. " . (APP_ENV === 'development' ? $ex->getMessage() : '');
            }
        } else {
            $message = "If that email is registered, a password reset link has been sent.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Forgot Password · <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

  body {
    font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
    background-color: #f4f6fb;
    margin: 0; padding: 0; min-height: 100vh; display: flex;
  }

  .login-wrapper { display: flex; min-height: 100vh; width: 100vw; }

  /* LEFT PANEL - BRANDING */
  .login-left {
    display: none; flex: 1;
    background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%);
    position: relative; overflow: hidden; padding: 4rem;
    flex-direction: column; justify-content: space-between; align-items: center;
    color: #fff;
  }

  @media (min-width: 992px) { .login-left { display: flex; } }

  .login-left::before {
    content: ''; position: absolute; inset: 0;
    background-image: linear-gradient(rgba(255, 255, 255, 0.05) 1px, transparent 1px),
                      linear-gradient(90deg, rgba(255, 255, 255, 0.05) 1px, transparent 1px);
    background-size: 25px 25px;
    mask-image: linear-gradient(to bottom, black, transparent);
    -webkit-mask-image: linear-gradient(to bottom, black, transparent);
  }
  
  .login-left::after {
    content: ''; position: absolute; top: -20%; right: -10%;
    width: 500px; height: 500px;
    background: radial-gradient(circle, rgba(59, 130, 246, 0.4) 0%, transparent 70%);
    filter: blur(50px); border-radius: 50%;
  }

  .brand-content {
    text-align: center;
    position: relative; z-index: 2;
    display: flex; flex-direction: column; align-items: center;
    margin-top: auto; margin-bottom: auto;
  }

  .login-logo-wrap {
    margin-bottom: 3rem;
    display: inline-block;
    text-decoration: none;
    transition: transform 0.2s ease;
  }
  .login-logo-wrap:hover { transform: scale(1.05); }
  
  .login-logo-img {
    height: 100px; width: auto; max-width: 320px;
    object-fit: contain; transform: scale(1.3); 
  }

  .login-left h1 {
    font-weight: 800; font-size: 3rem;
    letter-spacing: -0.03em; line-height: 1.1; margin-bottom: 1.5rem;
  }
  
  .login-left p { color: #94a3b8; font-size: 1.1rem; line-height: 1.6; max-width: 450px; margin: 0 auto; }

  /* RIGHT PANEL - FORM */
  .login-right {
    flex: 1; display: flex; align-items: center; justify-content: center;
    padding: 2rem; background: #fff; position: relative;
  }

  .form-wrapper { width: 100%; max-width: 420px; }

  .form-icon-wrap {
    width: 56px; height: 56px;
    border-radius: 14px;
    background: #eff6ff;
    color: #2563eb;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    margin: 0 auto 1.5rem;
  }

  .form-header { margin-bottom: 2rem; text-align: center; }
  .form-header h3 { font-weight: 800; font-size: 1.75rem; color: #0f172a; letter-spacing: -0.02em; margin-bottom: 0.5rem; }
  .form-header p { color: #64748b; font-size: 0.95rem; line-height: 1.5; }

  .form-group { margin-bottom: 1.25rem; }
  .form-group label { display: block; font-size: 0.85rem; font-weight: 700; color: #334155; margin-bottom: 0.4rem; }

  .input-wrapper { position: relative; }
  .input-wrapper input {
    width: 100%; padding: 0.85rem 1rem;
    border-radius: 10px; border: 1px solid #cbd5e1;
    font-size: 0.95rem; font-weight: 500; color: #0f172a;
    background: #f8fafc; transition: all 0.2s;
  }
  .input-wrapper input:focus {
    outline: none; background: #fff; border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
  }

  .btn-submit {
    width: 100%; background: #0f172a; color: #fff; border: none;
    border-radius: 10px; padding: 0.9rem; font-weight: 700; font-size: 1rem;
    transition: all 0.2s; display: flex; justify-content: center; align-items: center; gap: 0.5rem;
  }
  .btn-submit:hover { background: #1e293b; transform: translateY(-1px); box-shadow: 0 6px 15px rgba(15, 23, 42, 0.2); }

  .alert-custom {
    border-radius: 10px; padding: 0.85rem 1rem; font-size: 0.85rem; font-weight: 500;
    margin-bottom: 1.5rem; display: flex; align-items: flex-start; gap: 0.5rem;
    line-height: 1.5;
  }
  .alert-custom.danger { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }
  .alert-custom.success { background: #f0fdf4; color: #166534; border: 1px solid #bbf7d0; }

  .footer-text { text-align: center; font-size: 0.9rem; color: #64748b; margin-top: 2rem; }
  .footer-text a { font-weight: 700; color: #2563eb; text-decoration: none; }
  .footer-text a:hover { text-decoration: underline; }
  
  .back-link {
    display: block; text-align: center; font-size: 0.85rem;
    color: #94a3b8; text-decoration: none; margin-top: 1.5rem; transition: color 0.2s;
  }
  .back-link:hover { color: #0f172a; }
</style>
</head>
<body>

<div class="login-wrapper">
  <!-- LEFT SIDE: BRANDING -->
  <div class="login-left">
    <div class="brand-content">
      <a href="index.php" class="login-logo-wrap" title="Back to Home">
        <img src="<?= e(APP_URL) ?>/assets/logo/logo.png" alt="<?= e(APP_NAME) ?> Logo" class="login-logo-img">
      </a>
      <h1>Lost your way?</h1>
      <p>Don't worry, it happens to everyone. Enter your email and we'll send you a secure link to get back into your workspace.</p>
    </div>
    <div style="position: relative; z-index: 2;">
      <p class="small mb-0" style="opacity: 0.6;">&copy; <?= date('Y') ?> <?= e(APP_NAME) ?>. All rights reserved.</p>
    </div>
  </div>

  <!-- RIGHT SIDE: FORM -->
  <div class="login-right">
    <div class="form-wrapper">
      <div class="form-icon-wrap">
        <i class="fa-solid fa-key"></i>
      </div>
      <div class="form-header">
        <h3>Forgot Password?</h3>
        <p>Enter your account email and we'll send a reset link.</p>
      </div>

      <?php if ($error): ?>
        <div class="alert-custom danger">
          <i class="fa-solid fa-circle-exclamation mt-1"></i> <div><?= e($error) ?></div>
        </div>
      <?php endif; ?>

      <?php if ($message): ?>
        <div class="alert-custom success">
          <i class="fa-solid fa-circle-check mt-1"></i> <div><?= $message ?></div>
        </div>
      <?php endif; ?>

      <form method="post">
        <?= csrf_field() ?>
        <div class="form-group">
          <label>Email Address</label>
          <div class="input-wrapper">
            <input type="email" name="email" class="form-control" required autofocus placeholder="name@company.com">
          </div>
        </div>
        <button type="submit" class="btn-submit">
          Send Reset Link <i class="fa-solid fa-paper-plane ms-1"></i>
        </button>
      </form>

      <a href="login.php" class="back-link">
        <i class="fa-solid fa-arrow-left me-1" style="font-size: 0.75rem;"></i> Back to Login
      </a>
    </div>
  </div>
</div>

</body>
</html>