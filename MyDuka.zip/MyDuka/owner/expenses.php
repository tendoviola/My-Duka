<?php
// owner/expenses.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_role('owner');
require_permission('expense.view');

$pdo        = db();
$businessId = user_business_id();
$userId     = (int)current_user()['id'];
$branches   = user_branch_ids();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post('action');

    if ($action === 'save') {
        require_permission('expense.create');
        $id          = post_int('id');
        $branchId    = post_int('branch_id');
        $categoryId  = post_int('category_id') ?: null;
        $description = post('description');
        $amount      = post_float('amount');
        $date        = post('expense_date') ?: date('Y-m-d');
        $method      = post('method') ?: 'cash';

        $errors = [];
        if (!in_array($branchId, $branches, true)) $errors[] = 'Invalid branch.';
        if ($description === '') $errors[] = 'Description is required.';
        if ($amount <= 0)        $errors[] = 'Amount must be greater than zero.';
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) $errors[] = 'Invalid date.';
        if (!in_array($method, ['cash','mobile_money','bank','other'], true)) $errors[] = 'Invalid method.';
        if ($categoryId) {
            $chk = $pdo->prepare("SELECT 1 FROM expense_categories WHERE id = ? AND business_id = ?");
            $chk->execute([$categoryId, $businessId]);
            if (!$chk->fetchColumn()) $errors[] = 'Invalid category.';
        }

        if ($errors) {
            foreach ($errors as $e) flash('danger', $e);
        } else {
            try {
                if ($id > 0) {
                    $chk = $pdo->prepare("SELECT 1 FROM expenses WHERE id = ? AND business_id = ?");
                    $chk->execute([$id, $businessId]);
                    if (!$chk->fetchColumn()) throw new RuntimeException('Expense not found.');
                    $pdo->prepare("UPDATE expenses SET branch_id=?, category_id=?, description=?, amount=?, expense_date=?, method=? WHERE id=?")
                        ->execute([$branchId, $categoryId, $description, $amount, $date, $method, $id]);
                    audit_log('expense.update', 'expenses', $id, ['amount' => $amount], $branchId);
                    flash('success', 'Expense updated.');
                } else {
                    $pdo->prepare("INSERT INTO expenses (business_id, branch_id, category_id, description, amount, expense_date, method, user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")
                        ->execute([$businessId, $branchId, $categoryId, $description, $amount, $date, $method, $userId]);
                    $newId = (int)$pdo->lastInsertId();
                    audit_log('expense.create', 'expenses', $newId, ['amount' => $amount], $branchId);
                    flash('success', 'Expense recorded.');
                }
            } catch (Throwable $ex) {
                flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Could not save expense.');
            }
        }
        redirect('expenses.php');
    }
}

$branchFilter = (int)get('branch', 0);
$from = get('from', date('Y-m-01'));
$to   = get('to',   date('Y-m-d'));

$where = "e.business_id = ? AND e.expense_date BETWEEN ? AND ?";
$params = [$businessId, $from, $to];
if ($branchFilter > 0 && in_array($branchFilter, $branches, true)) {
    $where .= " AND e.branch_id = ?";
    $params[] = $branchFilter;
}

$stmt = $pdo->prepare(
    "SELECT e.*, b.name AS branch_name, c.name AS category_name, u.full_name AS recorder
     FROM expenses e JOIN branches b ON b.id = e.branch_id
     LEFT JOIN expense_categories c ON c.id = e.category_id
     LEFT JOIN users u ON u.id = e.user_id
     WHERE {$where} ORDER BY e.expense_date DESC, e.id DESC LIMIT 300"
);
$stmt->execute($params);
$expenses = $stmt->fetchAll();

$totals = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM expenses e WHERE {$where}");
$totals->execute($params);
$totalAmount = (float)$totals->fetchColumn();

$categories = $pdo->prepare("SELECT id, name FROM expense_categories WHERE business_id = ? ORDER BY name");
$categories->execute([$businessId]);
$categories = $categories->fetchAll();

$allBranches = $pdo->prepare("SELECT id, name FROM branches WHERE business_id = ? AND status='active' ORDER BY is_main DESC, name");
$allBranches->execute([$businessId]);
$allBranches = $allBranches->fetchAll();

$pageTitle = 'Expenses';
$breadcrumbs = ['Dashboard' => APP_URL . '/owner/dashboard.php', 'Expenses' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; }
  
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }

  .filter-form { display: flex; gap: 0.5rem; background: #fff; padding: 0.35rem; border-radius: 10px; border: 1px solid #cbd5e1; margin-bottom: 1rem; flex-wrap: wrap; align-items: center; }
  .filter-form input, .filter-form select { border: none; border-radius: 6px; padding: 0.35rem 0.5rem; font-size: 0.8rem; font-weight: 500; color: #0f172a; background: transparent; }
  .filter-form input:focus, .filter-form select:focus { outline: none; background: #f8fafc; }

  .list-panel { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
  .list-item { display: flex; align-items: center; padding: 1.25rem 1.5rem; border-bottom: 1px solid #f1f5f9; transition: background 0.15s; flex-wrap: wrap; gap: 1rem; }
  .list-item:last-child { border-bottom: none; }
  .list-item:hover { background: #f8fafc; }
  
  .list-icon { width: 44px; height: 44px; border-radius: 12px; background: #fef2f2; color: #dc2626; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0; }
  
  .list-content { flex: 1; min-width: 200px; }
  .list-title { font-weight: 700; font-size: 0.95rem; color: #0f172a; margin-bottom: 0.15rem; }
  .list-sub { font-size: 0.75rem; color: #64748b; font-weight: 500; display: flex; gap: 0.75rem; align-items: center; }
  
  .list-meta { display: flex; gap: 1.5rem; text-align: right; align-items: center; }
  .meta-item { text-align: right; }
  .meta-val { font-weight: 800; font-size: 1.05rem; color: #dc2626; }
  .meta-lbl { font-size: 0.65rem; color: #94a3b8; font-weight: 600; text-transform: uppercase; }
  
  .list-actions { display: flex; gap: 0.5rem; align-items: center; }
  .btn-icon { width: 32px; height: 32px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; border: 1px solid #cbd5e1; background: #fff; color: #475569; cursor: pointer; transition: all 0.15s; }
  .btn-icon:hover { background: #f8fafc; color: #2563eb; border-color: #3b82f6; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>Operating Expenses</h1>
      <p>Record and track your operational spending.</p>
    </div>
    <div class="d-flex gap-2">
      <?php if (has_permission('expense.create')): ?>
        <button class="btn btn-primary fw-bold px-3" data-bs-toggle="modal" data-bs-target="#expenseModal" onclick="openExpense(null)" style="border-radius: 8px;">
          <i class="fa-solid fa-plus me-1"></i> Add Expense
        </button>
      <?php endif; ?>
    </div>
  </div>

  <div class="d-flex justify-content-between align-items-end mb-3 flex-wrap gap-2">
    <form class="filter-form m-0" method="get">
      <input type="date" name="from" value="<?= e($from) ?>">
      <input type="date" name="to" value="<?= e($to) ?>">
      <select name="branch" onchange="this.form.submit()">
        <option value="0">All branches</option>
        <?php foreach ($allBranches as $b): ?>
          <option value="<?= (int)$b['id'] ?>" <?= $branchFilter === (int)$b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="btn btn-sm btn-dark">Filter</button>
    </form>
    <div class="text-end">
      <div class="text-muted small fw-bold text-uppercase">Total in range</div>
      <div class="fs-4 fw-bolder text-danger"><?= money($totalAmount) ?></div>
    </div>
  </div>

  <div class="list-panel">
    <?php if (!$expenses): ?>
      <div class="text-center py-5">
        <i class="fa-solid fa-wallet text-muted mb-3" style="font-size: 3rem; opacity: 0.3;"></i>
        <h5 class="fw-bold text-dark">No expenses found</h5>
        <p class="text-muted small">There are no expenses recorded for this period.</p>
      </div>
    <?php else: foreach ($expenses as $e): ?>
      <div class="list-item">
        <div class="list-icon"><i class="fa-solid fa-receipt"></i></div>
        
        <div class="list-content">
          <div class="list-title"><?= e($e['description']) ?></div>
          <div class="list-sub">
            <span><i class="fa-regular fa-calendar me-1"></i><?= human_date($e['expense_date']) ?></span>
            <span class="text-muted">•</span>
            <span><i class="fa-solid fa-store me-1"></i><?= e($e['branch_name']) ?></span>
            <span class="text-muted">•</span>
            <span><i class="fa-solid fa-tag me-1"></i><?= e($e['category_name'] ?: 'Uncategorized') ?></span>
          </div>
        </div>

        <div class="list-meta">
          <div class="meta-item">
            <div class="meta-val"><?= money((float)$e['amount']) ?></div>
            <div class="meta-lbl"><?= e(str_replace('_', ' ', $e['method'])) ?></div>
          </div>
        </div>

        <div class="list-actions">
          <?php if (has_permission('expense.create')): ?>
            <button class="btn-icon" onclick='openExpense(<?= json_encode([
                'id' => (int)$e['id'], 'branch_id' => (int)$e['branch_id'],
                'category_id' => (int)$e['category_id'], 'description' => $e['description'],
                'amount' => (float)$e['amount'], 'expense_date' => $e['expense_date'], 'method' => $e['method'],
            ], JSON_HEX_APOS | JSON_HEX_QUOT) ?>)' title="Edit Expense">
              <i class="fa-solid fa-pen"></i>
            </button>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<?php if (has_permission('expense.create')): ?>
<div class="modal fade" id="expenseModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" id="exId" value="0">
      <div class="modal-header">
        <h5 class="modal-title" id="exTitle">Add Expense</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Branch</label>
            <select name="branch_id" id="exBranch" class="form-select" required>
              <?php foreach ($allBranches as $b): ?>
                <option value="<?= (int)$b['id'] ?>"><?= e($b['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label">Category</label>
            <select name="category_id" id="exCategory" class="form-select">
              <option value="0">— None —</option>
              <?php foreach ($categories as $c): ?>
                <option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-12">
            <label class="form-label">Description</label>
            <input type="text" name="description" id="exDesc" class="form-control" required>
          </div>
          <div class="col-md-4">
            <label class="form-label">Amount</label>
            <input type="number" step="0.01" min="0.01" name="amount" id="exAmount" class="form-control" required>
          </div>
          <div class="col-md-4">
            <label class="form-label">Date</label>
            <input type="date" name="expense_date" id="exDate" class="form-control" value="<?= date('Y-m-d') ?>" required>
          </div>
          <div class="col-md-4">
            <label class="form-label">Method</label>
            <select name="method" id="exMethod" class="form-select">
              <option value="cash">Cash</option>
              <option value="mobile_money">Mobile Money</option>
              <option value="bank">Bank</option>
              <option value="other">Other</option>
            </select>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary">Save Expense</button>
      </div>
    </form>
  </div>
</div>
<script>
function openExpense(e) {
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = v ?? ''; };
  document.getElementById('exId').value = e ? e.id : 0;
  document.getElementById('exTitle').textContent = e ? 'Edit Expense' : 'Add Expense';
  set('exBranch',   e ? e.branch_id   : <?= (int)($allBranches[0]['id'] ?? 0) ?>);
  set('exCategory', e ? e.category_id : 0);
  set('exDesc',     e ? e.description : '');
  set('exAmount',   e ? e.amount      : '');
  set('exDate',     e ? e.expense_date: '<?= date('Y-m-d') ?>');
  set('exMethod',   e ? e.method      : 'cash');
  new bootstrap.Modal(document.getElementById('expenseModal')).show();
}
</script>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>