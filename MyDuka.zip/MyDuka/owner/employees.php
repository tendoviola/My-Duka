<?php
// owner/employees.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/mailer.php';
require_role('owner');
require_permission('employee.view');

$pdo        = db();
$businessId = user_business_id();
$userId     = (int)current_user()['id'];
$businessName = current_user()['business_name'] ?? APP_NAME;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post('action');

    if ($action === 'create') {
        require_permission('employee.manage');
        $fullName = post('full_name');
        $email    = post('email');
        $phone    = post('phone');
        $password = post('password');
        $branchIds = array_values(array_unique(array_map('intval', (array)($_POST['branches'] ?? []))));
        $grantCodes  = array_map('strval', (array)($_POST['grant']  ?? []));
        $revokeCodes = array_map('strval', (array)($_POST['revoke'] ?? []));

        $errors = [];
        if ($fullName === '')      $errors[] = 'Full name is required.';
        if (!valid_email($email))  $errors[] = 'Valid email is required.';
        if (!valid_phone($phone))  $errors[] = 'Valid phone number is required.';
        if (strlen($password) < PASSWORD_MIN_LEN) $errors[] = 'Password must be at least '.PASSWORD_MIN_LEN.' characters.';
        if (!$branchIds)           $errors[] = 'Assign at least one branch.';

        if ($branchIds && !$errors) {
            $in = implode(',', array_fill(0, count($branchIds), '?'));
            $chk = $pdo->prepare("SELECT COUNT(*) FROM branches WHERE business_id = ? AND id IN ($in)");
            $chk->execute(array_merge([$businessId], $branchIds));
            if ((int)$chk->fetchColumn() !== count($branchIds)) $errors[] = 'One or more branches are invalid.';
        }
        if (!$errors) {
            $chk = $pdo->prepare("SELECT 1 FROM users WHERE email = ? LIMIT 1");
            $chk->execute([$email]);
            if ($chk->fetchColumn()) $errors[] = 'That email is already in use.';
        }

        if ($errors) {
            foreach ($errors as $er) flash('danger', $er);
        } else {
            try {
                $pdo->beginTransaction();
                $hash = password_hash($password, PASSWORD_DEFAULT);

                // Generate verification token
                $verificationToken = bin2hex(random_bytes(32));

                $pdo->prepare(
                    "INSERT INTO users
                        (role_id, business_id, created_by, full_name, email, phone, password_hash,
                         must_change_password, status, verification_token, email_verified_at)
                     VALUES (3, ?, ?, ?, ?, ?, ?, 1, 'active', ?, NULL)"
                )->execute([
                    $businessId, $userId, $fullName, $email, $phone, $hash, $verificationToken
                ]);
                $newId = (int)$pdo->lastInsertId();

                $bIns = $pdo->prepare("INSERT INTO user_branch_assignments (user_id, branch_id) VALUES (?, ?)");
                foreach ($branchIds as $bid) $bIns->execute([$newId, $bid]);

                if ($grantCodes || $revokeCodes) {
                    $pLookup = $pdo->query("SELECT id, code FROM permissions");
                    $byCode = [];
                    foreach ($pLookup->fetchAll() as $row) $byCode[$row['code']] = (int)$row['id'];
                    $upIns = $pdo->prepare("INSERT INTO user_permissions (user_id, permission_id, granted) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE granted = VALUES(granted)");
                    foreach ($grantCodes  as $c) if (isset($byCode[$c])) $upIns->execute([$newId, $byCode[$c], 1]);
                    foreach ($revokeCodes as $c) if (isset($byCode[$c])) $upIns->execute([$newId, $byCode[$c], 0]);
                }

                audit_log('employee.create', 'users', $newId, ['email' => $email], null);
                $pdo->commit();

                // Send verification email
                $verifyUrl = APP_URL . '/verify_email.php?token=' . $verificationToken;
                $htmlBody = "
                    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 30px; background: #f8fafc; border-radius: 12px;'>
                        <h2 style='color: #0f172a;'>Welcome to " . htmlspecialchars($businessName) . ", " . htmlspecialchars($fullName) . "!</h2>
                        <p style='color: #475569; font-size: 15px; line-height: 1.6;'>Your employer has created an account for you on <strong>My Duka</strong>.</p>
                        <p style='color: #475569; font-size: 15px; line-height: 1.6;'>To activate your account, please verify your email by clicking the button below.</p>
                        <div style='text-align: center; margin: 30px 0;'>
                            <a href='$verifyUrl' style='background: #2563eb; color: #fff; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;'>Verify My Email</a>
                        </div>
                        <p style='color: #94a3b8; font-size: 13px;'>If the button doesn't work, copy this link into your browser:<br><a href='$verifyUrl' style='color: #2563eb;'>$verifyUrl</a></p>
                        <div style='background: #eff6ff; border: 1px solid #bfdbfe; padding: 15px; border-radius: 8px; margin-top: 20px;'>
                            <strong style='color: #1e40af;'>Your temporary password:</strong>
                            <p style='color: #1e40af; font-size: 16px; font-weight: bold; margin: 5px 0 0 0; font-family: monospace;'>" . htmlspecialchars($password) . "</p>
                            <p style='color: #1e40af; font-size: 12px; margin: 5px 0 0 0;'>You will be asked to change this on your first login.</p>
                        </div>
                        <hr style='border: none; border-top: 1px solid #e2e8f0; margin: 20px 0;'>
                        <p style='color: #94a3b8; font-size: 12px; text-align: center;'>&copy; " . date('Y') . " My Duka. All rights reserved.</p>
                    </div>
                ";

                try {
                    send_email($email, $fullName, 'Verify Your Account · ' . $businessName, $htmlBody);
                    flash('success', 'Employee created. A verification email has been sent to ' . e($email) . '.');
                } catch (Throwable $ex) {
                    error_log("Verification email failed for {$email}: " . $ex->getMessage());
                    flash('warning', 'Employee created, but the verification email could not be sent. Please ask them to use "Forgot Password" to set their password.');
                }
            } catch (Throwable $ex) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Failed to create employee.');
            }
        }
        redirect('employees.php');
    }

    if ($action === 'toggle') {
        require_permission('employee.manage');
        $targetId = post_int('id');
        $chk = $pdo->prepare("SELECT status FROM users WHERE id = ? AND business_id = ? AND role_id = 3");
        $chk->execute([$targetId, $businessId]);
        $cur = $chk->fetchColumn();
        if ($cur) {
            $new = $cur === 'active' ? 'inactive' : 'active';
            $pdo->prepare("UPDATE users SET status = ? WHERE id = ?")->execute([$new, $targetId]);
            audit_log('employee.status', 'users', $targetId, ['new_status' => $new]);
            flash('success', "Employee set to {$new}.");
        }
        redirect('employees.php');
    }

    if ($action === 'reset_password') {
        require_permission('employee.manage');
        $targetId = post_int('id');
        $chk = $pdo->prepare("SELECT full_name, email FROM users WHERE id = ? AND business_id = ? AND role_id = 3");
        $chk->execute([$targetId, $businessId]);
        $emp = $chk->fetch();
        if ($emp) {
            $temp = bin2hex(random_bytes(4));
            $hash = password_hash($temp, PASSWORD_DEFAULT);
            $pdo->prepare("UPDATE users SET password_hash = ?, must_change_password = 1 WHERE id = ?")->execute([$hash, $targetId]);
            audit_log('employee.reset_password', 'users', $targetId);

            // Also send reset password email
            $htmlBody = "
                <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 30px; background: #f8fafc; border-radius: 12px;'>
                    <h2 style='color: #0f172a;'>Password Reset</h2>
                    <p style='color: #475569; font-size: 15px; line-height: 1.6;'>Your employer has reset your password for <strong>My Duka</strong>.</p>
                    <div style='background: #eff6ff; border: 1px solid #bfdbfe; padding: 15px; border-radius: 8px; margin-top: 20px;'>
                        <strong style='color: #1e40af;'>Your new temporary password:</strong>
                        <p style='color: #1e40af; font-size: 16px; font-weight: bold; margin: 5px 0 0 0; font-family: monospace;'>" . htmlspecialchars($temp) . "</p>
                        <p style='color: #1e40af; font-size: 12px; margin: 5px 0 0 0;'>Please login and change this immediately.</p>
                    </div>
                </div>
            ";
            try {
                send_email($emp['email'], $emp['full_name'], 'Password Reset · My Duka', $htmlBody);
            } catch (Throwable $ex) {
                error_log("Reset password email failed for {$emp['email']}: " . $ex->getMessage());
            }

            flash('warning', "Temporary password: <strong>" . e($temp) . "</strong> — share it securely.");
        }
        redirect('employees.php');
    }

    if ($action === 'save_perms') {
        require_permission('employee.manage');
        $targetId  = post_int('id');
        $chk = $pdo->prepare("SELECT 1 FROM users WHERE id = ? AND business_id = ? AND role_id = 3");
        $chk->execute([$targetId, $businessId]);
        if (!$chk->fetchColumn()) { flash('danger', 'Employee not found.'); redirect('employees.php'); }

        $grants  = array_map('strval', (array)($_POST['perm'] ?? []));
        $revokes = array_map('strval', (array)($_POST['revoke'] ?? []));

        try {
            $pdo->beginTransaction();
            $pdo->prepare("DELETE FROM user_permissions WHERE user_id = ?")->execute([$targetId]);
            $byCode = [];
            foreach ($pdo->query("SELECT id, code FROM permissions")->fetchAll() as $row) $byCode[$row['code']] = (int)$row['id'];
            $ins = $pdo->prepare("INSERT INTO user_permissions (user_id, permission_id, granted) VALUES (?, ?, ?)");
            foreach ($grants  as $c) if (isset($byCode[$c])) $ins->execute([$targetId, $byCode[$c], 1]);
            foreach ($revokes as $c) if (isset($byCode[$c])) $ins->execute([$targetId, $byCode[$c], 0]);
            audit_log('employee.permissions', 'users', $targetId);
            $pdo->commit();
            flash('success', 'Permissions updated.');
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Could not update permissions.');
        }
        redirect('employees.php');
    }
    redirect('employees.php');
}

$branches = $pdo->prepare("SELECT id, name FROM branches WHERE business_id = ? AND status='active' ORDER BY is_main DESC, name");
$branches->execute([$businessId]);
$branches = $branches->fetchAll();

$employees = $pdo->prepare(
    "SELECT u.id, u.full_name, u.email, u.phone, u.status, u.last_login_at, u.created_at, u.email_verified_at,
            GROUP_CONCAT(DISTINCT b.name ORDER BY b.name SEPARATOR ', ') AS branches,
            COUNT(DISTINCT up.permission_id) AS override_count
     FROM users u
     LEFT JOIN user_branch_assignments uba ON uba.user_id = u.id
     LEFT JOIN branches b ON b.id = uba.branch_id
     LEFT JOIN user_permissions up ON up.user_id = u.id
     WHERE u.business_id = ? AND u.role_id = 3 GROUP BY u.id ORDER BY u.created_at DESC"
);
$employees->execute([$businessId]);
$employees = $employees->fetchAll();

$allPermissions = $pdo->query("SELECT code, description FROM permissions ORDER BY code")->fetchAll();

$overrides = [];
if ($employees) {
    $ids = array_column($employees, 'id');
    $in  = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("SELECT up.user_id, p.code, up.granted FROM user_permissions up JOIN permissions p ON p.id = up.permission_id WHERE up.user_id IN ($in)");
    $stmt->execute($ids);
    foreach ($stmt->fetchAll() as $row) $overrides[(int)$row['user_id']][$row['code']] = (int)$row['granted'];
}

$groupedPerms = [];
foreach ($allPermissions as $p) {
    $group = explode('.', $p['code'])[0];
    $groupedPerms[$group][] = $p;
}

$pageTitle = 'Employees';
$breadcrumbs = ['Dashboard' => APP_URL . '/owner/dashboard.php', 'Employees' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; }
  
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }

  .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
  .stat-box { background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 1.25rem; display: flex; align-items: center; gap: 1rem; box-shadow: 0 2px 4px -1px rgba(0,0,0,0.02); }
  .stat-icon { width: 44px; height: 44px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; }
  .stat-info .val { font-size: 1.4rem; font-weight: 800; color: #0f172a; line-height: 1.1; }
  .stat-info .lbl { font-size: 0.75rem; font-weight: 600; color: #64748b; text-transform: uppercase; letter-spacing: 0.05em; }

  .data-panel { background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
  .table { margin-bottom: 0; }
  .table th { background: #f8fafc; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b; border-bottom: 1px solid #e2e8f0; padding: 0.85rem 1.25rem; }
  .table td { padding: 1rem 1.25rem; vertical-align: middle; border-bottom: 1px solid #f1f5f9; }
  .table tr:last-child td { border-bottom: none; }
  .table tr:hover td { background: #f8fafc; }

  .avatar { width: 40px; height: 40px; border-radius: 50%; background: #eff6ff; color: #2563eb; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 0.9rem; }

  .action-btn { width: 32px; height: 32px; border-radius: 6px; border: 1px solid transparent; background: transparent; color: #64748b; display: inline-flex; align-items: center; justify-content: center; transition: all 0.15s; }
  .action-btn:hover { background: #f1f5f9; border-color: #cbd5e1; color: #0f172a; }
  .dropdown-menu { border-radius: 10px; border: 1px solid #e2e8f0; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1); padding: 0.5rem; }
  .dropdown-item { font-size: 0.85rem; font-weight: 500; color: #334155; border-radius: 6px; padding: 0.5rem 0.75rem; }
  .dropdown-item:hover { background: #f8fafc; color: #0f172a; }

  .perm-group-title { font-size: 0.75rem; font-weight: 800; text-transform: uppercase; color: #94a3b8; letter-spacing: 0.05em; margin-top: 1rem; margin-bottom: 0.5rem; }
  .perm-list { display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem; }
  .perm-item { display: flex; align-items: center; justify-content: space-between; padding: 0.5rem 0.75rem; background: #f8fafc; border-radius: 8px; border: 1px solid #e2e8f0; }
  .perm-name { font-size: 0.8rem; font-weight: 600; color: #0f172a; }

  .verify-badge {
    display: inline-flex; align-items: center; gap: 4px;
    font-size: 0.65rem; font-weight: 700; padding: 2px 6px;
    border-radius: 4px; margin-left: 6px;
  }
  .verify-badge.pending { background: #fef3c7; color: #92400e; }
  .verify-badge.verified { background: #dcfce7; color: #166534; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>Team Management</h1>
      <p>Manage staff access, branches, and system permissions.</p>
    </div>
    <?php if (has_permission('employee.manage')): ?>
      <button class="btn btn-primary fw-bold px-3" data-bs-toggle="modal" data-bs-target="#addEmployeeModal" style="border-radius: 8px;">
        <i class="fa-solid fa-plus me-1"></i> Add Staff
      </button>
    <?php endif; ?>
  </div>

  <div class="stats-grid">
    <div class="stat-box">
      <div class="stat-icon" style="background:#eff6ff; color:#2563eb;"><i class="fa-solid fa-users"></i></div>
      <div class="stat-info">
        <div class="val"><?= count($employees) ?></div>
        <div class="lbl">Total Staff</div>
      </div>
    </div>
    <div class="stat-box">
      <div class="stat-icon" style="background:#f0fdf4; color:#16a34a;"><i class="fa-solid fa-user-check"></i></div>
      <div class="stat-info">
        <div class="val"><?= count(array_filter($employees, fn($e) => $e['status']==='active')) ?></div>
        <div class="lbl">Active Now</div>
      </div>
    </div>
    <div class="stat-box">
      <div class="stat-icon" style="background:#fef3c7; color:#d97706;"><i class="fa-solid fa-envelope-circle-check"></i></div>
      <div class="stat-info">
        <div class="val"><?= count(array_filter($employees, fn($e) => empty($e['email_verified_at']))) ?></div>
        <div class="lbl">Pending Verification</div>
      </div>
    </div>
  </div>

  <div class="data-panel">
    <div class="table-responsive">
      <table class="table table-hover">
        <thead>
          <tr>
            <th>Employee</th>
            <th>Contact</th>
            <th>Branches</th>
            <th>Status</th>
            <th class="text-end">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!$employees): ?>
            <tr><td colspan="5" class="text-center py-5 text-muted">No employees found.</td></tr>
          <?php else: foreach ($employees as $emp): ?>
            <?php 
              $initials = '';
              foreach (array_slice(explode(' ', $emp['full_name']), 0, 2) as $part) {
                  $initials .= mb_strtoupper(mb_substr($part, 0, 1));
              }
              $isVerified = !empty($emp['email_verified_at']);
            ?>
            <tr>
              <td>
                <div class="d-flex align-items-center gap-3">
                  <div class="avatar"><?= e($initials) ?></div>
                  <div>
                    <div class="fw-bold text-dark" style="font-size: 0.9rem;">
                      <?= e($emp['full_name']) ?>
                      <span class="verify-badge <?= $isVerified ? 'verified' : 'pending' ?>">
                        <i class="fa-solid <?= $isVerified ? 'fa-check-circle' : 'fa-clock' ?>"></i>
                        <?= $isVerified ? 'Verified' : 'Pending' ?>
                      </span>
                    </div>
                    <div class="text-muted small"><?= $emp['last_login_at'] ? 'Last seen ' . human_date($emp['last_login_at']) : 'Never logged in' ?></div>
                  </div>
                </div>
              </td>
              <td>
                <div class="text-dark" style="font-size: 0.85rem;"><?= e($emp['email']) ?></div>
                <div class="text-muted small"><?= e($emp['phone']) ?></div>
              </td>
              <td>
                <div class="text-dark" style="font-size: 0.85rem; max-width: 200px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="<?= e($emp['branches']) ?>">
                  <?= e($emp['branches'] ?: 'None assigned') ?>
                </div>
              </td>
              <td>
                <?php if ($emp['status'] === 'active'): ?>
                  <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill">Active</span>
                <?php else: ?>
                  <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle rounded-pill">Inactive</span>
                <?php endif; ?>
              </td>
              <td class="text-end">
                <?php if (has_permission('employee.manage')): ?>
                  <div class="dropdown">
                    <button class="action-btn" data-bs-toggle="dropdown"><i class="fa-solid fa-ellipsis-vertical"></i></button>
                    <ul class="dropdown-menu dropdown-menu-end">
                      <li><button class="dropdown-item" data-bs-toggle="modal" data-bs-target="#permsModal" onclick='openPerms(<?= (int)$emp['id'] ?>, <?= json_encode($emp['full_name']) ?>)'><i class="fa-solid fa-shield-halved me-2 text-muted"></i>Permissions</button></li>
                      <li><hr class="dropdown-divider"></li>
                      <li>
                        <form method="post" class="m-0" onsubmit="return confirm('Toggle this employee\'s status?');">
                          <?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$emp['id'] ?>">
                          <button type="submit" class="dropdown-item"><i class="fa-solid fa-power-off me-2 text-muted"></i><?= $emp['status']==='active' ? 'Deactivate' : 'Activate' ?></button>
                        </form>
                      </li>
                      <li>
                        <form method="post" class="m-0" onsubmit="return confirm('Reset this employee\'s password? An email will be sent.');">
                          <?= csrf_field() ?><input type="hidden" name="action" value="reset_password"><input type="hidden" name="id" value="<?= (int)$emp['id'] ?>">
                          <button type="submit" class="dropdown-item text-warning"><i class="fa-solid fa-key me-2"></i>Reset Password</button>
                        </form>
                      </li>
                    </ul>
                  </div>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php if (has_permission('employee.manage')): ?>
<!-- Add Employee Modal -->
<div class="modal fade" id="addEmployeeModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <form class="modal-content" method="post">
      <?= csrf_field() ?><input type="hidden" name="action" value="create">
      <div class="modal-header border-0 pb-0"><h5 class="modal-title fw-bold">Add New Employee</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body pt-3">
        <div class="alert alert-info border-0 shadow-sm small mb-4">
          <i class="fa-solid fa-envelope-circle-check me-2"></i> The employee will receive a verification email. They must verify their email before they can log in.
        </div>
        <div class="row g-3">
          <div class="col-md-6"><label class="form-label">Full name</label><input type="text" name="full_name" class="form-control" required></div>
          <div class="col-md-6"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control" placeholder="+256..." required></div>
          <div class="col-md-6"><label class="form-label">Email</label><input type="email" name="email" class="form-control" required></div>
          <div class="col-md-6"><label class="form-label">Temp Password</label><input type="text" name="password" class="form-control" minlength="<?= PASSWORD_MIN_LEN ?>" required></div>
          <div class="col-12 mt-4">
            <label class="form-label fw-bold">Branch Access</label>
            <div class="d-flex flex-wrap gap-3 p-3 bg-light rounded-3 border">
              <?php foreach ($branches as $b): ?>
                <div class="form-check"><input class="form-check-input" type="checkbox" name="branches[]" id="br<?= (int)$b['id'] ?>" value="<?= (int)$b['id'] ?>"><label class="form-check-label fw-semibold" for="br<?= (int)$b['id'] ?>"><?= e($b['name']) ?></label></div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer border-0 pt-0"><button type="button" class="btn btn-light fw-bold" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary fw-bold">Create Employee</button></div>
    </form>
  </div>
</div>

<!-- Permissions Modal -->
<div class="modal fade" id="permsModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <form class="modal-content" method="post">
      <?= csrf_field() ?><input type="hidden" name="action" value="save_perms"><input type="hidden" name="id" id="permEmpId">
      <div class="modal-header border-0 pb-0"><h5 class="modal-title fw-bold">Permissions <span id="permEmpName" class="text-primary"></span></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body pt-3">
        <div class="alert alert-info border-0 shadow-sm small mb-4">
          <i class="fa-solid fa-circle-info me-2"></i> Check to <strong>grant</strong> access, or check "Deny" to explicitly block a specific feature.
        </div>
        
        <?php foreach ($groupedPerms as $group => $perms): ?>
          <div class="perm-group-title"><?= e(ucfirst($group)) ?></div>
          <div class="perm-list">
            <?php foreach ($perms as $p): ?>
              <div class="perm-item" data-code="<?= e($p['code']) ?>">
                <div>
                  <div class="perm-name"><?= e($p['code']) ?></div>
                </div>
                <div class="d-flex gap-3 pe-1">
                  <div class="form-check m-0" title="Grant Access">
                    <input class="form-check-input" type="checkbox" name="perm[]" value="<?= e($p['code']) ?>" data-role="grant" id="grant_<?= e($p['code']) ?>">
                  </div>
                  <div class="form-check m-0" title="Explicitly Deny">
                    <input class="form-check-input" type="checkbox" name="revoke[]" value="<?= e($p['code']) ?>" data-role="revoke" id="revoke_<?= e($p['code']) ?>" style="background-color: #fee2e2; border-color: #fca5a5;">
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endforeach; ?>
        
      </div>
      <div class="modal-footer border-0 pt-0"><button type="button" class="btn btn-light fw-bold" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary fw-bold">Save Permissions</button></div>
    </form>
  </div>
</div>

<script>
  const __RP_OVERRIDES__ = <?= json_encode($overrides) ?>;
  function openPerms(empId, empName) {
    document.getElementById('permEmpId').value = empId;
    document.getElementById('permEmpName').textContent = '· ' + empName;
    document.querySelectorAll('#permsModal .perm-item').forEach(item => {
      const code = item.dataset.code;
      const grant  = item.querySelector('input[data-role="grant"]');
      const revoke = item.querySelector('input[data-role="revoke"]');
      grant.checked = revoke.checked = false;
      const ov = __RP_OVERRIDES__[empId] && __RP_OVERRIDES__[empId][code];
      if (ov === 1) grant.checked = true;
      if (ov === 0) revoke.checked = true;
    });
    new bootstrap.Modal(document.getElementById('permsModal')).show();
  }
  document.querySelectorAll('#permsModal input[data-role]').forEach(cb => {
    cb.addEventListener('change', function () {
      if (this.checked) {
        const item = this.closest('.perm-item');
        const other = item.querySelector(this.dataset.role === 'grant' ? 'input[data-role="revoke"]' : 'input[data-role="grant"]');
        other.checked = false;
      }
    });
  });
</script>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>