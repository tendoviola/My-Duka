<?php
// owner/transfers.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/stock.php';
require_role('owner');
require_permission('transfer.view');

$pdo        = db();
$businessId = user_business_id();
$userId     = (int)current_user()['id'];
$branches   = user_branch_ids();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post('action');

    if ($action === 'create') {
        require_permission('transfer.create');
        $from    = post_int('from_branch_id');
        $to      = post_int('to_branch_id');
        $notes   = post('notes');
        $items   = (array)($_POST['item_product'] ?? []);
        $qtys    = (array)($_POST['item_qty'] ?? []);

        $errors = [];
        if (!in_array($from, $branches, true)) $errors[] = 'Invalid source branch.';
        if (!in_array($to, $branches, true))   $errors[] = 'Invalid destination branch.';
        if ($from === $to)                     $errors[] = 'Source and destination must differ.';

        $lines = [];
        for ($i = 0; $i < count($items); $i++) {
            $pid = (int)$items[$i];
            $qty = (float)($qtys[$i] ?? 0);
            if ($pid <= 0 || $qty <= 0) continue;
            $chk = $pdo->prepare("SELECT 1 FROM products WHERE id = ? AND business_id = ? AND status='active'");
            $chk->execute([$pid, $businessId]);
            if (!$chk->fetchColumn()) $errors[] = "Invalid product #{$pid}.";
            $lines[] = ['product_id' => $pid, 'quantity' => $qty];
        }
        if (!$lines) $errors[] = 'Add at least one product.';

        if ($errors) {
            foreach ($errors as $e) flash('danger', $e);
        } else {
            try {
                $pdo->beginTransaction();
                $number = generate_number('TRF', 'stock_transfers', 'transfer_number', $businessId);
                $pdo->prepare("INSERT INTO stock_transfers (business_id, transfer_number, from_branch_id, to_branch_id, notes, initiated_by) VALUES (?, ?, ?, ?, ?, ?)")
                    ->execute([$businessId, $number, $from, $to, $notes ?: null, $userId]);
                $tid = (int)$pdo->lastInsertId();

                $ins = $pdo->prepare("INSERT INTO stock_transfer_items (transfer_id, product_id, quantity) VALUES (?, ?, ?)");
                foreach ($lines as $l) $ins->execute([$tid, $l['product_id'], $l['quantity']]);

                audit_log('transfer.create', 'stock_transfers', $tid, ['number' => $number], $from);
                $pdo->commit();
                flash('success', "Transfer {$number} created.");
            } catch (Throwable $ex) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Could not create transfer.');
            }
        }
        redirect('transfers.php?' . http_build_query($_GET));
    }

    if ($action === 'dispatch') {
        require_permission('transfer.create');
        $tid = post_int('id');
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("SELECT * FROM stock_transfers WHERE id = ? AND business_id = ? FOR UPDATE");
            $stmt->execute([$tid, $businessId]);
            $tr = $stmt->fetch();
            if (!$tr) throw new RuntimeException('Transfer not found.');
            if ($tr['status'] !== 'pending') throw new RuntimeException('Only pending transfers can be dispatched.');

            $items = $pdo->prepare("SELECT * FROM stock_transfer_items WHERE transfer_id = ?");
            $items->execute([$tid]);
            foreach ($items->fetchAll() as $it) {
                apply_stock_change($pdo, $businessId, (int)$tr['from_branch_id'], (int)$it['product_id'], -(float)$it['quantity'], 'transfer_out', null, 'stock_transfers', $tid, "Transfer {$tr['transfer_number']} dispatched", $userId);
            }

            $pdo->prepare("UPDATE stock_transfers SET status = 'dispatched', dispatched_at = NOW() WHERE id = ?")->execute([$tid]);
            audit_log('transfer.dispatch', 'stock_transfers', $tid, null, (int)$tr['from_branch_id']);
            $pdo->commit();
            flash('success', 'Transfer dispatched.');
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Could not dispatch.');
        }
        redirect('transfers.php?' . http_build_query($_GET));
    }

    if ($action === 'receive') {
        require_permission('transfer.receive');
        $tid = post_int('id');
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("SELECT * FROM stock_transfers WHERE id = ? AND business_id = ? FOR UPDATE");
            $stmt->execute([$tid, $businessId]);
            $tr = $stmt->fetch();
            if (!$tr) throw new RuntimeException('Transfer not found.');
            if ($tr['status'] !== 'dispatched') throw new RuntimeException('Only dispatched transfers can be received.');

            $items = $pdo->prepare("SELECT * FROM stock_transfer_items WHERE transfer_id = ?");
            $items->execute([$tid]);
            foreach ($items->fetchAll() as $it) {
                apply_stock_change($pdo, $businessId, (int)$tr['to_branch_id'], (int)$it['product_id'], +(float)$it['quantity'], 'transfer_in', null, 'stock_transfers', $tid, "Transfer {$tr['transfer_number']} received", $userId);
            }

            $pdo->prepare("UPDATE stock_transfers SET status = 'received', received_at = NOW(), received_by = ? WHERE id = ?")->execute([$userId, $tid]);
            audit_log('transfer.receive', 'stock_transfers', $tid, null, (int)$tr['to_branch_id']);
            $pdo->commit();
            flash('success', 'Transfer received.');
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Could not receive.');
        }
        redirect('transfers.php?' . http_build_query($_GET));
    }

    if ($action === 'cancel') {
        require_permission('transfer.create');
        $tid = post_int('id');
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("SELECT * FROM stock_transfers WHERE id = ? AND business_id = ? FOR UPDATE");
            $stmt->execute([$tid, $businessId]);
            $tr = $stmt->fetch();
            if (!$tr) throw new RuntimeException('Transfer not found.');
            if ($tr['status'] === 'received') throw new RuntimeException('Received transfers cannot be cancelled.');
            if ($tr['status'] === 'cancelled') throw new RuntimeException('Already cancelled.');

            if ($tr['status'] === 'dispatched') {
                $items = $pdo->prepare("SELECT * FROM stock_transfer_items WHERE transfer_id = ?");
                $items->execute([$tid]);
                foreach ($items->fetchAll() as $it) {
                    apply_stock_change($pdo, $businessId, (int)$tr['from_branch_id'], (int)$it['product_id'], +(float)$it['quantity'], 'adjustment', null, 'stock_transfers', $tid, "Reversal of cancelled transfer {$tr['transfer_number']}", $userId);
                }
            }

            $pdo->prepare("UPDATE stock_transfers SET status = 'cancelled' WHERE id = ?")->execute([$tid]);
            audit_log('transfer.cancel', 'stock_transfers', $tid);
            $pdo->commit();
            flash('success', 'Transfer cancelled.');
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Could not cancel.');
        }
        redirect('transfers.php?' . http_build_query($_GET));
    }
}

$statusFilter = get('status', '');
$where = "t.business_id = ?";
$params = [$businessId];
if (in_array($statusFilter, ['pending','dispatched','received','cancelled'], true)) {
    $where .= " AND t.status = ?";
    $params[] = $statusFilter;
}

$stmt = $pdo->prepare(
    "SELECT t.*, fb.name AS from_name, tb.name AS to_name, u.full_name AS initiator,
            (SELECT COUNT(*) FROM stock_transfer_items sti WHERE sti.transfer_id = t.id) AS item_count
     FROM stock_transfers t JOIN branches fb ON fb.id = t.from_branch_id JOIN branches tb ON tb.id = t.to_branch_id JOIN users u ON u.id = t.initiated_by
     WHERE {$where} ORDER BY t.created_at DESC LIMIT 100"
);
$stmt->execute($params);
$transfers = $stmt->fetchAll();

$allBranches = $pdo->prepare("SELECT id, name FROM branches WHERE business_id = ? AND status='active' ORDER BY is_main DESC, name");
$allBranches->execute([$businessId]);
$allBranches = $allBranches->fetchAll();

$products = $pdo->prepare("SELECT id, name, sku FROM products WHERE business_id = ? AND status='active' ORDER BY name");
$products->execute([$businessId]);
$products = $products->fetchAll();

$pageTitle = 'Stock Transfers';
$breadcrumbs = ['Dashboard' => APP_URL . '/owner/dashboard.php', 'Stock Transfers' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; }
  
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }

  .filter-form { display: flex; gap: 0.5rem; background: #fff; padding: 0.35rem; border-radius: 10px; border: 1px solid #cbd5e1; margin-bottom: 1rem; flex-wrap: wrap; align-items: center; }
  .filter-form input, .filter-form select { border: none; border-radius: 6px; padding: 0.35rem 0.5rem; font-size: 0.8rem; font-weight: 500; color: #0f172a; background: transparent; }
  .filter-form input:focus, .filter-form select:focus { outline: none; background: #f8fafc; }

  .list-panel { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
  .list-item { display: flex; align-items: center; padding: 1.25rem 1.5rem; border-bottom: 1px solid #f1f5f9; transition: background 0.15s; flex-wrap: wrap; gap: 1rem; }
  .list-item:last-child { border-bottom: none; }
  .list-item:hover { background: #f8fafc; }
  
  .list-icon { width: 44px; height: 44px; border-radius: 12px; background: #eff6ff; color: #2563eb; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0; }
  
  .list-content { flex: 1; min-width: 200px; }
  .list-title { font-weight: 700; font-size: 0.95rem; color: #0f172a; margin-bottom: 0.15rem; }
  .list-sub { font-size: 0.75rem; color: #64748b; font-weight: 500; display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap; }
  
  .branch-route { display: inline-flex; align-items: center; gap: 0.5rem; background: #f1f5f9; padding: 0.25rem 0.75rem; border-radius: 20px; font-weight: 600; color: #0f172a; font-size: 0.8rem; }
  
  .list-meta { display: flex; gap: 1.5rem; text-align: right; align-items: center; }
  .meta-item { text-align: right; }
  .meta-val { font-weight: 700; font-size: 0.9rem; color: #0f172a; }
  .meta-lbl { font-size: 0.65rem; color: #94a3b8; font-weight: 600; text-transform: uppercase; }
  
  .list-actions { display: flex; gap: 0.5rem; align-items: center; }
  .btn-action { padding: 0.35rem 0.75rem; font-size: 0.75rem; font-weight: 600; border-radius: 6px; border: 1px solid #cbd5e1; background: #fff; color: #475569; transition: all 0.15s; text-decoration: none; display: inline-flex; align-items: center; gap: 0.25rem; }
  .btn-action:hover { background: #f1f5f9; color: #0f172a; }
  .btn-action.primary { background: #2563eb; border-color: #2563eb; color: #fff; }
  .btn-action.primary:hover { background: #1d4ed8; }
  .btn-action.success { background: #16a34a; border-color: #16a34a; color: #fff; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>Stock Transfers</h1>
      <p>Move inventory between branches smoothly.</p>
    </div>
    <div class="d-flex gap-2">
      <form method="get">
        <select name="status" class="form-select form-select-sm fw-bold" onchange="this.form.submit()">
          <option value="">All Transfers</option>
          <option value="pending" <?= $statusFilter==='pending' ? 'selected':'' ?>>Pending</option>
          <option value="dispatched" <?= $statusFilter==='dispatched' ? 'selected':'' ?>>Dispatched</option>
          <option value="received" <?= $statusFilter==='received' ? 'selected':'' ?>>Received</option>
          <option value="cancelled" <?= $statusFilter==='cancelled' ? 'selected':'' ?>>Cancelled</option>
        </select>
      </form>
      <?php if (has_permission('transfer.create')): ?>
        <button class="btn btn-primary fw-bold px-3" data-bs-toggle="modal" data-bs-target="#createModal" style="border-radius: 8px;">
          <i class="fa-solid fa-plus me-1"></i> New Transfer
        </button>
      <?php endif; ?>
    </div>
  </div>

  <div class="list-panel">
    <?php if (!$transfers): ?>
      <div class="text-center py-5">
        <i class="fa-solid fa-right-left text-muted mb-3" style="font-size: 3rem; opacity: 0.3;"></i>
        <h5 class="fw-bold text-dark">No transfers found</h5>
        <p class="text-muted small">Create a new transfer to move stock.</p>
      </div>
    <?php else: foreach ($transfers as $t): ?>
      <?php
        $statusColors = ['pending'=>'bg-warning-subtle text-warning', 'dispatched'=>'bg-primary-subtle text-primary', 'received'=>'bg-success-subtle text-success', 'cancelled'=>'bg-secondary-subtle text-secondary'];
      ?>
      <div class="list-item">
        <div class="list-icon"><i class="fa-solid fa-truck-fast"></i></div>
        
        <div class="list-content">
          <div class="list-title">
            <?= e($t['transfer_number']) ?>
            <span class="badge <?= $statusColors[$t['status']] ?> ms-2" style="font-size:0.6rem; letter-spacing:0.05em;"><?= strtoupper($t['status']) ?></span>
          </div>
          <div class="list-sub">
            <div class="branch-route">
              <?= e($t['from_name']) ?> <i class="fa-solid fa-arrow-right text-muted" style="font-size:0.7rem;"></i> <?= e($t['to_name']) ?>
            </div>
            <span class="text-muted">•</span>
            <span><i class="fa-solid fa-box me-1"></i><?= (int)$t['item_count'] ?> items</span>
            <span class="text-muted">•</span>
            <span><i class="fa-solid fa-user me-1"></i><?= e($t['initiator']) ?></span>
          </div>
        </div>

        <div class="list-meta">
          <div class="meta-item">
            <div class="meta-val" style="font-size:0.8rem; font-weight:600;"><?= human_datetime($t['created_at']) ?></div>
            <div class="meta-lbl">Created</div>
          </div>
        </div>

        <div class="list-actions">
          <?php if ($t['status'] === 'pending' && has_permission('transfer.create')): ?>
            <form method="post" class="m-0" onsubmit="return confirm('Dispatch? Stock will leave source branch.');">
              <?= csrf_field() ?><input type="hidden" name="action" value="dispatch"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
              <button type="submit" class="btn-action primary">Dispatch</button>
            </form>
            <form method="post" class="m-0" onsubmit="return confirm('Cancel?');">
              <?= csrf_field() ?><input type="hidden" name="action" value="cancel"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
              <button type="submit" class="btn-action text-danger"><i class="fa-solid fa-xmark"></i></button>
            </form>
          <?php elseif ($t['status'] === 'dispatched' && has_permission('transfer.receive')): ?>
            <form method="post" class="m-0" onsubmit="return confirm('Receive? Stock will be added to destination.');">
              <?= csrf_field() ?><input type="hidden" name="action" value="receive"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
              <button type="submit" class="btn-action success">Receive</button>
            </form>
            <?php if (has_permission('transfer.create')): ?>
              <form method="post" class="m-0" onsubmit="return confirm('Cancel? Stock will return to source.');">
                <?= csrf_field() ?><input type="hidden" name="action" value="cancel"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
                <button type="submit" class="btn-action text-danger"><i class="fa-solid fa-xmark"></i></button>
              </form>
            <?php endif; ?>
          <?php else: ?>
            <span class="text-muted small">—</span>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<!-- Transfer Modal -->
<?php if (has_permission('transfer.create')): ?>
<div class="modal fade" id="createModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <form class="modal-content" method="post">
      <?= csrf_field() ?><input type="hidden" name="action" value="create">
      <div class="modal-header">
        <h5 class="modal-title">New Stock Transfer</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="row g-3 mb-3">
          <div class="col-md-5">
            <label class="form-label">From branch</label>
            <select name="from_branch_id" class="form-select" required>
              <?php foreach ($allBranches as $b): ?><option value="<?= (int)$b['id'] ?>"><?= e($b['name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-5">
            <label class="form-label">To branch</label>
            <select name="to_branch_id" class="form-select" required>
              <?php foreach ($allBranches as $b): ?><option value="<?= (int)$b['id'] ?>"><?= e($b['name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-2 d-flex align-items-end">
            <button type="button" class="btn btn-outline-primary w-100" onclick="addLine()"><i class="fa-solid fa-plus"></i></button>
          </div>
        </div>
        <table class="table align-middle">
          <thead><tr><th>Product</th><th style="width:140px">Quantity</th><th></th></tr></thead>
          <tbody id="transferLines"></tbody>
        </table>
        <div class="mt-2"><label class="form-label">Notes</label><textarea name="notes" class="form-control" rows="2"></textarea></div>
        <div class="alert alert-info small mt-3 mb-0">Creating a transfer does not move stock. Stock leaves source at <strong>Dispatch</strong> and arrives at <strong>Receive</strong>.</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary">Create Transfer</button>
      </div>
    </form>
  </div>
</div>
<script>
  window.__RP_TRANSFER_PRODUCTS__ = <?= json_encode(array_map(fn($p) => ['id' => (int)$p['id'], 'label' => $p['name'] . ' (' . $p['sku'] . ')'], $products), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
  (function () {
    const prods = window.__RP_TRANSFER_PRODUCTS__ || [];
    const box = document.getElementById('transferLines');
    window.addLine = function () {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td><select name="item_product[]" class="form-select form-select-sm" required><option value="">— Select product —</option>${prods.map(p => `<option value="${p.id}">${p.label}</option>`).join('')}</select></td>
        <td><input type="number" step="0.001" min="0.001" name="item_qty[]" class="form-control form-control-sm" required></td>
        <td><button type="button" class="btn btn-sm btn-outline-danger" onclick="this.closest('tr').remove();">&times;</button></td>
      `;
      box.appendChild(row);
    };
    addLine();
  })();
</script>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>