<?php
// owner/products.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/uploads.php';
require_role('owner');
require_permission('product.view');

$pdo        = db();
$businessId = user_business_id();

// ---- Actions ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post('action');

    // ---------- SAVE ----------
    if ($action === 'save') {
        require_permission('product.create');
        $id          = post_int('id');
        $name        = post('name');
        $sku         = post('sku');
        $barcode     = post('barcode');
        $categoryId  = post_int('category_id');
        $supplierId  = post_int('supplier_id');
        $unit        = post('unit') ?: 'pcs';
        $buying      = post_float('buying_price');
        $selling     = post_float('selling_price');
        $minStock    = post_float('min_stock_level');
        $description = post('description');

        $errors = [];
        if ($name === '')        $errors[] = 'Product name is required.';
        if ($sku === '')         $errors[] = 'SKU is required.';
        if ($buying < 0)         $errors[] = 'Buying price must be ≥ 0.';
        if ($selling < 0)        $errors[] = 'Selling price must be ≥ 0.';
        if ($selling < $buying)  $errors[] = 'Selling price should not be below buying price.';

        if (!$errors) {
            $dup = $pdo->prepare("SELECT id FROM products WHERE business_id = ? AND sku = ? AND id <> ? LIMIT 1");
            $dup->execute([$businessId, $sku, $id]);
            if ($dup->fetchColumn()) $errors[] = 'SKU already used in this business.';
        }
        if ($categoryId && !$errors) {
            $chk = $pdo->prepare("SELECT 1 FROM categories WHERE id = ? AND business_id = ?");
            $chk->execute([$categoryId, $businessId]);
            if (!$chk->fetchColumn()) $errors[] = 'Invalid category.';
        }
        if ($supplierId && !$errors) {
            $chk = $pdo->prepare("SELECT 1 FROM suppliers WHERE id = ? AND business_id = ?");
            $chk->execute([$supplierId, $businessId]);
            if (!$chk->fetchColumn()) $errors[] = 'Invalid supplier.';
        }

        $newImage = null;
        try {
            $newImage = handle_image_upload($_FILES['image'] ?? [], 'products');
        } catch (Throwable $ex) {
            $errors[] = $ex->getMessage();
        }

        if ($errors) {
            foreach ($errors as $e) flash('danger', $e);
        } else {
            try {
                $pdo->beginTransaction();
                if ($id > 0) {
                    $chk = $pdo->prepare("SELECT image_path FROM products WHERE id = ? AND business_id = ?");
                    $chk->execute([$id, $businessId]);
                    $current = $chk->fetch();
                    if (!$current) throw new RuntimeException('Product not found.');

                    $imgPath = $current['image_path'];
                    if ($newImage) {
                        delete_upload($imgPath);
                        $imgPath = $newImage;
                    }

                    $pdo->prepare(
                        "UPDATE products SET
                            category_id=?, supplier_id=?, name=?, sku=?, barcode=?,
                            description=?, image_path=?, unit=?,
                            buying_price=?, selling_price=?, min_stock_level=?
                         WHERE id=? AND business_id=?"
                    )->execute([
                        $categoryId ?: null, $supplierId ?: null,
                        $name, $sku, $barcode ?: null, $description ?: null,
                        $imgPath, $unit, $buying, $selling, $minStock,
                        $id, $businessId,
                    ]);
                    audit_log('product.update', 'products', $id, ['name' => $name, 'sku' => $sku]);
                    flash('success', 'Product updated.');
                } else {
                    $pdo->prepare(
                        "INSERT INTO products
                            (business_id, category_id, supplier_id, name, sku, barcode,
                             description, image_path, unit,
                             buying_price, selling_price, min_stock_level)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                    )->execute([
                        $businessId, $categoryId ?: null, $supplierId ?: null,
                        $name, $sku, $barcode ?: null, $description ?: null,
                        $newImage, $unit, $buying, $selling, $minStock,
                    ]);
                    $newId = (int)$pdo->lastInsertId();
                    audit_log('product.create', 'products', $newId, ['name' => $name, 'sku' => $sku]);
                    flash('success', 'Product created.');
                }
                $pdo->commit();
            } catch (Throwable $ex) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                if ($newImage) delete_upload($newImage);
                flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Could not save product.');
            }
        }
        redirect('products.php');
    }

    // ---------- ARCHIVE / RESTORE ----------
    if ($action === 'archive' || $action === 'restore') {
        require_permission('product.delete');
        $id = post_int('id');
        $newStatus = $action === 'archive' ? 'archived' : 'active';
        $chk = $pdo->prepare("SELECT 1 FROM products WHERE id = ? AND business_id = ?");
        $chk->execute([$id, $businessId]);
        if ($chk->fetchColumn()) {
            $pdo->prepare("UPDATE products SET status=? WHERE id = ?")->execute([$newStatus, $id]);
            audit_log("product.$action", 'products', $id);
            flash('success', "Product $action" . ($action === 'archive' ? 'd' : 'd') . ".");
        }
        redirect('products.php');
    }
}

// ---- Filters ----
$search   = get('q');
$catFilter = (int)get('category', 0);
$status    = get('status', 'active');
$page     = max(1, (int)get('page', 1));
$perPage  = 15;

$where  = "p.business_id = ?";
$params = [$businessId];
if ($status === 'active' || $status === 'archived') {
    $where .= " AND p.status = ?";
    $params[] = $status;
}
if ($catFilter > 0) {
    $where .= " AND p.category_id = ?";
    $params[] = $catFilter;
}
if ($search !== '') {
    $where .= " AND (p.name LIKE ? OR p.sku LIKE ? OR p.barcode LIKE ?)";
    $like = "%{$search}%";
    array_push($params, $like, $like, $like);
}

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM products p WHERE {$where}");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();
$pages = max(1, (int)ceil($total / $perPage));
$page  = min($page, $pages);
$offset = ($page - 1) * $perPage;

$stmt = $pdo->prepare(
    "SELECT p.*, c.name AS category_name,
            COALESCE((SELECT SUM(inv.quantity) FROM inventory inv WHERE inv.product_id = p.id), 0) AS total_stock
     FROM products p
     LEFT JOIN categories c ON c.id = p.category_id
     WHERE {$where}
     ORDER BY p.name
     LIMIT {$perPage} OFFSET {$offset}"
);
$stmt->execute($params);
$products = $stmt->fetchAll();

$categories = $pdo->prepare("SELECT id, name FROM categories WHERE business_id = ? AND status='active' ORDER BY name");
$categories->execute([$businessId]);
$categories = $categories->fetchAll();

$suppliers = $pdo->prepare("SELECT id, name FROM suppliers WHERE business_id = ? AND status='active' ORDER BY name");
$suppliers->execute([$businessId]);
$suppliers = $suppliers->fetchAll();

$pageTitle = 'Products';
$breadcrumbs = ['Dashboard' => APP_URL . '/owner/dashboard.php', 'Products' => null];
$pageScripts = ['assets/js/products.js'];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; }
  
  /* Header */
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }
  
  /* Filter Form */
  .filter-form { display: flex; gap: 0.5rem; background: #fff; padding: 0.35rem; border-radius: 10px; border: 1px solid #cbd5e1; }
  .filter-form input, .filter-form select { border: none; border-radius: 6px; padding: 0.35rem 0.5rem; font-size: 0.8rem; font-weight: 500; color: #0f172a; background: transparent; }
  .filter-form input:focus, .filter-form select:focus { outline: none; background: #f8fafc; }
  
  /* Product Grid */
  .product-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 1rem; }
  
  .product-card {
    background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; padding: 1rem;
    display: flex; flex-direction: column; transition: all 0.2s ease;
  }
  .product-card:hover { box-shadow: 0 8px 20px -8px rgba(0,0,0,0.08); border-color: #cbd5e1; transform: translateY(-2px); }
  
  .product-img-wrap { width: 100%; height: 160px; background: #f8fafc; border-radius: 10px; overflow: hidden; margin-bottom: 1rem; display: flex; align-items: center; justify-content: center; position: relative; }
  .product-img-wrap img { width: 100%; height: 100%; object-fit: cover; }
  .product-img-wrap i { font-size: 2.5rem; color: #cbd5e1; }
  
  .product-title { font-weight: 700; font-size: 0.95rem; color: #0f172a; margin-bottom: 0.15rem; line-height: 1.2; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .product-sku { font-size: 0.7rem; font-weight: 600; color: #94a3b8; margin-bottom: 0.75rem; }
  
  .product-footer { margin-top: auto; display: flex; justify-content: space-between; align-items: center; border-top: 1px dashed #e2e8f0; padding-top: 0.75rem; }
  .product-price { font-size: 0.85rem; font-weight: 800; color: #2563eb; }
  .product-stock { font-size: 0.7rem; font-weight: 700; padding: 0.25rem 0.5rem; border-radius: 6px; }
  
  .badge-out { background: #fee2e2; color: #b91c1c; }
  .badge-low { background: #fef3c7; color: #b45309; }
  .badge-good { background: #dcfce7; color: #15803d; }

  /* Action Buttons overlay */
  .card-actions { position: absolute; top: 0.5rem; right: 0.5rem; display: flex; gap: 0.25rem; opacity: 0; transition: opacity 0.2s; }
  .product-card:hover .card-actions { opacity: 1; }
  .card-actions button { background: rgba(255,255,255,0.9); backdrop-filter: blur(4px); border: 1px solid #cbd5e1; border-radius: 6px; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; color: #475569; cursor: pointer; transition: all 0.15s; }
  .card-actions button:hover { background: #fff; color: #2563eb; border-color: #3b82f6; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>Product Catalog</h1>
      <p><?= number_format($total) ?> item<?= $total === 1 ? '' : 's' ?> in your inventory</p>
    </div>
    <div class="d-flex gap-2 flex-wrap">
      <form class="filter-form" method="get">
        <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search product...">
        <select name="category" onchange="this.form.submit()">
          <option value="0">All Categories</option>
          <?php foreach ($categories as $c): ?>
            <option value="<?= (int)$c['id'] ?>" <?= $catFilter === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
          <?php endforeach; ?>
        </select>
        <select name="status" onchange="this.form.submit()">
          <option value="active" <?= $status==='active' ? 'selected':'' ?>>Active</option>
          <option value="archived" <?= $status==='archived' ? 'selected':'' ?>>Archived</option>
          <option value="" <?= $status==='' ? 'selected':'' ?>>All</option>
        </select>
      </form>
      <?php if (has_permission('product.create')): ?>
        <button class="btn btn-primary fw-bold px-3" data-bs-toggle="modal" data-bs-target="#productModal" onclick="openProduct(null)" style="border-radius: 8px;">
          <i class="fa-solid fa-plus me-1"></i> New Product
        </button>
      <?php endif; ?>
    </div>
  </div>

  <?php if (!$products): ?>
    <div class="text-center py-5 bg-white rounded-3 border">
      <i class="fa-solid fa-box-open text-muted mb-3" style="font-size: 3rem; opacity: 0.3;"></i>
      <h5 class="fw-bold text-dark">No products found</h5>
      <p class="text-muted small">Try adjusting your filters or search term.</p>
    </div>
  <?php else: ?>
    <div class="product-grid">
      <?php foreach ($products as $p): ?>
        <?php 
          $stock = (float)$p['total_stock'];
          $badgeClass = $stock <= 0 ? 'badge-out' : ($stock <= (float)$p['min_stock_level'] ? 'badge-low' : 'badge-good');
          $badgeText = $stock <= 0 ? 'Out of Stock' : num($stock, 0) . ' ' . e($p['unit']);
        ?>
        <div class="product-card">
          <div class="product-img-wrap">
            <?php if ($p['image_path'] && ($u = upload_url($p['image_path']))): ?>
              <img src="<?= e($u) ?>" alt="<?= e($p['name']) ?>">
            <?php else: ?>
              <i class="fa-solid fa-box"></i>
            <?php endif; ?>
            
            <?php if (has_permission('product.create')): ?>
              <div class="card-actions">
                <button onclick='openProduct(<?= json_encode([
                    'id'             => (int)$p['id'], 'name' => $p['name'], 'sku' => $p['sku'],
                    'barcode'        => $p['barcode'], 'category_id' => (int)$p['category_id'],
                    'supplier_id'    => (int)$p['supplier_id'], 'unit' => $p['unit'],
                    'buying_price'   => $p['buying_price'], 'selling_price' => $p['selling_price'],
                    'min_stock_level'=> $p['min_stock_level'], 'description' => $p['description'],
                ], JSON_HEX_APOS | JSON_HEX_QUOT) ?>)' title="Edit">
                  <i class="fa-solid fa-pen"></i>
                </button>
                <?php if ($p['status'] === 'active'): ?>
                  <form method="post" class="m-0" onsubmit="return confirm('Archive this product?');">
                    <?= csrf_field() ?><input type="hidden" name="action" value="archive"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                    <button type="submit" title="Archive"><i class="fa-solid fa-box-archive"></i></button>
                  </form>
                <?php else: ?>
                  <form method="post" class="m-0">
                    <?= csrf_field() ?><input type="hidden" name="action" value="restore"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                    <button type="submit" title="Restore" class="text-success"><i class="fa-solid fa-rotate-left"></i></button>
                  </form>
                <?php endif; ?>
              </div>
            <?php endif; ?>
          </div>
          
          <div class="product-title" title="<?= e($p['name']) ?>"><?= e($p['name']) ?></div>
          <div class="product-sku"><?= e($p['sku']) ?> <?= $p['barcode'] ? '· '.e($p['barcode']) : '' ?></div>
          
          <div class="product-footer">
            <div>
              <div class="product-price"><?= money((float)$p['selling_price']) ?></div>
              <div class="text-muted" style="font-size:0.65rem; font-weight:600;"><?= e($p['category_name'] ?: 'Uncategorized') ?></div>
            </div>
            <div class="product-stock <?= $badgeClass ?>"><?= $badgeText ?></div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    
    <!-- Pagination -->
    <?php if ($pages > 1): ?>
      <div class="d-flex justify-content-between align-items-center mt-4">
        <small class="text-muted">Page <?= $page ?> of <?= $pages ?></small>
        <nav>
          <ul class="pagination pagination-sm mb-0">
            <?php
              $qs = $_GET; unset($qs['page']);
              $base = 'products.php?' . http_build_query($qs) . (count($qs) ? '&' : '') . 'page=';
            ?>
            <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="<?= e($base . ($page - 1)) ?>">Prev</a></li>
            <?php for ($i = max(1, $page - 2); $i <= min($pages, $page + 2); $i++): ?>
              <li class="page-item <?= $i === $page ? 'active' : '' ?>"><a class="page-link" href="<?= e($base . $i) ?>"><?= $i ?></a></li>
            <?php endfor; ?>
            <li class="page-item <?= $page >= $pages ? 'disabled' : '' ?>"><a class="page-link" href="<?= e($base . ($page + 1)) ?>">Next</a></li>
          </ul>
        </nav>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</div>

<?php if (has_permission('product.create')): ?>
<!-- Modal remains exactly the same -->
<div class="modal fade" id="productModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <form class="modal-content" method="post" enctype="multipart/form-data">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" id="pId" value="0">
      <div class="modal-header">
        <h5 class="modal-title" id="pTitle">New Product</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="row g-3">
          <div class="col-md-8">
            <label class="form-label">Product name</label>
            <input type="text" name="name" id="pName" class="form-control" required>
          </div>
          <div class="col-md-4">
            <label class="form-label">SKU / Code</label>
            <input type="text" name="sku" id="pSku" class="form-control" required>
          </div>
          <div class="col-md-4">
            <label class="form-label">Barcode <span class="text-muted small">(optional)</span></label>
            <input type="text" name="barcode" id="pBarcode" class="form-control">
          </div>
          <div class="col-md-4">
            <label class="form-label">Category</label>
            <select name="category_id" id="pCategory" class="form-select">
              <option value="0">— None —</option>
              <?php foreach ($categories as $c): ?>
                <option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label">Supplier</label>
            <select name="supplier_id" id="pSupplier" class="form-select">
              <option value="0">— None —</option>
              <?php foreach ($suppliers as $s): ?>
                <option value="<?= (int)$s['id'] ?>"><?= e($s['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">Unit</label>
            <input type="text" name="unit" id="pUnit" class="form-control" value="pcs">
          </div>
          <div class="col-md-3">
            <label class="form-label">Buying price</label>
            <input type="number" step="0.01" min="0" name="buying_price" id="pBuying" class="form-control" required>
          </div>
          <div class="col-md-3">
            <label class="form-label">Selling price</label>
            <input type="number" step="0.01" min="0" name="selling_price" id="pSelling" class="form-control" required>
          </div>
          <div class="col-md-3">
            <label class="form-label">Min stock</label>
            <input type="number" step="0.001" min="0" name="min_stock_level" id="pMinStock" class="form-control" value="0">
          </div>
          <div class="col-12">
            <label class="form-label">Description <span class="text-muted small">(optional)</span></label>
            <textarea name="description" id="pDescription" class="form-control" rows="2"></textarea>
          </div>
          <div class="col-12">
            <label class="form-label">Image <span class="text-muted small">(JPG/PNG/WEBP, ≤ 2MB)</span></label>
            <input type="file" name="image" class="form-control" accept="image/*">
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary">Save Product</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>