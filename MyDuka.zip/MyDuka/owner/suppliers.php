<?php
// owner/suppliers.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_role('owner');
require_permission('supplier.view');

$pdo        = db();
$businessId = user_business_id();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post('action');

    if ($action === 'save') {
        require_permission('supplier.manage');
        $id      = post_int('id');
        $name    = post('name');
        $contact = post('contact_person');
        $phone   = post('phone');
        $email   = post('email');
        $address = post('address');
        $notes   = post('notes');

        $errors = [];
        if ($name === '') $errors[] = 'Supplier name is required.';
        if ($email !== '' && !valid_email($email)) $errors[] = 'Invalid email.';
        if ($phone !== '' && !valid_phone($phone)) $errors[] = 'Invalid phone.';

        if (!$errors) {
            try {
                if ($id > 0) {
                    $chk = $pdo->prepare("SELECT 1 FROM suppliers WHERE id = ? AND business_id = ?");
                    $chk->execute([$id, $businessId]);
                    if (!$chk->fetchColumn()) throw new RuntimeException('Supplier not found.');
                    $pdo->prepare("UPDATE suppliers SET name=?, contact_person=?, phone=?, email=?, address=?, notes=? WHERE id=? AND business_id=?")
                        ->execute([$name, $contact ?: null, $phone ?: null, $email ?: null, $address ?: null, $notes ?: null, $id, $businessId]);
                    audit_log('supplier.update', 'suppliers', $id, ['name' => $name]);
                    flash('success', 'Supplier updated.');
                } else {
                    $pdo->prepare("INSERT INTO suppliers (business_id, name, contact_person, phone, email, address, notes) VALUES (?, ?, ?, ?, ?, ?, ?)")
                        ->execute([$businessId, $name, $contact ?: null, $phone ?: null, $email ?: null, $address ?: null, $notes ?: null]);
                    $newId = (int)$pdo->lastInsertId();
                    audit_log('supplier.create', 'suppliers', $newId, ['name' => $name]);
                    flash('success', 'Supplier created.');
                }
            } catch (Throwable $ex) {
                flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Failed to save supplier.');
            }
        } else {
            foreach ($errors as $er) flash('danger', $er);
        }
        redirect('suppliers.php');
    }

    if ($action === 'archive' || $action === 'restore') {
        require_permission('supplier.manage');
        $id     = post_int('id');
        $status = $action === 'archive' ? 'archived' : 'active';
        $chk = $pdo->prepare("SELECT 1 FROM suppliers WHERE id = ? AND business_id = ?");
        $chk->execute([$id, $businessId]);
        if ($chk->fetchColumn()) {
            $pdo->prepare("UPDATE suppliers SET status = ? WHERE id = ?")->execute([$status, $id]);
            audit_log("supplier.{$action}", 'suppliers', $id);
            flash('success', 'Supplier ' . ($action === 'archive' ? 'archived.' : 'restored.'));
        }
        redirect('suppliers.php');
    }
}

$search = get('q');
$status = get('status', 'active');
$where  = "s.business_id = ?";
$params = [$businessId];
if ($status === 'active' || $status === 'archived') {
    $where .= " AND s.status = ?";
    $params[] = $status;
}
if ($search !== '') {
    $where .= " AND (s.name LIKE ? OR s.phone LIKE ? OR s.email LIKE ?)";
    $like = "%{$search}%";
    array_push($params, $like, $like, $like);
}

$stmt = $pdo->prepare(
    "SELECT s.*,
            (SELECT COUNT(*) FROM purchases p WHERE p.supplier_id = s.id) AS purchase_count,
            (SELECT COALESCE(SUM(balance_due),0) FROM purchases p WHERE p.supplier_id = s.id AND p.status='received') AS outstanding
     FROM suppliers s WHERE {$where} ORDER BY s.name"
);
$stmt->execute($params);
$suppliers = $stmt->fetchAll();

$pageTitle = 'Suppliers';
$breadcrumbs = ['Dashboard' => APP_URL . '/owner/dashboard.php', 'Suppliers' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; }
  
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }

  .filter-form { display: flex; gap: 0.5rem; background: #fff; padding: 0.35rem; border-radius: 10px; border: 1px solid #cbd5e1; margin-bottom: 1rem; flex-wrap: wrap; align-items: center; }
  .filter-form input, .filter-form select { border: none; border-radius: 6px; padding: 0.35rem 0.5rem; font-size: 0.8rem; font-weight: 500; color: #0f172a; background: transparent; }
  .filter-form input:focus, .filter-form select:focus { outline: none; background: #f8fafc; }

  .list-panel { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
  .list-item { display: flex; align-items: center; padding: 1.25rem 1.5rem; border-bottom: 1px solid #f1f5f9; transition: background 0.15s; flex-wrap: wrap; gap: 1rem; }
  .list-item:last-child { border-bottom: none; }
  .list-item:hover { background: #f8fafc; }
  
  .list-icon { width: 44px; height: 44px; border-radius: 12px; background: #eff6ff; color: #2563eb; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0; }
  
  .list-content { flex: 1; min-width: 200px; }
  .list-title { font-weight: 700; font-size: 0.95rem; color: #0f172a; margin-bottom: 0.15rem; }
  .list-sub { font-size: 0.75rem; color: #64748b; font-weight: 500; display: flex; gap: 0.75rem; align-items: center; }
  
  .list-meta { display: flex; gap: 1.5rem; text-align: right; align-items: center; }
  .meta-item { text-align: right; }
  .meta-val { font-weight: 700; font-size: 0.9rem; color: #0f172a; }
  .meta-lbl { font-size: 0.65rem; color: #94a3b8; font-weight: 600; text-transform: uppercase; }
  .meta-val.text-danger { color: #dc2626; }
  
  .list-actions { display: flex; gap: 0.5rem; align-items: center; }
  .btn-icon { width: 32px; height: 32px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; border: 1px solid #cbd5e1; background: #fff; color: #475569; cursor: pointer; transition: all 0.15s; }
  .btn-icon:hover { background: #f8fafc; color: #2563eb; border-color: #3b82f6; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>Suppliers</h1>
      <p>Manage your vendors and track outstanding balances.</p>
    </div>
    <div class="d-flex gap-2">
      <form class="filter-form m-0" method="get">
        <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search supplier...">
        <select name="status" onchange="this.form.submit()">
          <option value="active" <?= $status==='active' ? 'selected':'' ?>>Active</option>
          <option value="archived" <?= $status==='archived' ? 'selected':'' ?>>Archived</option>
          <option value="" <?= $status==='' ? 'selected':'' ?>>All</option>
        </select>
        <button type="submit" class="btn btn-sm btn-dark">Search</button>
      </form>
      <?php if (has_permission('supplier.manage')): ?>
        <button class="btn btn-primary fw-bold px-3" data-bs-toggle="modal" data-bs-target="#supplierModal" onclick="openSupplier(null)" style="border-radius: 8px;">
          <i class="fa-solid fa-plus me-1"></i> New Supplier
        </button>
      <?php endif; ?>
    </div>
  </div>

  <div class="list-panel">
    <?php if (!$suppliers): ?>
      <div class="text-center py-5">
        <i class="fa-solid fa-handshake text-muted mb-3" style="font-size: 3rem; opacity: 0.3;"></i>
        <h5 class="fw-bold text-dark">No suppliers found</h5>
        <p class="text-muted small">Add your first supplier to start recording purchases.</p>
      </div>
    <?php else: foreach ($suppliers as $s): ?>
      <div class="list-item">
        <div class="list-icon"><i class="fa-solid fa-building"></i></div>
        
        <div class="list-content">
          <div class="list-title">
            <?= e($s['name']) ?>
            <?php if ($s['status'] === 'archived'): ?><span class="badge bg-secondary ms-2" style="font-size:0.6rem;">Archived</span><?php endif; ?>
          </div>
          <div class="list-sub">
            <span><i class="fa-solid fa-user me-1"></i><?= e($s['contact_person'] ?: 'No Contact') ?></span>
            <span class="text-muted">•</span>
            <span><i class="fa-solid fa-phone me-1"></i><?= e($s['phone'] ?: 'No Phone') ?></span>
          </div>
        </div>

        <div class="list-meta">
          <div class="meta-item">
            <div class="meta-val"><?= (int)$s['purchase_count'] ?></div>
            <div class="meta-lbl">Purchases</div>
          </div>
          <div class="meta-item">
            <div class="meta-val <?= (float)$s['outstanding'] > 0 ? 'text-danger' : '' ?>"><?= money((float)$s['outstanding']) ?></div>
            <div class="meta-lbl">Outstanding</div>
          </div>
        </div>

        <div class="list-actions">
          <?php if (has_permission('supplier.manage')): ?>
            <button class="btn-icon" onclick='openSupplier(<?= json_encode([
                'id' => (int)$s['id'], 'name' => $s['name'], 'contact_person' => $s['contact_person'],
                'phone' => $s['phone'], 'email' => $s['email'], 'address' => $s['address'], 'notes' => $s['notes'],
            ], JSON_HEX_APOS | JSON_HEX_QUOT) ?>)' title="Edit">
              <i class="fa-solid fa-pen"></i>
            </button>
            <?php if ($s['status'] === 'active'): ?>
              <form method="post" class="m-0" onsubmit="return confirm('Archive supplier?');">
                <?= csrf_field() ?><input type="hidden" name="action" value="archive"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
                <button type="submit" class="btn-icon text-danger" title="Archive"><i class="fa-solid fa-box-archive"></i></button>
              </form>
            <?php else: ?>
              <form method="post" class="m-0">
                <?= csrf_field() ?><input type="hidden" name="action" value="restore"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
                <button type="submit" class="btn-icon text-success" title="Restore"><i class="fa-solid fa-rotate-left"></i></button>
              </form>
            <?php endif; ?>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<?php if (has_permission('supplier.manage')): ?>
<div class="modal fade" id="supplierModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <form class="modal-content" method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" id="supId" value="0">
      <div class="modal-header">
        <h5 class="modal-title" id="supTitle">New Supplier</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="row g-3">
          <div class="col-md-8">
            <label class="form-label">Supplier name</label>
            <input type="text" name="name" id="supName" class="form-control" required>
          </div>
          <div class="col-md-4">
            <label class="form-label">Contact person</label>
            <input type="text" name="contact_person" id="supContact" class="form-control">
          </div>
          <div class="col-md-6">
            <label class="form-label">Phone</label>
            <input type="text" name="phone" id="supPhone" class="form-control">
          </div>
          <div class="col-md-6">
            <label class="form-label">Email</label>
            <input type="email" name="email" id="supEmail" class="form-control">
          </div>
          <div class="col-12">
            <label class="form-label">Address</label>
            <input type="text" name="address" id="supAddress" class="form-control">
          </div>
          <div class="col-12">
            <label class="form-label">Notes</label>
            <textarea name="notes" id="supNotes" class="form-control" rows="2"></textarea>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary">Save Supplier</button>
      </div>
    </form>
  </div>
</div>
<script>
function openSupplier(s) {
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = v ?? ''; };
  document.getElementById('supId').value = s ? s.id : 0;
  document.getElementById('supTitle').textContent = s ? 'Edit Supplier' : 'New Supplier';
  set('supName', s ? s.name : '');
  set('supContact', s ? s.contact_person : '');
  set('supPhone', s ? s.phone : '');
  set('supEmail', s ? s.email : '');
  set('supAddress', s ? s.address : '');
  set('supNotes', s ? s.notes : '');
  new bootstrap.Modal(document.getElementById('supplierModal')).show();
}
</script>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>