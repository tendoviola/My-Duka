<?php
// owner/branches.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_role('owner');
require_permission('branch.view');

$pdo        = db();
$businessId = user_business_id();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post('action');

    if ($action === 'save') {
        require_permission('branch.manage');
        $id      = post_int('id');
        $name    = post('name');
        $code    = post('code');
        $address = post('address');
        $phone   = post('phone');
        $isMain  = post_int('is_main');

        $errors = [];
        if ($name === '') $errors[] = 'Branch name is required.';
        if (!$errors) {
            $dup = $pdo->prepare("SELECT id FROM branches WHERE business_id = ? AND name = ? AND id <> ? LIMIT 1");
            $dup->execute([$businessId, $name, $id]);
            if ($dup->fetchColumn()) $errors[] = 'A branch with that name already exists.';
        }

        if ($errors) { foreach ($errors as $e) flash('danger', $e); }
        else {
            try {
                $pdo->beginTransaction();
                if ($isMain) $pdo->prepare("UPDATE branches SET is_main = 0 WHERE business_id = ?")->execute([$businessId]);
                if ($id > 0) {
                    $chk = $pdo->prepare("SELECT 1 FROM branches WHERE id = ? AND business_id = ?");
                    $chk->execute([$id, $businessId]);
                    if (!$chk->fetchColumn()) throw new RuntimeException('Branch not found.');
                    $pdo->prepare("UPDATE branches SET name=?, code=?, address=?, phone=?, is_main=? WHERE id=?")->execute([$name, $code ?: null, $address ?: null, $phone ?: null, $isMain ? 1 : 0, $id]);
                    audit_log('branch.update', 'branches', $id, ['name' => $name]);
                    flash('success', 'Branch updated.');
                } else {
                    $pdo->prepare("INSERT INTO branches (business_id, name, code, address, phone, is_main) VALUES (?, ?, ?, ?, ?, ?)")->execute([$businessId, $name, $code ?: null, $address ?: null, $phone ?: null, $isMain ? 1 : 0]);
                    $newId = (int)$pdo->lastInsertId();
                    audit_log('branch.create', 'branches', $newId, ['name' => $name]);
                    flash('success', 'Branch created.');
                }
                $pdo->commit();
            } catch (Throwable $ex) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Could not save branch.');
            }
        }
        redirect('branches.php');
    }

    if ($action === 'toggle') {
        require_permission('branch.manage');
        $id = post_int('id');
        $chk = $pdo->prepare("SELECT status, is_main FROM branches WHERE id = ? AND business_id = ?");
        $chk->execute([$id, $businessId]);
        $b = $chk->fetch();
        if ($b) {
            if ((int)$b['is_main'] === 1 && $b['status'] === 'active') {
                flash('danger', 'Cannot deactivate the main branch.');
            } else {
                $new = $b['status'] === 'active' ? 'inactive' : 'active';
                $pdo->prepare("UPDATE branches SET status = ? WHERE id = ?")->execute([$new, $id]);
                audit_log('branch.toggle', 'branches', $id, ['new_status' => $new]);
                flash('success', "Branch set to {$new}.");
            }
        }
        redirect('branches.php');
    }
}

$stmt = $pdo->prepare(
    "SELECT b.*,
            (SELECT COUNT(*) FROM user_branch_assignments uba WHERE uba.branch_id = b.id) AS staff_count,
            (SELECT COUNT(*) FROM inventory i WHERE i.branch_id = b.id AND i.quantity > 0) AS sku_count,
            (SELECT COALESCE(SUM(i.quantity * i.weighted_avg_cost),0) FROM inventory i WHERE i.branch_id = b.id) AS stock_value
     FROM branches b WHERE b.business_id = ? ORDER BY b.is_main DESC, b.name"
);
$stmt->execute([$businessId]);
$branches = $stmt->fetchAll();

$pageTitle = 'Branches';
$breadcrumbs = ['Dashboard' => APP_URL . '/owner/dashboard.php', 'Branches' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; }
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }

  .branch-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 1rem; }
  
  .branch-card {
    background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; padding: 1.5rem;
    display: flex; flex-direction: column; transition: all 0.2s ease; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02);
  }
  .branch-card:hover { transform: translateY(-2px); box-shadow: 0 8px 20px -8px rgba(0,0,0,0.08); border-color: #cbd5e1; }
  
  .branch-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem; }
  .branch-name { font-weight: 800; font-size: 1.1rem; color: #0f172a; margin: 0; }
  
  .branch-stats { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 0.5rem; background: #f8fafc; border-radius: 10px; padding: 0.85rem; margin-bottom: 1.25rem; }
  .stat-item { text-align: center; }
  .stat-val { font-weight: 800; font-size: 1rem; color: #0f172a; }
  .stat-lbl { font-size: 0.65rem; color: #64748b; text-transform: uppercase; font-weight: 700; letter-spacing: 0.05em; }
  
  .branch-actions { display: flex; gap: 0.5rem; margin-top: auto; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>Branches</h1>
      <p>Manage your retail locations and monitor their performance.</p>
    </div>
    <?php if (has_permission('branch.manage')): ?>
      <button class="btn btn-primary fw-bold px-3" data-bs-toggle="modal" data-bs-target="#branchModal" onclick="openBranch(null)" style="border-radius: 8px;">
        <i class="fa-solid fa-plus me-1"></i> New Branch
      </button>
    <?php endif; ?>
  </div>

  <?php if (!$branches): ?>
    <div class="text-center py-5 bg-white rounded-3 border">
      <i class="fa-solid fa-store text-muted mb-3" style="font-size: 3rem; opacity: 0.3;"></i>
      <h5 class="fw-bold text-dark">No branches yet</h5>
      <p class="text-muted small">Create your first location to get started.</p>
    </div>
  <?php else: ?>
    <div class="branch-grid">
      <?php foreach ($branches as $b): ?>
        <div class="branch-card">
          <div class="branch-header">
            <div>
              <h3 class="branch-name">
                <?= e($b['name']) ?>
                <?php if ((int)$b['is_main']): ?>
                  <i class="fa-solid fa-star text-warning ms-1" style="font-size:0.8rem;" title="Main Branch"></i>
                <?php endif; ?>
              </h3>
              <div class="text-muted small mt-1"><i class="fa-solid fa-location-dot me-1"></i><?= e($b['address'] ?: 'No address provided') ?></div>
            </div>
            <span class="badge <?= $b['status']==='active' ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary' ?>" style="font-size:0.65rem;">
              <?= strtoupper($b['status']) ?>
            </span>
          </div>

          <div class="branch-stats">
            <div class="stat-item"><div class="stat-val"><?= (int)$b['staff_count'] ?></div><div class="stat-lbl">Staff</div></div>
            <div class="stat-item"><div class="stat-val"><?= (int)$b['sku_count'] ?></div><div class="stat-lbl">SKUs</div></div>
            <div class="stat-item"><div class="stat-val" style="font-size:0.85rem;"><?= money((float)$b['stock_value']) ?></div><div class="stat-lbl">Stock</div></div>
          </div>

          <?php if (has_permission('branch.manage')): ?>
            <div class="branch-actions">
              <button class="btn btn-sm btn-light border fw-bold w-100" onclick='openBranch(<?= json_encode([
                  'id' => (int)$b['id'], 'name' => $b['name'], 'code' => $b['code'],
                  'address' => $b['address'], 'phone' => $b['phone'], 'is_main' => (int)$b['is_main'],
              ], JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>Edit Details</button>
              
              <form method="post" class="m-0 w-100" onsubmit="return confirm('Toggle status?');">
                <?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
                <button class="btn btn-sm <?= $b['status']==='active' ? 'btn-outline-danger' : 'btn-outline-success' ?> fw-bold w-100">
                  <?= $b['status']==='active' ? 'Deactivate' : 'Activate' ?>
                </button>
              </form>
            </div>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php if (has_permission('branch.manage')): ?>
<div class="modal fade" id="branchModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="post">
      <?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" id="brId" value="0">
      <div class="modal-header"><h5 class="modal-title" id="brTitle">New Branch</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <div class="row g-3">
          <div class="col-md-8"><label class="form-label">Name</label><input type="text" name="name" id="brName" class="form-control" required></div>
          <div class="col-md-4"><label class="form-label">Code</label><input type="text" name="code" id="brCode" class="form-control" placeholder="KLA"></div>
          <div class="col-12"><label class="form-label">Address</label><input type="text" name="address" id="brAddress" class="form-control"></div>
          <div class="col-md-6"><label class="form-label">Phone</label><input type="text" name="phone" id="brPhone" class="form-control"></div>
          <div class="col-md-6">
            <label class="form-label d-block">Main branch?</label>
            <div class="form-check form-switch mt-2"><input class="form-check-input" type="checkbox" name="is_main" value="1" id="brMain"><label class="form-check-label" for="brMain">Set as main</label></div>
          </div>
        </div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary">Save Branch</button></div>
    </form>
  </div>
</div>
<script>
function openBranch(b) {
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = v ?? ''; };
  document.getElementById('brId').value = b ? b.id : 0;
  document.getElementById('brTitle').textContent = b ? 'Edit Branch' : 'New Branch';
  set('brName', b ? b.name : '');
  set('brCode', b ? b.code : '');
  set('brAddress', b ? b.address : '');
  set('brPhone', b ? b.phone : '');
  document.getElementById('brMain').checked = b ? b.is_main == 1 : false;
  new bootstrap.Modal(document.getElementById('branchModal')).show();
}
</script>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>