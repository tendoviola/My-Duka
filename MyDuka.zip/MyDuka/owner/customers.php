<?php
// owner/customers.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_role('owner');
require_permission('customer.view');

$pdo        = db();
$businessId = user_business_id();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post('action');

    if ($action === 'save') {
        require_permission('customer.manage');
        $id      = post_int('id');
        $name    = post('name');
        $phone   = post('phone');
        $email   = post('email');
        $address = post('address');

        $errors = [];
        if ($name === '') $errors[] = 'Customer name is required.';
        if ($email !== '' && !valid_email($email)) $errors[] = 'Invalid email.';
        if ($phone !== '' && !valid_phone($phone)) $errors[] = 'Invalid phone.';

        if ($errors) {
            foreach ($errors as $e) flash('danger', $e);
        } else {
            try {
                if ($id > 0) {
                    $chk = $pdo->prepare("SELECT 1 FROM customers WHERE id = ? AND business_id = ?");
                    $chk->execute([$id, $businessId]);
                    if (!$chk->fetchColumn()) throw new RuntimeException('Customer not found.');
                    $pdo->prepare("UPDATE customers SET name=?, phone=?, email=?, address=? WHERE id=?")
                        ->execute([$name, $phone ?: null, $email ?: null, $address ?: null, $id]);
                    audit_log('customer.update', 'customers', $id);
                    flash('success', 'Customer updated.');
                } else {
                    $pdo->prepare("INSERT INTO customers (business_id, name, phone, email, address) VALUES (?, ?, ?, ?, ?)")
                        ->execute([$businessId, $name, $phone ?: null, $email ?: null, $address ?: null]);
                    $newId = (int)$pdo->lastInsertId();
                    audit_log('customer.create', 'customers', $newId);
                    flash('success', 'Customer created.');
                }
            } catch (Throwable $ex) {
                flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Could not save customer.');
            }
        }
        redirect('customers.php');
    }
}

$search = get('q');
$where = "c.business_id = ?";
$params = [$businessId];
if ($search !== '') {
    $where .= " AND (c.name LIKE ? OR c.phone LIKE ? OR c.email LIKE ?)";
    $like = "%{$search}%";
    array_push($params, $like, $like, $like);
}

$stmt = $pdo->prepare(
    "SELECT c.*,
            (SELECT COUNT(*) FROM sales s WHERE s.customer_id = c.id) AS sales_count,
            (SELECT COALESCE(SUM(total_amount),0) FROM sales s WHERE s.customer_id = c.id AND s.status IN ('completed','credit')) AS total_spent
     FROM customers c WHERE {$where} ORDER BY c.name LIMIT 300"
);
$stmt->execute($params);
$customers = $stmt->fetchAll();

$pageTitle = 'Customers';
$breadcrumbs = ['Dashboard' => APP_URL . '/owner/dashboard.php', 'Customers' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; }
  
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }

  .filter-form { display: flex; gap: 0.5rem; background: #fff; padding: 0.35rem; border-radius: 10px; border: 1px solid #cbd5e1; margin-bottom: 1rem; flex-wrap: wrap; align-items: center; }
  .filter-form input, .filter-form select { border: none; border-radius: 6px; padding: 0.35rem 0.5rem; font-size: 0.8rem; font-weight: 500; color: #0f172a; background: transparent; }
  .filter-form input:focus, .filter-form select:focus { outline: none; background: #f8fafc; }

  .list-panel { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
  
  .list-item { display: flex; align-items: center; padding: 1.25rem 1.5rem; border-bottom: 1px solid #f1f5f9; transition: background 0.15s; flex-wrap: wrap; gap: 1rem; }
  .list-item:last-child { border-bottom: none; }
  .list-item:hover { background: #f8fafc; }
  
  .list-avatar { width: 44px; height: 44px; border-radius: 12px; background: #f1f5f9; color: #475569; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; font-weight: 700; flex-shrink: 0; }
  
  .list-content { flex: 1; min-width: 200px; }
  .list-title { font-weight: 700; font-size: 0.95rem; color: #0f172a; margin-bottom: 0.15rem; }
  .list-sub { font-size: 0.75rem; color: #64748b; font-weight: 500; display: flex; gap: 0.75rem; align-items: center; }
  
  .list-meta { display: flex; gap: 1.5rem; text-align: right; align-items: center; }
  .meta-item { text-align: right; }
  .meta-val { font-weight: 700; font-size: 0.9rem; color: #0f172a; }
  .meta-lbl { font-size: 0.65rem; color: #94a3b8; font-weight: 600; text-transform: uppercase; }
  .meta-val.text-success { color: #16a34a; }
  
  .list-actions { display: flex; gap: 0.5rem; align-items: center; }
  .btn-icon { width: 32px; height: 32px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; border: 1px solid #cbd5e1; background: #fff; color: #475569; cursor: pointer; transition: all 0.15s; }
  .btn-icon:hover { background: #f8fafc; color: #2563eb; border-color: #3b82f6; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>Customers</h1>
      <p>Manage your client directory and their purchase history.</p>
    </div>
    <div class="d-flex gap-2">
      <form class="filter-form m-0" method="get">
        <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search name, phone or email...">
        <button type="submit" class="btn btn-sm btn-dark">Search</button>
      </form>
      <?php if (has_permission('customer.manage')): ?>
        <button class="btn btn-primary fw-bold px-3" data-bs-toggle="modal" data-bs-target="#customerModal" onclick="openCustomer(null)" style="border-radius: 8px;">
          <i class="fa-solid fa-plus me-1"></i> New Customer
        </button>
      <?php endif; ?>
    </div>
  </div>

  <div class="list-panel">
    <?php if (!$customers): ?>
      <div class="text-center py-5">
        <i class="fa-solid fa-users text-muted mb-3" style="font-size: 3rem; opacity: 0.3;"></i>
        <h5 class="fw-bold text-dark">No customers found</h5>
        <p class="text-muted small">Add your first customer to track their sales history.</p>
      </div>
    <?php else: foreach ($customers as $c): ?>
      <?php 
        $initials = '';
        foreach (array_slice(explode(' ', $c['name']), 0, 2) as $part) {
            $initials .= mb_strtoupper(mb_substr($part, 0, 1));
        }
      ?>
      <div class="list-item">
        <div class="list-avatar"><?= e($initials) ?></div>
        
        <div class="list-content">
          <div class="list-title"><?= e($c['name']) ?></div>
          <div class="list-sub">
            <span><i class="fa-solid fa-phone me-1"></i><?= e($c['phone'] ?: 'No phone') ?></span>
            <?php if ($c['email']): ?>
              <span class="text-muted">•</span>
              <span><i class="fa-regular fa-envelope me-1"></i><?= e($c['email']) ?></span>
            <?php endif; ?>
          </div>
        </div>

        <div class="list-meta">
          <div class="meta-item">
            <div class="meta-val"><?= (int)$c['sales_count'] ?></div>
            <div class="meta-lbl">Orders</div>
          </div>
          <div class="meta-item">
            <div class="meta-val text-success"><?= money((float)$c['total_spent']) ?></div>
            <div class="meta-lbl">Total Spent</div>
          </div>
        </div>

        <div class="list-actions">
          <?php if (has_permission('customer.manage')): ?>
            <button class="btn-icon" onclick='openCustomer(<?= json_encode([
                'id' => (int)$c['id'], 'name' => $c['name'], 'phone' => $c['phone'],
                'email' => $c['email'], 'address' => $c['address'],
            ], JSON_HEX_APOS | JSON_HEX_QUOT) ?>)' title="Edit Customer">
              <i class="fa-solid fa-pen"></i>
            </button>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<?php if (has_permission('customer.manage')): ?>
<div class="modal fade" id="customerModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" id="custId" value="0">
      <div class="modal-header">
        <h5 class="modal-title" id="custTitle">New Customer</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label class="form-label">Name</label>
          <input type="text" name="name" id="custName" class="form-control" required>
        </div>
        <div class="row g-2 mb-3">
          <div class="col-md-6">
            <label class="form-label">Phone</label>
            <input type="text" name="phone" id="custPhone" class="form-control" placeholder="+256...">
          </div>
          <div class="col-md-6">
            <label class="form-label">Email</label>
            <input type="email" name="email" id="custEmail" class="form-control">
          </div>
        </div>
        <div class="mb-3">
          <label class="form-label">Address</label>
          <input type="text" name="address" id="custAddress" class="form-control">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary">Save Customer</button>
      </div>
    </form>
  </div>
</div>
<script>
function openCustomer(c) {
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = v ?? ''; };
  document.getElementById('custId').value = c ? c.id : 0;
  document.getElementById('custTitle').textContent = c ? 'Edit Customer' : 'New Customer';
  set('custName', c ? c.name : '');
  set('custPhone', c ? c.phone : '');
  set('custEmail', c ? c.email : '');
  set('custAddress', c ? c.address : '');
  new bootstrap.Modal(document.getElementById('customerModal')).show();
}
</script>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>