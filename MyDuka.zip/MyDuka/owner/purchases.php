<?php
// owner/purchases.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/stock.php';
require_role('owner');
require_permission('purchase.view');

$pdo        = db();
$businessId = user_business_id();
$userId     = (int)current_user()['id'];
$branches   = user_branch_ids();

// ---- Actions ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post('action');

    if ($action === 'create') {
        require_permission('purchase.create');
        $supplierId   = post_int('supplier_id') ?: null;
        $branchId     = post_int('branch_id');
        $purchaseDate = post('purchase_date') ?: date('Y-m-d');
        $referenceNo  = post('reference_no');
        $notes        = post('notes');

        $itemProductIds = (array)($_POST['item_product'] ?? []);
        $itemQtys       = (array)($_POST['item_qty']     ?? []);
        $itemCosts      = (array)($_POST['item_cost']    ?? []);

        $errors = [];
        if (!in_array($branchId, $branches, true)) $errors[] = 'Invalid branch.';
        if ($supplierId) {
            $chk = $pdo->prepare("SELECT 1 FROM suppliers WHERE id = ? AND business_id = ? AND status='active'");
            $chk->execute([$supplierId, $businessId]);
            if (!$chk->fetchColumn()) $errors[] = 'Invalid supplier.';
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $purchaseDate)) $errors[] = 'Invalid date.';

        $lineItems = [];
        for ($i = 0; $i < count($itemProductIds); $i++) {
            $pid  = (int)$itemProductIds[$i];
            $qty  = (float)($itemQtys[$i] ?? 0);
            $cost = (float)($itemCosts[$i] ?? 0);
            if ($pid <= 0 || $qty <= 0) continue;
            if ($cost < 0) $errors[] = 'Unit cost must be ≥ 0.';
            $chk = $pdo->prepare("SELECT 1 FROM products WHERE id = ? AND business_id = ? AND status='active'");
            $chk->execute([$pid, $businessId]);
            if (!$chk->fetchColumn()) $errors[] = "Invalid product #{$pid}.";
            $lineItems[] = ['product_id' => $pid, 'quantity' => $qty, 'unit_cost' => $cost, 'line_total' => $qty * $cost];
        }
        if (!$lineItems) $errors[] = 'Add at least one product with quantity.';

        if ($errors) {
            foreach ($errors as $er) flash('danger', $er);
        } else {
            try {
                $pdo->beginTransaction();
                $total = array_sum(array_column($lineItems, 'line_total'));
                $purchaseNumber = generate_number('PUR', 'purchases', 'purchase_number', $businessId);

                $pdo->prepare(
                    "INSERT INTO purchases
                        (business_id, branch_id, supplier_id, purchase_number, purchase_date,
                         reference_no, total_amount, status, notes, created_by)
                     VALUES (?, ?, ?, ?, ?, ?, ?, 'draft', ?, ?)"
                )->execute([
                    $businessId, $branchId, $supplierId, $purchaseNumber, $purchaseDate,
                    $referenceNo ?: null, $total, $notes ?: null, $userId,
                ]);
                $purchaseId = (int)$pdo->lastInsertId();

                $pIns = $pdo->prepare(
                    "INSERT INTO purchase_items (purchase_id, product_id, quantity, unit_cost, line_total)
                     VALUES (?, ?, ?, ?, ?)"
                );
                foreach ($lineItems as $it) {
                    $pIns->execute([$purchaseId, $it['product_id'], $it['quantity'], $it['unit_cost'], $it['line_total']]);
                }

                audit_log('purchase.create', 'purchases', $purchaseId, ['number' => $purchaseNumber]);
                $pdo->commit();
                flash('success', 'Purchase saved as draft.');
            } catch (Throwable $ex) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Could not save purchase.');
            }
        }
        redirect('purchases.php');
    }

    if ($action === 'receive') {
        require_permission('purchase.create');
        $pid = post_int('id');
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("SELECT * FROM purchases WHERE id = ? AND business_id = ? FOR UPDATE");
            $stmt->execute([$pid, $businessId]);
            $pur = $stmt->fetch();
            if (!$pur) throw new RuntimeException('Purchase not found.');
            if ($pur['status'] !== 'draft') throw new RuntimeException('Only draft purchases can be received.');

            $items = $pdo->prepare("SELECT * FROM purchase_items WHERE purchase_id = ?");
            $items->execute([$pid]);
            foreach ($items->fetchAll() as $it) {
                apply_stock_change(
                    $pdo, $businessId, (int)$pur['branch_id'], (int)$it['product_id'],
                    (float)$it['quantity'], 'purchase', (float)$it['unit_cost'],
                    'purchases', $pid, 'Purchase received', $userId
                );
            }

            $pdo->prepare("UPDATE purchases SET status = 'received' WHERE id = ?")->execute([$pid]);
            audit_log('purchase.receive', 'purchases', $pid);
            $pdo->commit();
            flash('success', 'Purchase received. Stock updated.');
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Could not receive purchase.');
        }
        redirect('purchases.php?' . http_build_query($_GET));
    }

    if ($action === 'cancel') {
        require_permission('purchase.cancel');
        $pid = post_int('id');
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("SELECT * FROM purchases WHERE id = ? AND business_id = ? FOR UPDATE");
            $stmt->execute([$pid, $businessId]);
            $pur = $stmt->fetch();
            if (!$pur) throw new RuntimeException('Purchase not found.');
            if ($pur['status'] === 'cancelled') throw new RuntimeException('Already cancelled.');

            if ($pur['status'] === 'received') {
                $items = $pdo->prepare("SELECT * FROM purchase_items WHERE purchase_id = ?");
                $items->execute([$pid]);
                foreach ($items->fetchAll() as $it) {
                    apply_stock_change(
                        $pdo, $businessId, (int)$pur['branch_id'], (int)$it['product_id'],
                        -(float)$it['quantity'], 'adjustment', null,
                        'purchases', $pid, "Reversal of cancelled purchase {$pur['purchase_number']}", $userId
                    );
                }
            }
            $pdo->prepare("UPDATE purchases SET status = 'cancelled' WHERE id = ?")->execute([$pid]);
            audit_log('purchase.cancel', 'purchases', $pid);
            $pdo->commit();
            flash('success', 'Purchase cancelled.');
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Could not cancel purchase.');
        }
        redirect('purchases.php?' . http_build_query($_GET));
    }

    if ($action === 'pay') {
        require_permission('purchase.create');
        $pid    = post_int('id');
        $amount = post_float('amount');
        $method = post('method') ?: 'cash';
        if ($amount <= 0) {
            flash('danger', 'Payment amount must be greater than zero.');
        } else {
            try {
                $pdo->beginTransaction();
                $stmt = $pdo->prepare("SELECT * FROM purchases WHERE id = ? AND business_id = ? FOR UPDATE");
                $stmt->execute([$pid, $businessId]);
                $pur = $stmt->fetch();
                if (!$pur || !$pur['supplier_id']) throw new RuntimeException('Invalid purchase.');

                $balance = (float)$pur['total_amount'] - (float)$pur['paid_amount'];
                if ($amount > $balance) $amount = $balance;

                $pdo->prepare(
                    "INSERT INTO supplier_payments (business_id, purchase_id, supplier_id, amount, payment_date, method, user_id)
                     VALUES (?, ?, ?, ?, CURDATE(), ?, ?)"
                )->execute([$businessId, $pid, (int)$pur['supplier_id'], $amount, $method, $userId]);

                $newPaid = (float)$pur['paid_amount'] + $amount;
                $status  = $newPaid >= (float)$pur['total_amount'] ? 'paid' : ($newPaid > 0 ? 'partial' : 'unpaid');
                $pdo->prepare("UPDATE purchases SET paid_amount = ?, payment_status = ? WHERE id = ?")
                    ->execute([$newPaid, $status, $pid]);

                audit_log('purchase.payment', 'purchases', $pid, ['amount' => $amount, 'method' => $method]);
                $pdo->commit();
                flash('success', 'Payment recorded.');
            } catch (Throwable $ex) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Could not record payment.');
            }
        }
        redirect('purchases.php?' . http_build_query($_GET));
    }

    if ($action === 'delete') {
        require_permission('purchase.cancel');
        $pid = post_int('id');
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("SELECT * FROM purchases WHERE id = ? AND business_id = ? FOR UPDATE");
            $stmt->execute([$pid, $businessId]);
            $pur = $stmt->fetch();
            if (!$pur) throw new RuntimeException('Purchase not found.');

            $payCount = $pdo->prepare("SELECT COUNT(*) FROM supplier_payments WHERE purchase_id = ?");
            $payCount->execute([$pid]);
            if ((int)$payCount->fetchColumn() > 0) {
                throw new RuntimeException('This purchase has supplier payments and cannot be deleted.');
            }

            $items = $pdo->prepare("SELECT * FROM purchase_items WHERE purchase_id = ?");
            $items->execute([$pid]);
            $items = $items->fetchAll();

            if ($pur['status'] === 'received') {
                foreach ($items as $it) {
                    apply_stock_change(
                        $pdo, $businessId, (int)$pur['branch_id'], (int)$it['product_id'],
                        -(float)$it['quantity'], 'adjustment', null,
                        'purchases', $pid, "Deletion of received purchase {$pur['purchase_number']}", $userId
                    );
                }
            }

            $pdo->prepare("DELETE FROM purchase_items WHERE purchase_id = ?")->execute([$pid]);
            $pdo->prepare("DELETE FROM purchases WHERE id = ? AND business_id = ?")->execute([$pid, $businessId]);

            audit_log('purchase.delete', 'purchases', $pid, ['number' => $pur['purchase_number']]);
            $pdo->commit();
            flash('success', "Purchase {$pur['purchase_number']} deleted.");
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Could not delete purchase.');
        }
        redirect('purchases.php?' . http_build_query($_GET));
    }
}

$statusFilter = get('status', '');
$search       = get('q');
$from         = get('from', date('Y-m-01'));
$to           = get('to',   date('Y-m-d'));
$branchFilter = (int)get('branch', 0);
$validBranch  = $branchFilter > 0 && in_array($branchFilter, $branches, true);

$where  = "p.business_id = ? AND p.purchase_date BETWEEN ? AND ?";
$params = [$businessId, $from, $to];
if (in_array($statusFilter, ['draft','received','cancelled'], true)) {
    $where .= " AND p.status = ?";
    $params[] = $statusFilter;
}
if ($validBranch) {
    $where .= " AND p.branch_id = ?";
    $params[] = $branchFilter;
}
if ($search !== '') {
    $where .= " AND (p.purchase_number LIKE ? OR p.reference_no LIKE ?)";
    $like = "%{$search}%";
    array_push($params, $like, $like);
}

$sumSql = "SELECT COUNT(*) AS n, COALESCE(SUM(p.total_amount),0) AS total_all,
             COALESCE(SUM(CASE WHEN p.status <> 'cancelled' THEN p.paid_amount ELSE 0 END),0) AS paid_real,
             COALESCE(SUM(CASE WHEN p.status <> 'cancelled' THEN p.balance_due ELSE 0 END),0) AS owed_real
           FROM purchases p WHERE {$where}";
$stmt = $pdo->prepare($sumSql);
$stmt->execute($params);
$summary = $stmt->fetch();

$stmt = $pdo->prepare(
    "SELECT p.*, b.name AS branch_name, s.name AS supplier_name,
            (SELECT COUNT(*) FROM supplier_payments sp WHERE sp.purchase_id = p.id) AS payment_count
     FROM purchases p
     JOIN branches b ON b.id = p.branch_id
     LEFT JOIN suppliers s ON s.id = p.supplier_id
     WHERE {$where} ORDER BY p.created_at DESC LIMIT 200"
);
$stmt->execute($params);
$purchases = $stmt->fetchAll();

$suppliers = $pdo->prepare("SELECT id, name FROM suppliers WHERE business_id = ? AND status='active' ORDER BY name");
$suppliers->execute([$businessId]);
$suppliers = $suppliers->fetchAll();

$products = $pdo->prepare("SELECT id, name, sku, buying_price, unit FROM products WHERE business_id = ? AND status='active' ORDER BY name");
$products->execute([$businessId]);
$products = $products->fetchAll();

$allBranches = $pdo->prepare("SELECT id, name FROM branches WHERE business_id = ? AND status='active' ORDER BY is_main DESC, name");
$allBranches->execute([$businessId]);
$allBranches = $allBranches->fetchAll();

$pageTitle = 'Purchases';
$breadcrumbs = ['Dashboard' => APP_URL . '/owner/dashboard.php', 'Purchases' => null];
$pageScripts = ['assets/js/purchases.js'];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; }
  
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }

  /* KPI Grid */
  .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
  .kpi-card { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; padding: 1.25rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
  .kpi-label { font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b; margin-bottom: 0.25rem; }
  .kpi-value { font-size: 1.5rem; font-weight: 800; color: #0f172a; line-height: 1.2; }
  .kpi-sub { font-size: 0.75rem; color: #94a3b8; font-weight: 500; margin-top: 0.2rem; }

  /* Filter Form */
  .filter-form { display: flex; gap: 0.5rem; background: #fff; padding: 0.35rem; border-radius: 10px; border: 1px solid #cbd5e1; margin-bottom: 1rem; flex-wrap: wrap; align-items: center; }
  .filter-form input, .filter-form select { border: none; border-radius: 6px; padding: 0.35rem 0.5rem; font-size: 0.8rem; font-weight: 500; color: #0f172a; background: transparent; }
  .filter-form input:focus, .filter-form select:focus { outline: none; background: #f8fafc; }

  /* List view */
  .list-panel { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
  .list-item { display: flex; align-items: center; padding: 1.25rem 1.5rem; border-bottom: 1px solid #f1f5f9; transition: background 0.15s; flex-wrap: wrap; gap: 1rem; }
  .list-item:last-child { border-bottom: none; }
  .list-item:hover { background: #f8fafc; }
  
  .list-icon { width: 44px; height: 44px; border-radius: 12px; background: #eff6ff; color: #2563eb; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0; }
  
  .list-content { flex: 1; min-width: 200px; }
  .list-title { font-weight: 700; font-size: 0.95rem; color: #0f172a; margin-bottom: 0.15rem; }
  .list-sub { font-size: 0.75rem; color: #64748b; font-weight: 500; display: flex; gap: 0.5rem; align-items: center; }
  
  .list-meta { display: flex; gap: 1.5rem; text-align: right; align-items: center; }
  .meta-item { text-align: right; }
  .meta-val { font-weight: 700; font-size: 0.9rem; color: #0f172a; }
  .meta-lbl { font-size: 0.65rem; color: #94a3b8; font-weight: 600; text-transform: uppercase; }
  .meta-val.text-danger { color: #dc2626; }
  
  .list-actions { display: flex; gap: 0.5rem; align-items: center; }
  .btn-action { padding: 0.35rem 0.75rem; font-size: 0.75rem; font-weight: 600; border-radius: 6px; border: 1px solid #cbd5e1; background: #fff; color: #475569; transition: all 0.15s; text-decoration: none; display: inline-flex; align-items: center; gap: 0.25rem; }
  .btn-action:hover { background: #f1f5f9; color: #0f172a; }
  .btn-action.primary { background: #2563eb; border-color: #2563eb; color: #fff; }
  .btn-action.primary:hover { background: #1d4ed8; }
  .btn-action.success { background: #16a34a; border-color: #16a34a; color: #fff; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>Purchases</h1>
      <p>Manage supplier invoices and stock replenishment.</p>
    </div>
    <?php if (has_permission('purchase.create')): ?>
      <button class="btn btn-primary fw-bold px-3" data-bs-toggle="modal" data-bs-target="#purchaseModal" style="border-radius: 8px;">
        <i class="fa-solid fa-plus me-1"></i> New Purchase
      </button>
    <?php endif; ?>
  </div>

  <div class="kpi-grid">
    <div class="kpi-card">
      <div class="kpi-label">Total Purchases</div>
      <div class="kpi-value"><?= money((float)$summary['total_all']) ?></div>
      <div class="kpi-sub"><?= (int)$summary['n'] ?> invoices in range</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Paid to Suppliers</div>
      <div class="kpi-value text-success"><?= money((float)$summary['paid_real']) ?></div>
      <div class="kpi-sub">Actual money out</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Outstanding</div>
      <div class="kpi-value text-danger"><?= money((float)$summary['owed_real']) ?></div>
      <div class="kpi-sub">Still owed to suppliers</div>
    </div>
  </div>

  <form class="filter-form" method="get">
    <input type="date" name="from" value="<?= e($from) ?>">
    <input type="date" name="to" value="<?= e($to) ?>">
    <select name="branch" onchange="this.form.submit()">
      <option value="0">All branches</option>
      <?php foreach ($allBranches as $b): ?>
        <option value="<?= (int)$b['id'] ?>" <?= $validBranch && $branchFilter === (int)$b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="status" onchange="this.form.submit()">
      <option value="">All statuses</option>
      <option value="draft" <?= $statusFilter==='draft' ? 'selected':'' ?>>Draft</option>
      <option value="received" <?= $statusFilter==='received' ? 'selected':'' ?>>Received</option>
      <option value="cancelled" <?= $statusFilter==='cancelled' ? 'selected':'' ?>>Cancelled</option>
    </select>
    <input type="text" name="q" value="<?= e($search) ?>" placeholder="Number or ref...">
    <button type="submit" class="btn btn-sm btn-dark">Apply</button>
    <a href="?<?= e(http_build_query(['from' => date('Y-m-01'), 'to' => date('Y-m-d')])) ?>" class="btn btn-sm btn-light border">Reset</a>
  </form>

  <div class="list-panel">
    <?php if (!$purchases): ?>
      <div class="text-center py-5">
        <i class="fa-solid fa-truck-ramp-box text-muted mb-3" style="font-size: 3rem; opacity: 0.3;"></i>
        <h5 class="fw-bold text-dark">No purchases found</h5>
        <p class="text-muted small">Try adjusting filters or record a new purchase.</p>
      </div>
    <?php else: foreach ($purchases as $p): ?>
      <?php
        $hasPayments = (int)$p['payment_count'] > 0;
        $canDelete   = has_permission('purchase.cancel') && !$hasPayments;
        $statusColors = ['draft'=>'bg-warning-subtle text-warning', 'received'=>'bg-success-subtle text-success', 'cancelled'=>'bg-secondary-subtle text-secondary'];
      ?>
      <div class="list-item">
        <div class="list-icon"><i class="fa-solid fa-file-invoice"></i></div>
        
        <div class="list-content">
          <div class="list-title">
            <?= e($p['purchase_number']) ?>
            <span class="badge <?= $statusColors[$p['status']] ?> ms-2" style="font-size:0.6rem; letter-spacing:0.05em;"><?= strtoupper($p['status']) ?></span>
          </div>
          <div class="list-sub">
            <i class="fa-regular fa-calendar me-1"></i><?= human_date($p['purchase_date']) ?>
            <span class="text-muted">•</span>
            <i class="fa-solid fa-truck me-1"></i><?= e($p['supplier_name'] ?: 'No Supplier') ?>
            <span class="text-muted">•</span>
            <i class="fa-solid fa-store me-1"></i><?= e($p['branch_name']) ?>
          </div>
        </div>

        <div class="list-meta">
          <div class="meta-item">
            <div class="meta-val"><?= money((float)$p['total_amount']) ?></div>
            <div class="meta-lbl">Total</div>
          </div>
          <div class="meta-item">
            <div class="meta-val text-success"><?= money((float)$p['paid_amount']) ?></div>
            <div class="meta-lbl">Paid</div>
          </div>
          <div class="meta-item">
            <div class="meta-val <?= (float)$p['balance_due'] > 0 ? 'text-danger' : '' ?>"><?= money((float)$p['balance_due']) ?></div>
            <div class="meta-lbl">Balance</div>
          </div>
        </div>

        <div class="list-actions">
          <?php if ($p['status'] === 'draft' && has_permission('purchase.create')): ?>
            <form method="post" class="m-0" onsubmit="return confirm('Receive this purchase?');">
              <?= csrf_field() ?><input type="hidden" name="action" value="receive"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
              <button type="submit" class="btn-action success"><i class="fa-solid fa-check"></i> Receive</button>
            </form>
          <?php endif; ?>
          
          <?php if ($p['status'] === 'received' && (float)$p['balance_due'] > 0 && has_permission('purchase.create')): ?>
            <button class="btn-action primary" data-bs-toggle="modal" data-bs-target="#payModal"
                    data-id="<?= (int)$p['id'] ?>" data-balance="<?= e((string)$p['balance_due']) ?>" data-number="<?= e($p['purchase_number']) ?>">
              <i class="fa-solid fa-money-bill"></i> Pay
            </button>
          <?php endif; ?>

          <?php if (in_array($p['status'], ['draft','received'], true) && has_permission('purchase.cancel')): ?>
            <form method="post" class="m-0" onsubmit="return confirm('Cancel this purchase?');">
              <?= csrf_field() ?><input type="hidden" name="action" value="cancel"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
              <button type="submit" class="btn-action"><i class="fa-solid fa-ban"></i></button>
            </form>
          <?php endif; ?>

          <?php if (has_permission('purchase.cancel')): ?>
            <?php if ($canDelete): ?>
              <button class="btn-action text-danger" data-bs-toggle="modal" data-bs-target="#deleteModal"
                      data-id="<?= (int)$p['id'] ?>" data-number="<?= e($p['purchase_number']) ?>" data-status="<?= e($p['status']) ?>" data-total="<?= e(number_format((float)$p['total_amount'], 2, '.', '')) ?>">
                <i class="fa-solid fa-trash"></i>
              </button>
            <?php else: ?>
              <button class="btn-action text-muted" disabled title="Has payments - Cancel instead"><i class="fa-solid fa-trash"></i></button>
            <?php endif; ?>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<!-- Modals (Keep your existing form structures for Purchase create, Pay, and Delete, but wrap them in standard Bootstrap modals) -->
<?php if (has_permission('purchase.cancel')): ?>
<div class="modal fade" id="deleteModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="post">
      <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" id="delId">
      <div class="modal-header">
        <h5 class="modal-title text-danger">Delete Purchase</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <p class="mb-2">You are about to delete purchase <strong id="delNumber"></strong> (<span id="delTotal"></span>).</p>
        <ul class="small text-muted mb-3">
          <li>This removes the purchase row and line items permanently.</li>
          <li id="delStockNote">If received, stock will be reversed.</li>
        </ul>
        <div class="alert alert-danger small mb-0">This cannot be undone.</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Keep</button>
        <button class="btn btn-danger">Delete Permanently</button>
      </div>
    </form>
  </div>
</div>
<script>
  document.getElementById('deleteModal').addEventListener('show.bs.modal', ev => {
    const b = ev.relatedTarget; if (!b) return;
    document.getElementById('delId').value = b.dataset.id;
    document.getElementById('delNumber').textContent = b.dataset.number;
    document.getElementById('delTotal').textContent = 'UGX ' + Number(b.dataset.total || 0).toLocaleString(undefined, {minimumFractionDigits: 2});
    document.getElementById('delStockNote').style.display = b.dataset.status === 'received' ? 'list-item' : 'none';
  });
</script>
<?php endif; ?>

<?php if (has_permission('purchase.create')): ?>
<!-- Create Modal (Same as before, form fields remain unchanged) -->
<div class="modal fade" id="purchaseModal" tabindex="-1">
  <div class="modal-dialog modal-xl modal-dialog-scrollable">
    <form class="modal-content" method="post" id="purchaseForm">
      <?= csrf_field() ?><input type="hidden" name="action" value="create">
      <div class="modal-header">
        <h5 class="modal-title">New Purchase</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="row g-3 mb-3">
          <div class="col-md-4">
            <label class="form-label">Supplier</label>
            <select name="supplier_id" class="form-select">
              <option value="0">— None —</option>
              <?php foreach ($suppliers as $s): ?><option value="<?= (int)$s['id'] ?>"><?= e($s['name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">Branch</label>
            <select name="branch_id" class="form-select" required>
              <?php foreach ($allBranches as $b): ?><option value="<?= (int)$b['id'] ?>"><?= e($b['name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">Date</label>
            <input type="date" name="purchase_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
          </div>
          <div class="col-md-2">
            <label class="form-label">Reference</label>
            <input type="text" name="reference_no" class="form-control" placeholder="Invoice #">
          </div>
        </div>
        <table class="table align-middle">
          <thead><tr><th style="width:45%">Product</th><th style="width:15%">Qty</th><th style="width:20%">Unit cost</th><th style="width:15%">Line total</th><th></th></tr></thead>
          <tbody id="lineItems"></tbody>
          <tfoot><tr><td colspan="3" class="text-end fw-semibold">Total</td><td class="fw-bold" id="grandTotal">UGX 0</td><td></td></tr></tfoot>
        </table>
        <button type="button" class="btn btn-outline-primary btn-sm" onclick="addLine()"><i class="fa-solid fa-plus me-1"></i>Add line</button>
        <div class="mt-3"><label class="form-label">Notes</label><textarea name="notes" class="form-control" rows="2"></textarea></div>
        <div class="alert alert-info small mt-3 mb-0">Saving a purchase does not change stock. Use "Receive" after review.</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary">Save Draft</button>
      </div>
    </form>
  </div>
</div>

<!-- Pay Modal (Same as before) -->
<div class="modal fade" id="payModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="post">
      <?= csrf_field() ?><input type="hidden" name="action" value="pay"><input type="hidden" name="id" id="payId">
      <div class="modal-header"><h5 class="modal-title">Record Payment</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <p class="small text-muted mb-2">Purchase: <strong id="payNumber"></strong></p>
        <div class="mb-3"><label class="form-label">Amount (Balance: <span id="payBalance"></span>)</label><input type="number" step="0.01" min="0.01" name="amount" id="payAmount" class="form-control" required></div>
        <div class="mb-3"><label class="form-label">Method</label><select name="method" class="form-select"><option value="cash">Cash</option><option value="mobile_money">Mobile Money</option><option value="bank">Bank</option><option value="other">Other</option></select></div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary">Save</button></div>
    </form>
  </div>
</div>

<script>
  window.__RP_PRODUCTS__ = <?= json_encode(array_map(fn($p) => ['id' => (int)$p['id'], 'label' => $p['name'] . ' (' . $p['sku'] . ')', 'cost' => (float)$p['buying_price']], $products), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
</script>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>