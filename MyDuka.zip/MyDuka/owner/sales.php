<?php
// owner/sales.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/stock.php';
require_role('owner');
require_permission('sale.view');

$pdo        = db();
$businessId = user_business_id();
$userId     = (int)current_user()['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post('action');
    $saleId = post_int('id');

    if ($action === 'cancel') {
        require_permission('sale.cancel');
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("SELECT * FROM sales WHERE id = ? AND business_id = ? FOR UPDATE");
            $stmt->execute([$saleId, $businessId]);
            $sale = $stmt->fetch();
            if (!$sale) throw new RuntimeException('Sale not found.');
            if ($sale['status'] === 'cancelled') throw new RuntimeException('Already cancelled.');
            if ($sale['status'] === 'returned')  throw new RuntimeException('Returned sales cannot be cancelled.');

            $items = $pdo->prepare("SELECT * FROM sale_items WHERE sale_id = ?");
            $items->execute([$saleId]);
            foreach ($items->fetchAll() as $it) {
                apply_stock_change($pdo, $businessId, (int)$sale['branch_id'], (int)$it['product_id'], +(float)$it['quantity'], 'sale_return', (float)$it['unit_cost'], 'sales', $saleId, "Cancellation of {$sale['sale_number']}", $userId);
            }

            $pdo->prepare("UPDATE sales SET status = 'cancelled' WHERE id = ?")->execute([$saleId]);
            audit_log('sale.cancel', 'sales', $saleId, ['number' => $sale['sale_number']], (int)$sale['branch_id']);
            $pdo->commit();
            flash('success', "Sale {$sale['sale_number']} cancelled. Stock restored.");
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Could not cancel sale.');
        }
        redirect('sales.php?' . http_build_query($_GET));
    }

    if ($action === 'return') {
        require_permission('sale.return');
        $reason = post('reason');
        try {
            if ($reason === '') throw new RuntimeException('Return reason is required.');

            $pdo->beginTransaction();
            $stmt = $pdo->prepare("SELECT * FROM sales WHERE id = ? AND business_id = ? FOR UPDATE");
            $stmt->execute([$saleId, $businessId]);
            $sale = $stmt->fetch();
            if (!$sale) throw new RuntimeException('Sale not found.');
            if (!in_array($sale['status'], ['completed','credit'], true)) throw new RuntimeException('Only completed/credit sales can be returned.');

            $items = $pdo->prepare("SELECT * FROM sale_items WHERE sale_id = ?");
            $items->execute([$saleId]);
            $items = $items->fetchAll();
            if (!$items) throw new RuntimeException('Sale has no items.');

            $returnNumber = generate_number('RET', 'sales_returns', 'return_number', $businessId);
            $returnTotal  = (float)$sale['total_amount'];

            $pdo->prepare(
                "INSERT INTO sales_returns (business_id, branch_id, sale_id, return_number, reason, total_amount, status, user_id)
                 VALUES (?, ?, ?, ?, ?, ?, 'accepted', ?)"
            )->execute([$businessId, (int)$sale['branch_id'], $saleId, $returnNumber, $reason, $returnTotal, $userId]);
            $returnId = (int)$pdo->lastInsertId();

            $rIns = $pdo->prepare("INSERT INTO sales_return_items (return_id, product_id, quantity, unit_price, line_total) VALUES (?, ?, ?, ?, ?)");
            foreach ($items as $it) {
                $rIns->execute([$returnId, (int)$it['product_id'], (float)$it['quantity'], (float)$it['unit_price'], (float)$it['line_total']]);
                apply_stock_change($pdo, $businessId, (int)$sale['branch_id'], (int)$it['product_id'], +(float)$it['quantity'], 'sale_return', (float)$it['unit_cost'], 'sales_returns', $returnId, "Return of {$sale['sale_number']}", $userId);
            }

            $pdo->prepare("UPDATE sales SET status = 'returned' WHERE id = ?")->execute([$saleId]);
            audit_log('sale.return', 'sales', $saleId, ['return' => $returnNumber, 'reason' => $reason]);
            $pdo->commit();
            flash('success', "Return {$returnNumber} recorded. Stock restored.");
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Could not process return.');
        }
        redirect('sales.php?' . http_build_query($_GET));
    }
}

$branchId = (int)get('branch', 0);
$from     = get('from', date('Y-m-d', strtotime('-30 days')));
$to       = get('to', date('Y-m-d'));
$statusFilter = get('status', '');
$search   = get('q');

$where  = "s.business_id = ? AND DATE(s.sale_date) BETWEEN ? AND ?";
$params = [$businessId, $from, $to];
if ($branchId > 0) {
    $where .= " AND s.branch_id = ?";
    $params[] = $branchId;
}
if (in_array($statusFilter, ['completed','credit','cancelled','returned'], true)) {
    $where .= " AND s.status = ?";
    $params[] = $statusFilter;
}
if ($search !== '') {
    $where .= " AND (s.sale_number LIKE ? OR u.full_name LIKE ?)";
    $like = "%{$search}%";
    array_push($params, $like, $like);
}

$stmt = $pdo->prepare(
    "SELECT s.*, b.name AS branch_name, u.full_name AS attendant
     FROM sales s JOIN branches b ON b.id = s.branch_id JOIN users u ON u.id = s.user_id
     WHERE {$where} ORDER BY s.sale_date DESC LIMIT 200"
);
$stmt->execute($params);
$sales = $stmt->fetchAll();

$allBranches = $pdo->prepare("SELECT id, name FROM branches WHERE business_id = ? AND status='active' ORDER BY is_main DESC, name");
$allBranches->execute([$businessId]);
$allBranches = $allBranches->fetchAll();

$pageTitle = 'Sales';
$breadcrumbs = ['Dashboard' => APP_URL . '/owner/dashboard.php', 'Sales' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; }
  
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }

  .filter-form { display: flex; gap: 0.5rem; background: #fff; padding: 0.35rem; border-radius: 10px; border: 1px solid #cbd5e1; margin-bottom: 1rem; flex-wrap: wrap; align-items: center; }
  .filter-form input, .filter-form select { border: none; border-radius: 6px; padding: 0.35rem 0.5rem; font-size: 0.8rem; font-weight: 500; color: #0f172a; background: transparent; }
  .filter-form input:focus, .filter-form select:focus { outline: none; background: #f8fafc; }

  .list-panel { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
  .list-item { display: flex; align-items: center; padding: 1.25rem 1.5rem; border-bottom: 1px solid #f1f5f9; transition: background 0.15s; flex-wrap: wrap; gap: 1rem; }
  .list-item:last-child { border-bottom: none; }
  .list-item:hover { background: #f8fafc; }
  
  .list-icon { width: 44px; height: 44px; border-radius: 12px; background: #eff6ff; color: #2563eb; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0; }
  
  .list-content { flex: 1; min-width: 200px; }
  .list-title { font-weight: 700; font-size: 0.95rem; color: #0f172a; margin-bottom: 0.15rem; text-decoration: none; display: inline-block; }
  .list-title:hover { color: #2563eb; }
  .list-sub { font-size: 0.75rem; color: #64748b; font-weight: 500; display: flex; gap: 0.5rem; align-items: center; }
  
  .list-meta { display: flex; gap: 1.5rem; text-align: right; align-items: center; }
  .meta-item { text-align: right; }
  .meta-val { font-weight: 700; font-size: 0.9rem; color: #0f172a; }
  .meta-lbl { font-size: 0.65rem; color: #94a3b8; font-weight: 600; text-transform: uppercase; }
  
  .list-actions { display: flex; gap: 0.5rem; align-items: center; }
  .btn-action { padding: 0.35rem 0.75rem; font-size: 0.75rem; font-weight: 600; border-radius: 6px; border: 1px solid #cbd5e1; background: #fff; color: #475569; transition: all 0.15s; text-decoration: none; display: inline-flex; align-items: center; gap: 0.25rem; }
  .btn-action:hover { background: #f1f5f9; color: #0f172a; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>Sales History</h1>
      <p>Review and manage all transactions.</p>
    </div>
  </div>

  <form class="filter-form" method="get">
    <input type="date" name="from" value="<?= e($from) ?>">
    <input type="date" name="to" value="<?= e($to) ?>">
    <select name="branch" onchange="this.form.submit()">
      <option value="0">All branches</option>
      <?php foreach ($allBranches as $b): ?>
        <option value="<?= (int)$b['id'] ?>" <?= $branchId === (int)$b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="status" onchange="this.form.submit()">
      <option value="">Any status</option>
      <?php foreach (['completed','credit','cancelled','returned'] as $st): ?>
        <option value="<?= $st ?>" <?= $statusFilter === $st ? 'selected' : '' ?>><?= ucfirst($st) ?></option>
      <?php endforeach; ?>
    </select>
    <input type="text" name="q" value="<?= e($search) ?>" placeholder="Receipt or attendant...">
    <button type="submit" class="btn btn-sm btn-dark">Filter</button>
  </form>

  <div class="list-panel">
    <?php if (!$sales): ?>
      <div class="text-center py-5">
        <i class="fa-solid fa-receipt text-muted mb-3" style="font-size: 3rem; opacity: 0.3;"></i>
        <h5 class="fw-bold text-dark">No sales found</h5>
        <p class="text-muted small">Try adjusting your filters.</p>
      </div>
    <?php else: foreach ($sales as $s): ?>
      <?php
        $statusColors = ['completed'=>'bg-success-subtle text-success', 'credit'=>'bg-warning-subtle text-warning', 'cancelled'=>'bg-secondary-subtle text-secondary', 'returned'=>'bg-danger-subtle text-danger'];
      ?>
      <div class="list-item">
        <div class="list-icon"><i class="fa-solid fa-file-invoice-dollar"></i></div>
        
        <div class="list-content">
          <a href="<?= e(APP_URL) ?>/receipt.php?id=<?= (int)$s['id'] ?>" target="_blank" class="list-title">
            <?= e($s['sale_number']) ?>
          </a>
          <span class="badge <?= $statusColors[$s['status']] ?> ms-2" style="font-size:0.6rem; letter-spacing:0.05em;"><?= strtoupper($s['status']) ?></span>
          <div class="list-sub">
            <i class="fa-regular fa-clock me-1"></i><?= human_datetime($s['sale_date']) ?>
            <span class="text-muted">•</span>
            <i class="fa-solid fa-user me-1"></i><?= e($s['attendant']) ?>
            <span class="text-muted">•</span>
            <i class="fa-solid fa-store me-1"></i><?= e($s['branch_name']) ?>
          </div>
        </div>

        <div class="list-meta">
          <div class="meta-item">
            <div class="meta-val"><?= money((float)$s['total_amount']) ?></div>
            <div class="meta-lbl">Total</div>
          </div>
          <div class="meta-item">
            <div class="meta-val text-success"><?= money((float)$s['paid_amount']) ?></div>
            <div class="meta-lbl">Paid</div>
          </div>
        </div>

        <div class="list-actions">
          <?php if (has_permission('sale.cancel') && in_array($s['status'], ['completed','credit'], true)): ?>
            <form method="post" class="m-0" onsubmit="return confirm('Cancel this sale?');">
              <?= csrf_field() ?><input type="hidden" name="action" value="cancel"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
              <button type="submit" class="btn-action"><i class="fa-solid fa-ban"></i> Cancel</button>
            </form>
          <?php endif; ?>
          <?php if (has_permission('sale.return') && in_array($s['status'], ['completed','credit'], true)): ?>
            <button class="btn-action text-danger" data-bs-toggle="modal" data-bs-target="#returnModal" data-id="<?= (int)$s['id'] ?>" data-number="<?= e($s['sale_number']) ?>">
              <i class="fa-solid fa-rotate-left"></i> Return
            </button>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<?php if (has_permission('sale.return')): ?>
<div class="modal fade" id="returnModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="post">
      <?= csrf_field() ?><input type="hidden" name="action" value="return"><input type="hidden" name="id" id="returnSaleId">
      <div class="modal-header">
        <h5 class="modal-title">Return Sale <span id="returnSaleNumber"></span></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="alert alert-info small">Records a full return. Stock is restored and sale is marked returned.</div>
        <label class="form-label">Reason</label>
        <textarea name="reason" class="form-control" rows="3" required placeholder="Reason..."></textarea>
        <input type="hidden" name="return_full" value="1">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-danger">Confirm Return</button>
      </div>
    </form>
  </div>
</div>
<script>
  document.getElementById('returnModal').addEventListener('show.bs.modal', ev => {
    const b = ev.relatedTarget; if (!b) return;
    document.getElementById('returnSaleId').value = b.dataset.id;
    document.getElementById('returnSaleNumber').textContent = b.dataset.number;
  });
</script>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>