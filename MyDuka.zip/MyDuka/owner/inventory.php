<?php
// owner/inventory.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/stock.php';
require_role('owner');
require_permission('inventory.view');

$pdo        = db();
$businessId = user_business_id();
$userId     = (int)current_user()['id'];
$branches   = user_branch_ids();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (post('action') === 'adjust') {
        require_permission('inventory.adjust');
        $productId = post_int('product_id');
        $branchId  = post_int('branch_id');
        $change    = post_float('qty_change');
        $reason    = post('reason');

        try {
            if (!in_array($branchId, $branches, true)) throw new RuntimeException('Invalid branch.');
            if ($change == 0) throw new RuntimeException('Quantity change must not be zero.');
            if ($reason === '') throw new RuntimeException('Reason is required.');
            $chk = $pdo->prepare("SELECT name FROM products WHERE id = ? AND business_id = ?");
            $chk->execute([$productId, $businessId]);
            $prod = $chk->fetch();
            if (!$prod) throw new RuntimeException('Invalid product.');

            $pdo->beginTransaction();
            $result = apply_stock_change($pdo, $businessId, $branchId, $productId, $change, 'adjustment', null, 'stock_adjustments', null, $reason, $userId);
            $pdo->prepare(
                "INSERT INTO stock_adjustments (business_id, branch_id, product_id, qty_change, reason, movement_id, user_id)
                 VALUES (?, ?, ?, ?, ?, ?, ?)"
            )->execute([$businessId, $branchId, $productId, $change, $reason, $result['movement_id'], $userId]);

            audit_log('inventory.adjust', 'inventory', $productId, ['qty_change' => $change, 'reason' => $reason], $branchId);
            $pdo->commit();
            flash('success', "Adjusted {$prod['name']} by " . ($change > 0 ? '+' : '') . num($change, 2) . '.');
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Adjustment failed.');
        }
        redirect('inventory.php?' . http_build_query($_GET));
    }
}

$branchFilter = (int)get('branch', $branches[0] ?? 0);
if (!in_array($branchFilter, $branches, true)) $branchFilter = $branches[0] ?? 0;
$search = get('q');
$lowOnly = (int)get('low', 0);

$where  = "i.business_id = ? AND i.branch_id = ?";
$params = [$businessId, $branchFilter];
if ($search !== '') {
    $where .= " AND (p.name LIKE ? OR p.sku LIKE ?)";
    $like = "%{$search}%";
    array_push($params, $like, $like);
}
if ($lowOnly) $where .= " AND i.quantity <= p.min_stock_level";

$stmt = $pdo->prepare(
    "SELECT i.*, p.name, p.sku, p.unit, p.min_stock_level, p.selling_price
     FROM inventory i JOIN products p ON p.id = i.product_id
     WHERE {$where} ORDER BY p.name LIMIT 200"
);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$historyProductId = (int)get('product', 0);
$history = [];
if ($historyProductId > 0) {
    $hstmt = $pdo->prepare(
        "SELECT sm.*, u.full_name AS user_name FROM stock_movements sm LEFT JOIN users u ON u.id = sm.user_id
         WHERE sm.business_id = ? AND sm.product_id = ? AND sm.branch_id = ?
         ORDER BY sm.created_at DESC LIMIT 100"
    );
    $hstmt->execute([$businessId, $historyProductId, $branchFilter]);
    $history = $hstmt->fetchAll();
}

$allBranches = $pdo->prepare("SELECT id, name FROM branches WHERE business_id = ? AND status='active' ORDER BY is_main DESC, name");
$allBranches->execute([$businessId]);
$allBranches = $allBranches->fetchAll();

$allProducts = $pdo->prepare("SELECT id, name, sku, unit FROM products WHERE business_id = ? AND status='active' ORDER BY name");
$allProducts->execute([$businessId]);
$allProducts = $allProducts->fetchAll();

$pageTitle = 'Inventory';
$breadcrumbs = ['Dashboard' => APP_URL . '/owner/dashboard.php', 'Inventory' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; }
  
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }

  .filter-form { display: flex; align-items: center; gap: 0.5rem; background: #fff; padding: 0.35rem; border-radius: 10px; border: 1px solid #cbd5e1; }
  .filter-form input, .filter-form select { border: none; border-radius: 6px; padding: 0.35rem 0.5rem; font-size: 0.8rem; font-weight: 500; color: #0f172a; background: transparent; }
  .filter-form input:focus, .filter-form select:focus { outline: none; background: #f8fafc; }

  /* Inventory List */
  .list-panel { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); margin-bottom: 1.5rem; }
  
  .list-item { display: flex; align-items: center; padding: 1rem 1.5rem; border-bottom: 1px solid #f1f5f9; transition: background 0.15s; }
  .list-item:last-child { border-bottom: none; }
  .list-item:hover { background: #f8fafc; }
  
  .list-icon { width: 40px; height: 40px; border-radius: 10px; background: #f1f5f9; color: #64748b; display: flex; align-items: center; justify-content: center; font-size: 1rem; margin-right: 1rem; }
  
  .list-content { flex: 1; min-width: 0; }
  .list-title { font-weight: 700; font-size: 0.9rem; color: #0f172a; margin-bottom: 0.1rem; }
  .list-sub { font-size: 0.75rem; color: #64748b; font-weight: 500; }
  
  .list-values { display: grid; grid-template-columns: 100px 100px 120px 80px; gap: 1rem; text-align: right; align-items: center; }
  .val-item { font-size: 0.85rem; font-weight: 600; color: #0f172a; }
  .val-label { font-size: 0.65rem; color: #94a3b8; text-transform: uppercase; font-weight: 700; letter-spacing: 0.05em; margin-bottom: 2px; }

  .badge-stock { font-size: 0.75rem; padding: 0.3rem 0.6rem; border-radius: 6px; font-weight: 700; display: inline-block; }
  .badge-out { background: #fee2e2; color: #b91c1c; }
  .badge-low { background: #fef3c7; color: #b45309; }
  .badge-good { background: #dcfce7; color: #15803d; }

  /* Timeline */
  .timeline { position: relative; padding-left: 1.5rem; margin: 0; list-style: none; }
  .timeline::before { content: ''; position: absolute; top: 0; bottom: 0; left: 5px; width: 2px; background: #e2e8f0; }
  .timeline-item { position: relative; margin-bottom: 1.25rem; }
  .timeline-marker { position: absolute; left: -1.5rem; top: 0.25rem; width: 12px; height: 12px; border-radius: 50%; background: #fff; border: 2px solid #3b82f6; }
  .timeline-marker.in { border-color: #16a34a; }
  .timeline-marker.out { border-color: #dc2626; }
  .timeline-content { background: #fff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 0.85rem 1rem; }
  .timeline-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.35rem; }
  .timeline-title { font-weight: 700; font-size: 0.85rem; color: #0f172a; margin: 0; text-transform: capitalize; }
  .timeline-date { font-size: 0.7rem; font-weight: 600; color: #94a3b8; }
  .timeline-body { display: flex; justify-content: space-between; align-items: center; font-size: 0.8rem; color: #64748b; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>Stock Levels</h1>
      <p>Monitoring inventory for <strong><?= e($allBranches[array_search($branchFilter, array_column($allBranches, 'id'))]['name'] ?? '') ?></strong></p>
    </div>
    <div class="d-flex gap-2 flex-wrap">
      <form class="filter-form" method="get">
        <select name="branch" onchange="this.form.submit()">
          <?php foreach ($allBranches as $b): ?>
            <option value="<?= (int)$b['id'] ?>" <?= $branchFilter === (int)$b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option>
          <?php endforeach; ?>
        </select>
        <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search SKU or Name...">
        <div class="form-check form-switch m-0 d-flex align-items-center gap-2 ps-4" style="border-left: 1px solid #e2e8f0;">
          <input class="form-check-input m-0" type="checkbox" name="low" value="1" id="lowSwitch" <?= $lowOnly ? 'checked' : '' ?> onchange="this.form.submit()">
          <label class="form-check-label small fw-bold text-danger" for="lowSwitch" style="cursor:pointer;">Low Stock Only</label>
        </div>
      </form>
      <?php if (has_permission('inventory.adjust')): ?>
        <button class="btn btn-primary fw-bold px-3" data-bs-toggle="modal" data-bs-target="#adjustModal" style="border-radius: 8px;">
          <i class="fa-solid fa-sliders me-1"></i> Adjust Stock
        </button>
      <?php endif; ?>
    </div>
  </div>

  <div class="list-panel">
    <div class="list-item" style="background: #f8fafc; border-bottom: 1px solid #e2e8f0; padding: 0.75rem 1.5rem;">
      <div class="list-content"></div>
      <div class="list-values">
        <div class="val-label">Quantity</div>
        <div class="val-label">Min Level</div>
        <div class="val-label">Avg Cost</div>
        <div class="val-label">History</div>
      </div>
    </div>

    <?php if (!$rows): ?>
      <div class="text-center py-5">
        <i class="fa-solid fa-boxes-stacked text-muted mb-3" style="font-size: 3rem; opacity: 0.3;"></i>
        <h5 class="fw-bold text-dark">No inventory found</h5>
        <p class="text-muted small">Try adjusting your filters or record a purchase.</p>
      </div>
    <?php else: foreach ($rows as $r): ?>
      <?php
        $qty = (float)$r['quantity'];
        $isOut = $qty <= 0;
        $isLow = $qty <= (float)$r['min_stock_level'];
        $badgeClass = $isOut ? 'badge-out' : ($isLow ? 'badge-low' : 'badge-good');
      ?>
      <div class="list-item">
        <div class="list-icon"><i class="fa-solid fa-cube"></i></div>
        <div class="list-content">
          <div class="list-title"><?= e($r['name']) ?></div>
          <div class="list-sub">SKU: <?= e($r['sku']) ?></div>
        </div>
        
        <div class="list-values">
          <div>
            <span class="badge-stock <?= $badgeClass ?>"><?= num($qty, 2) ?> <?= e($r['unit']) ?></span>
          </div>
          <div class="val-item text-muted"><?= num((float)$r['min_stock_level'], 2) ?></div>
          <div class="val-item"><?= money((float)$r['weighted_avg_cost']) ?></div>
          <div>
            <a href="?<?= e(http_build_query(array_merge($_GET, ['product' => (int)$r['product_id']]))) ?>" class="btn btn-sm btn-outline-secondary" style="border-radius:6px; font-size:0.7rem;">View</a>
          </div>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>

  <?php if ($historyProductId > 0 && $history): ?>
    <div class="mt-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="fw-bold m-0">Movement History</h5>
        <a href="?<?= e(http_build_query(array_diff_key($_GET, ['product' => 1]))) ?>" class="btn btn-sm btn-light border">Close Timeline</a>
      </div>
      <ul class="timeline">
        <?php foreach ($history as $h): ?>
          <?php $isIn = (float)$h['quantity'] > 0; ?>
          <li class="timeline-item">
            <div class="timeline-marker <?= $isIn ? 'in' : 'out' ?>"></div>
            <div class="timeline-content">
              <div class="timeline-header">
                <h6 class="timeline-title"><?= e(str_replace('_', ' ', $h['movement_type'])) ?></h6>
                <span class="timeline-date"><?= human_datetime($h['created_at']) ?></span>
              </div>
              <div class="timeline-body">
                <span><?= e($h['reason'] ?: 'No reason provided') ?> <span class="text-muted">(<?= e($h['user_name']) ?>)</span></span>
                <strong class="<?= $isIn ? 'text-success' : 'text-danger' ?>">
                  <?= $isIn ? '+' : '' ?><?= num((float)$h['quantity'], 2) ?>
                </strong>
              </div>
            </div>
          </li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>
</div>

<?php if (has_permission('inventory.adjust')): ?>
<div class="modal fade" id="adjustModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="adjust">
      <div class="modal-header">
        <h5 class="modal-title">Adjust Stock</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label class="form-label">Branch</label>
          <select name="branch_id" class="form-select" required>
            <?php foreach ($allBranches as $b): ?>
              <option value="<?= (int)$b['id'] ?>" <?= $branchFilter === (int)$b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-3">
          <label class="form-label">Product</label>
          <select name="product_id" class="form-select" required>
            <option value="">— Select product —</option>
            <?php foreach ($allProducts as $p): ?>
              <option value="<?= (int)$p['id'] ?>"><?= e($p['name']) ?> (<?= e($p['sku']) ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-3">
          <label class="form-label">Qty change <small class="text-muted">(negative to reduce)</small></label>
          <input type="number" step="0.001" name="qty_change" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Reason</label>
          <input type="text" name="reason" class="form-control" placeholder="e.g. Damaged goods, expiry, correction" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary">Apply Adjustment</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>