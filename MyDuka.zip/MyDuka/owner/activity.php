<?php
// owner/activity.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_role('owner');
require_permission('audit.view');

$pdo        = db();
$businessId = user_business_id();
$search     = get('q');
$userId     = (int)get('user', 0);
$from       = get('from', date('Y-m-01'));
$to         = get('to',   date('Y-m-d'));

$where = "a.business_id = ? AND DATE(a.created_at) BETWEEN ? AND ?";
$params = [$businessId, $from, $to];
if ($userId > 0) { $where .= " AND a.user_id = ?"; $params[] = $userId; }
if ($search !== '') { $where .= " AND a.action LIKE ?"; $params[] = "%{$search}%"; }

$stmt = $pdo->prepare("SELECT a.*, u.full_name AS user_name, b.name AS branch_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id LEFT JOIN branches b ON b.id = a.branch_id WHERE {$where} ORDER BY a.created_at DESC LIMIT 500");
$stmt->execute($params);
$logs = $stmt->fetchAll();

$users = $pdo->prepare("SELECT id, full_name FROM users WHERE business_id = ? ORDER BY full_name");
$users->execute([$businessId]);
$users = $users->fetchAll();

$pageTitle = 'Activity Logs';
$breadcrumbs = ['Dashboard' => APP_URL . '/owner/dashboard.php', 'Activity Logs' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; }
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }

  .filter-bar { display: flex; gap: 0.5rem; background: #fff; padding: 0.35rem; border-radius: 10px; border: 1px solid #cbd5e1; margin-bottom: 1.5rem; flex-wrap: wrap; align-items: center; }
  .filter-bar input, .filter-bar select { border: none; border-radius: 6px; padding: 0.35rem 0.5rem; font-size: 0.8rem; font-weight: 500; color: #0f172a; background: transparent; }
  .filter-bar input:focus, .filter-bar select:focus { outline: none; background: #f8fafc; }

  .timeline { position: relative; padding-left: 2rem; margin: 0; list-style: none; }
  .timeline::before { content: ''; position: absolute; top: 0; bottom: 0; left: 7px; width: 2px; background: #e2e8f0; }
  .timeline-item { position: relative; margin-bottom: 1.5rem; }
  .timeline-marker { position: absolute; left: -2rem; top: 0.25rem; width: 16px; height: 16px; border-radius: 50%; background: #fff; border: 3px solid #3b82f6; }
  .timeline-content { background: #fff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 1rem; box-shadow: 0 2px 4px -1px rgba(0,0,0,0.02); }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>Activity Logs</h1>
      <p>Immutable audit trail of every action in your business.</p>
    </div>
  </div>

  <form class="filter-bar" method="get">
    <input type="date" name="from" value="<?= e($from) ?>">
    <input type="date" name="to" value="<?= e($to) ?>">
    <select name="user">
      <option value="0">All users</option>
      <?php foreach ($users as $u): ?>
        <option value="<?= (int)$u['id'] ?>" <?= $userId === (int)$u['id'] ? 'selected' : '' ?>><?= e($u['full_name']) ?></option>
      <?php endforeach; ?>
    </select>
    <input type="text" name="q" value="<?= e($search) ?>" placeholder="Action code (e.g. sale.create)...">
    <button type="submit" class="btn btn-sm btn-dark">Filter</button>
  </form>

  <?php if (!$logs): ?>
    <div class="text-center py-5 bg-white rounded-3 border">
      <i class="fa-solid fa-shield-halved text-muted mb-3" style="font-size: 3rem; opacity: 0.3;"></i>
      <h5 class="fw-bold text-dark">No activity found</h5>
      <p class="text-muted small">No logs match your current filters.</p>
    </div>
  <?php else: ?>
    <ul class="timeline">
      <?php foreach ($logs as $l): ?>
        <li class="timeline-item">
          <div class="timeline-marker"></div>
          <div class="timeline-content">
            <div class="d-flex justify-content-between align-items-start mb-2">
              <div>
                <span class="fw-bold text-dark"><?= e($l['user_name'] ?: 'System') ?></span>
                <span class="text-muted small ms-2">performed</span>
                <code class="ms-1"><?= e($l['action']) ?></code>
              </div>
              <small class="text-muted fw-bold"><?= human_datetime($l['created_at']) ?></small>
            </div>
            <div class="d-flex gap-3 text-muted small">
              <?php if ($l['entity']): ?>
                <span><i class="fa-solid fa-cube me-1"></i>Entity: <?= e($l['entity']) ?> <?= $l['entity_id'] ? '#'.$l['entity_id'] : '' ?></span>
              <?php endif; ?>
              <?php if ($l['branch_name']): ?>
                <span><i class="fa-solid fa-store me-1"></i><?= e($l['branch_name']) ?></span>
              <?php endif; ?>
              <span><i class="fa-solid fa-location-crosshairs me-1"></i>IP: <?= e($l['ip_address'] ?: '—') ?></span>
            </div>
          </div>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>