<?php
// owner/categories.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/uploads.php';
require_role('owner');
require_permission('category.view');

$pdo        = db();
$businessId = user_business_id();

// ---- Actions ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post('action');

    if ($action === 'save') {
        require_permission('category.manage');
        $id   = post_int('id');
        $name = post('name');
        $desc = post('description');

        if ($name === '') {
            flash('danger', 'Category name is required.');
        } else {
            $dup = $pdo->prepare("SELECT id FROM categories WHERE business_id = ? AND name = ? AND id <> ? LIMIT 1");
            $dup->execute([$businessId, $name, $id]);
            if ($dup->fetchColumn()) {
                flash('danger', 'A category with that name already exists.');
            } elseif ($id > 0) {
                $chk = $pdo->prepare("SELECT 1 FROM categories WHERE id = ? AND business_id = ?");
                $chk->execute([$id, $businessId]);
                if ($chk->fetchColumn()) {
                    $pdo->prepare("UPDATE categories SET name = ?, description = ? WHERE id = ?")
                        ->execute([$name, $desc ?: null, $id]);
                    audit_log('category.update', 'categories', $id, ['name' => $name]);
                    flash('success', 'Category updated.');
                }
            } else {
                $pdo->prepare("INSERT INTO categories (business_id, name, description) VALUES (?, ?, ?)")
                    ->execute([$businessId, $name, $desc ?: null]);
                $newId = (int)$pdo->lastInsertId();
                audit_log('category.create', 'categories', $newId, ['name' => $name]);
                flash('success', 'Category created.');
            }
        }
    }

    if ($action === 'archive' || $action === 'restore') {
        require_permission('category.manage');
        $id = post_int('id');
        $newStatus = $action === 'archive' ? 'archived' : 'active';
        $chk = $pdo->prepare("SELECT 1 FROM categories WHERE id = ? AND business_id = ?");
        $chk->execute([$id, $businessId]);
        if ($chk->fetchColumn()) {
            $pdo->prepare("UPDATE categories SET status=? WHERE id = ?")->execute([$newStatus, $id]);
            audit_log("category.$action", 'categories', $id);
            flash('success', "Category $newStatus.");
        }
    }
    redirect('categories.php');
}

// ---- Load ----
$search = get('q');
$status = get('status', 'active');
$where  = "business_id = ?";
$params = [$businessId];
if ($status === 'active' || $status === 'archived') {
    $where .= " AND status = ?";
    $params[] = $status;
}
if ($search !== '') {
    $where .= " AND name LIKE ?";
    $params[] = "%{$search}%";
}
$stmt = $pdo->prepare(
    "SELECT c.*,
            (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id AND p.business_id = c.business_id) AS product_count
     FROM categories c
     WHERE {$where}
     ORDER BY c.name"
);
$stmt->execute($params);
$categories = $stmt->fetchAll();

$pageTitle = 'Categories';
$breadcrumbs = ['Dashboard' => APP_URL . '/owner/dashboard.php', 'Categories' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; max-width: 1000px; }
  
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }

  .filter-form { display: flex; gap: 0.5rem; background: #fff; padding: 0.35rem; border-radius: 10px; border: 1px solid #cbd5e1; }
  .filter-form input, .filter-form select { border: none; border-radius: 6px; padding: 0.35rem 0.5rem; font-size: 0.8rem; font-weight: 500; color: #0f172a; background: transparent; }
  .filter-form input:focus, .filter-form select:focus { outline: none; background: #f8fafc; }

  /* List View */
  .list-panel { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
  
  .list-item { display: flex; align-items: center; padding: 1.25rem 1.5rem; border-bottom: 1px solid #f1f5f9; transition: background 0.15s; }
  .list-item:last-child { border-bottom: none; }
  .list-item:hover { background: #f8fafc; }
  
  .list-icon { width: 44px; height: 44px; border-radius: 10px; background: #eff6ff; color: #2563eb; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; margin-right: 1.25rem; }
  
  .list-content { flex: 1; min-width: 0; }
  .list-title { font-weight: 700; font-size: 0.95rem; color: #0f172a; margin-bottom: 0.15rem; }
  .list-desc { font-size: 0.8rem; color: #64748b; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 400px; }
  
  .list-meta { text-align: right; margin-right: 2rem; }
  .list-count { font-weight: 800; font-size: 1.1rem; color: #0f172a; line-height: 1; }
  .list-meta-label { font-size: 0.7rem; color: #94a3b8; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; margin-top: 2px; }

  .list-actions { display: flex; gap: 0.5rem; }
  .btn-icon { width: 32px; height: 32px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; border: 1px solid #cbd5e1; background: #fff; color: #475569; cursor: pointer; transition: all 0.15s; }
  .btn-icon:hover { background: #f8fafc; color: #0f172a; border-color: #94a3b8; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>Categories</h1>
      <p><?= count($categories) ?> categor<?= count($categories) === 1 ? 'y' : 'ies' ?> configured</p>
    </div>
    <div class="d-flex gap-2 flex-wrap">
      <form class="filter-form" method="get">
        <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search categories...">
        <select name="status" onchange="this.form.submit()">
          <option value="active" <?= $status==='active' ? 'selected':'' ?>>Active</option>
          <option value="archived" <?= $status==='archived' ? 'selected':'' ?>>Archived</option>
          <option value="" <?= $status==='' ? 'selected':'' ?>>All</option>
        </select>
      </form>
      <?php if (has_permission('category.manage')): ?>
        <button class="btn btn-primary fw-bold px-3" data-bs-toggle="modal" data-bs-target="#categoryModal" onclick="openCategory(null)" style="border-radius: 8px;">
          <i class="fa-solid fa-plus me-1"></i> New Category
        </button>
      <?php endif; ?>
    </div>
  </div>

  <?php if (!$categories): ?>
    <div class="text-center py-5 bg-white rounded-3 border">
      <i class="fa-solid fa-tags text-muted mb-3" style="font-size: 3rem; opacity: 0.3;"></i>
      <h5 class="fw-bold text-dark">No categories found</h5>
      <p class="text-muted small">Create your first category to organize products.</p>
    </div>
  <?php else: ?>
    <div class="list-panel">
      <?php foreach ($categories as $c): ?>
        <div class="list-item">
          <div class="list-icon">
            <i class="fa-solid fa-tag"></i>
          </div>
          
          <div class="list-content">
            <div class="list-title">
              <?= e($c['name']) ?>
              <?php if ($c['status'] === 'archived'): ?>
                <span class="badge bg-secondary ms-2" style="font-size:0.6rem;">Archived</span>
              <?php endif; ?>
            </div>
            <div class="list-desc"><?= e($c['description'] ?: 'No description provided.') ?></div>
          </div>
          
          <div class="list-meta">
            <div class="list-count"><?= (int)$c['product_count'] ?></div>
            <div class="list-meta-label">Products</div>
          </div>
          
          <?php if (has_permission('category.manage')): ?>
            <div class="list-actions">
              <button class="btn-icon" onclick='openCategory(<?= json_encode($c) ?>)' title="Edit">
                <i class="fa-solid fa-pen"></i>
              </button>
              
              <?php if ($c['status'] === 'active'): ?>
                <form method="post" class="m-0" onsubmit="return confirm('Archive this category?');">
                  <?= csrf_field() ?><input type="hidden" name="action" value="archive"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                  <button type="submit" class="btn-icon" title="Archive"><i class="fa-solid fa-box-archive"></i></button>
                </form>
              <?php else: ?>
                <form method="post" class="m-0">
                  <?= csrf_field() ?><input type="hidden" name="action" value="restore"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                  <button type="submit" class="btn-icon text-success" title="Restore"><i class="fa-solid fa-rotate-left"></i></button>
                </form>
              <?php endif; ?>
            </div>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php if (has_permission('category.manage')): ?>
<div class="modal fade" id="categoryModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" id="catId" value="0">
      <div class="modal-header">
        <h5 class="modal-title" id="catTitle">New Category</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label class="form-label">Name</label>
          <input type="text" name="name" id="catName" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Description <span class="text-muted small">(optional)</span></label>
          <textarea name="description" id="catDesc" class="form-control" rows="2"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>
<script>
function openCategory(cat) {
  document.getElementById('catId').value = cat ? cat.id : 0;
  document.getElementById('catName').value = cat ? cat.name : '';
  document.getElementById('catDesc').value = cat ? (cat.description || '') : '';
  document.getElementById('catTitle').textContent = cat ? 'Edit Category' : 'New Category';
  new bootstrap.Modal(document.getElementById('categoryModal')).show();
}
</script>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>