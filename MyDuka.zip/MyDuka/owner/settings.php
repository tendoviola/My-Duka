<?php
// owner/settings.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/uploads.php';
require_role('owner');

$pdo        = db();
$businessId = user_business_id();
$userId     = (int)current_user()['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post('action');

    if ($action === 'business') {
        $name    = post('name');
        $phone   = post('phone');
        $email   = post('email');
        $address = post('address');

        $errors = [];
        if ($name === '') $errors[] = 'Business name is required.';
        if ($email !== '' && !valid_email($email)) $errors[] = 'Invalid business email.';

        $newLogo = null;
        try { $newLogo = handle_image_upload($_FILES['logo'] ?? [], 'logos'); }
        catch (Throwable $ex) { $errors[] = $ex->getMessage(); }

        if ($errors) { foreach ($errors as $e) flash('danger', $e); }
        else {
            $logoPath = null;
            if ($newLogo) {
                $old = $pdo->query("SELECT logo_path FROM businesses WHERE id = $businessId")->fetchColumn();
                if ($old) delete_upload($old);
                $logoPath = $newLogo;
                $pdo->prepare("UPDATE businesses SET logo_path = ? WHERE id = ?")->execute([$logoPath, $businessId]);
            }
            $pdo->prepare("UPDATE businesses SET name=?, phone=?, email=?, address=? WHERE id=?")
                ->execute([$name, $phone ?: null, $email ?: null, $address ?: null, $businessId]);
            audit_log('business.update', 'businesses', $businessId);
            flash('success', 'Business details updated.');
        }
        redirect('settings.php?tab=brand');
    }

    if ($action === 'settings') {
        $taxRate   = (float)post('default_tax_rate');
        $allowNeg  = post_int('allow_negative_stock') ? 1 : 0;
        $footer    = post('receipt_footer');
        if ($taxRate < 0 || $taxRate > 100) { flash('danger', 'Tax rate must be between 0 and 100.'); }
        else {
            $pdo->prepare(
                "INSERT INTO business_settings (business_id, default_tax_rate, allow_negative_stock, receipt_footer)
                 VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE default_tax_rate=VALUES(default_tax_rate),
                    allow_negative_stock=VALUES(allow_negative_stock), receipt_footer=VALUES(receipt_footer)"
            )->execute([$businessId, $taxRate, $allowNeg, $footer ?: null]);
            audit_log('settings.update', 'business_settings', $businessId);
            flash('success', 'Settings updated.');
        }
        redirect('settings.php?tab=operations');
    }

    if ($action === 'password') {
        $current = post('current_password');
        $new     = post('new_password');
        $confirm = post('confirm_password');

        $errors = [];
        $u = current_user();
        if (!password_verify($current, $u['password_hash'])) $errors[] = 'Current password is incorrect.';
        if (strlen($new) < PASSWORD_MIN_LEN) $errors[] = 'New password too short.';
        if ($new !== $confirm) $errors[] = 'Passwords do not match.';

        if ($errors) { foreach ($errors as $e) flash('danger', $e); }
        else {
            $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?")
                ->execute([password_hash($new, PASSWORD_DEFAULT), $userId]);
            audit_log('user.password_changed', 'users', $userId);
            flash('success', 'Password updated.');
        }
        redirect('settings.php?tab=security');
    }
}

$business = $pdo->prepare("SELECT * FROM businesses WHERE id = ?"); $business->execute([$businessId]); $business = $business->fetch();
$settings = $pdo->prepare("SELECT * FROM business_settings WHERE business_id = ?"); $settings->execute([$businessId]); $settings = $settings->fetch() ?: ['default_tax_rate' => 0, 'allow_negative_stock' => 0, 'receipt_footer' => ''];

$tab = get('tab', 'brand');
if (!in_array($tab, ['brand', 'operations', 'security'], true)) $tab = 'brand';

$pageTitle = 'Settings';
$breadcrumbs = ['Dashboard' => APP_URL . '/owner/dashboard.php', 'Settings' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; max-width: 900px; margin: 0 auto; }
  .page-header { margin-bottom: 2rem; text-align: center; }
  .page-header h1 { font-weight: 800; font-size: 1.75rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.95rem; color: #64748b; font-weight: 500; margin-top: 0.5rem; }

  /* Tabs */
  .settings-tabs { display: flex; gap: 1rem; border-bottom: 2px solid #e2e8f0; margin-bottom: 2rem; }
  .settings-tab {
    padding: 0.75rem 1rem; font-weight: 600; font-size: 0.9rem; color: #64748b;
    text-decoration: none; border-bottom: 2px solid transparent; margin-bottom: -2px;
    transition: all 0.15s; cursor: pointer;
  }
  .settings-tab:hover { color: #0f172a; }
  .settings-tab.active { color: #2563eb; border-bottom-color: #2563eb; }

  /* Cards */
  .settings-card { background: #fff; border: 1px solid #e2e8f0; border-radius: 16px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); overflow: hidden; }
  .settings-header { padding: 1.5rem; border-bottom: 1px solid #f1f5f9; }
  .settings-header h3 { font-size: 1.1rem; font-weight: 700; color: #0f172a; margin: 0 0 0.25rem 0; }
  .settings-header p { font-size: 0.85rem; color: #64748b; margin: 0; }
  .settings-body { padding: 1.5rem; }
  
  .form-control, .form-select { border-radius: 10px; border: 1px solid #cbd5e1; padding: 0.75rem 1rem; font-size: 0.9rem; font-weight: 500; background: #f8fafc; transition: all 0.2s; }
  .form-control:focus, .form-select:focus { border-color: #3b82f6; background: #fff; box-shadow: 0 0 0 3px rgba(59,130,246,0.1); outline: none; }
  .form-label { font-size: 0.8rem; font-weight: 700; color: #334155; margin-bottom: 0.4rem; }
  
  /* Password specific */
  .input-wrapper { position: relative; }
  .toggle-password { position: absolute; right: 0.75rem; top: 50%; transform: translateY(-50%); background: none; border: none; color: #94a3b8; cursor: pointer; padding: 0.25rem; font-size: 1rem; transition: color 0.2s; }
  .toggle-password:hover { color: #475569; }
  
  .requirements { list-style: none; padding: 0; margin: 1rem 0 0 0; }
  .requirements li { font-size: 0.8rem; font-weight: 500; color: #94a3b8; margin-bottom: 0.4rem; display: flex; align-items: center; gap: 0.5rem; transition: all 0.2s ease; }
  .requirements li i { font-size: 0.9rem; color: #cbd5e1; }
  .requirements li.met { color: #16a34a; }
  .requirements li.met i { color: #16a34a; }

  .btn-save { background: #0f172a; color: #fff; font-weight: 700; padding: 0.75rem 1.5rem; border-radius: 10px; transition: all 0.2s; border: none; }
  .btn-save:hover { background: #1e293b; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <h1>Workspace Settings</h1>
    <p>Manage your brand identity, operational rules, and account security.</p>
  </div>

  <div class="settings-tabs">
    <a class="settings-tab <?= $tab === 'brand' ? 'active' : '' ?>" href="?tab=brand">Brand Details</a>
    <a class="settings-tab <?= $tab === 'operations' ? 'active' : '' ?>" href="?tab=operations">Operations</a>
    <a class="settings-tab <?= $tab === 'security' ? 'active' : '' ?>" href="?tab=security">Security</a>
  </div>

  <?php if ($tab === 'brand'): ?>
    <!-- BRAND TAB -->
    <div class="settings-card">
      <div class="settings-header">
        <h3>Brand Identity</h3>
        <p>This information appears on your receipts and customer emails.</p>
      </div>
      <div class="settings-body">
        <form method="post" enctype="multipart/form-data">
          <?= csrf_field() ?><input type="hidden" name="action" value="business">
          
          <div class="row g-4">
            <div class="col-md-12">
              <label class="form-label">Business Name</label>
              <input type="text" name="name" class="form-control" value="<?= e($business['name']) ?>" required>
            </div>
            
            <div class="col-md-6">
              <label class="form-label">Contact Phone</label>
              <input type="text" name="phone" class="form-control" value="<?= e($business['phone']) ?>" placeholder="+256...">
            </div>
            <div class="col-md-6">
              <label class="form-label">Contact Email</label>
              <input type="email" name="email" class="form-control" value="<?= e($business['email']) ?>">
            </div>
            
            <div class="col-12">
              <label class="form-label">Physical Address</label>
              <input type="text" name="address" class="form-control" value="<?= e($business['address']) ?>">
            </div>
            
            <div class="col-12">
              <label class="form-label">Business Logo</label>
              <div class="d-flex align-items-center gap-3">
                <?php if ($business['logo_path'] && ($u = upload_url($business['logo_path']))): ?>
                  <img src="<?= e($u) ?>" style="height:56px; width:56px; object-fit:cover; border-radius: 12px; border: 1px solid #e2e8f0;">
                <?php else: ?>
                  <div class="d-flex align-items-center justify-content-center bg-light text-muted" style="height:56px; width:56px; border-radius:12px; border: 1px solid #e2e8f0;"><i class="fa-solid fa-store"></i></div>
                <?php endif; ?>
                <input type="file" name="logo" class="form-control" accept="image/*">
              </div>
            </div>
          </div>

          <div class="mt-5 pt-3 border-top">
            <button type="submit" class="btn-save">Save Brand Details</button>
          </div>
        </form>
      </div>
    </div>

  <?php elseif ($tab === 'operations'): ?>
    <!-- OPERATIONS TAB -->
    <div class="settings-card">
      <div class="settings-header">
        <h3>Operational Rules</h3>
        <p>Configure how the POS and inventory behave globally.</p>
      </div>
      <div class="settings-body">
        <form method="post">
          <?= csrf_field() ?><input type="hidden" name="action" value="settings">
          
          <div class="row g-4">
            <div class="col-md-6">
              <label class="form-label">Default Tax Rate (%)</label>
              <input type="number" step="0.01" min="0" max="100" name="default_tax_rate" class="form-control" value="<?= e((string)$settings['default_tax_rate']) ?>">
              <small class="text-muted mt-1 d-block">Applied automatically to POS totals.</small>
            </div>
            
            <div class="col-12">
              <div class="form-check form-switch p-3 bg-light rounded-3 border">
                <input class="form-check-input ms-0 me-3" type="checkbox" name="allow_negative_stock" value="1" id="allowNeg" <?= $settings['allow_negative_stock'] ? 'checked' : '' ?>>
                <label class="form-check-label fw-bold text-dark" for="allowNeg">Allow Negative Stock</label>
                <div class="text-muted small ms-5 ps-2">If enabled, employees can sell items even if inventory shows 0.</div>
              </div>
            </div>

            <div class="col-12">
              <label class="form-label">Receipt Footer Message</label>
              <textarea name="receipt_footer" class="form-control" rows="3" placeholder="Thank you for shopping with us!"><?= e($settings['receipt_footer']) ?></textarea>
            </div>
          </div>

          <div class="mt-5 pt-3 border-top">
            <button type="submit" class="btn-save">Save Operational Settings</button>
          </div>
        </form>
      </div>
    </div>

  <?php elseif ($tab === 'security'): ?>
    <!-- SECURITY TAB -->
    <div class="settings-card">
      <div class="settings-header">
        <h3>Change Password</h3>
        <p>Ensure your account stays secure by using a strong password.</p>
      </div>
      <div class="settings-body">
        <form method="post" id="passwordForm">
          <?= csrf_field() ?><input type="hidden" name="action" value="password">
          
          <div class="row g-4">
            <div class="col-12">
              <label class="form-label">Current Password</label>
              <div class="input-wrapper">
                <input type="password" name="current_password" id="current_password" class="form-control" required>
                <button type="button" class="toggle-password" data-target="current_password"><i class="fa-regular fa-eye"></i></button>
              </div>
            </div>
            
            <div class="col-md-6">
              <label class="form-label">New Password</label>
              <div class="input-wrapper">
                <input type="password" name="new_password" id="new_password" class="form-control" minlength="<?= PASSWORD_MIN_LEN ?>" required>
                <button type="button" class="toggle-password" data-target="new_password"><i class="fa-regular fa-eye"></i></button>
              </div>
            </div>
            
            <div class="col-md-6">
              <label class="form-label">Confirm New Password</label>
              <div class="input-wrapper">
                <input type="password" name="confirm_password" id="confirm_password" class="form-control" required>
                <button type="button" class="toggle-password" data-target="confirm_password"><i class="fa-regular fa-eye"></i></button>
              </div>
            </div>

            <div class="col-12 mt-3">
              <ul class="requirements" id="reqList">
                <li id="req-length"><i class="fa-solid fa-circle"></i> At least <?= PASSWORD_MIN_LEN ?> characters</li>
                <li id="req-upper"><i class="fa-solid fa-circle"></i> Contains upper & lowercase letters</li>
                <li id="req-number"><i class="fa-solid fa-circle"></i> Contains at least one number</li>
                <li id="req-match"><i class="fa-solid fa-circle"></i> Passwords match</li>
              </ul>
            </div>
          </div>

          <div class="mt-5 pt-3 border-top">
            <button type="submit" class="btn-save" id="submitBtn" disabled>Update Password</button>
          </div>
        </form>
      </div>
    </div>
  <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  // Toggle Password Visibility
  document.querySelectorAll('.toggle-password').forEach(btn => {
    btn.addEventListener('click', function() {
      const input = document.getElementById(this.dataset.target);
      const icon = this.querySelector('i');
      if (input.type === 'password') {
        input.type = 'text';
        icon.classList.replace('fa-eye', 'fa-eye-slash');
        this.style.color = '#2563eb';
      } else {
        input.type = 'password';
        icon.classList.replace('fa-eye-slash', 'fa-eye');
        this.style.color = '#94a3b8';
      }
    });
  });

  // Live Password Validation
  const newPass = document.getElementById('new_password');
  if (!newPass) return; // Only run on security tab

  const confirmPass = document.getElementById('confirm_password');
  const currentPass = document.getElementById('current_password');
  const submitBtn = document.getElementById('submitBtn');
  
  const reqLength = document.getElementById('req-length');
  const reqUpper = document.getElementById('req-upper');
  const reqNumber = document.getElementById('req-number');
  const reqMatch = document.getElementById('req-match');

  function validate() {
    const val = newPass.value;
    const confirmVal = confirmPass.value;
    
    const isLength = val.length >= <?= PASSWORD_MIN_LEN ?>;
    const isUpper = /[A-Z]/.test(val) && /[a-z]/.test(val);
    const isNumber = /[0-9]/.test(val);
    const isMatch = val.length > 0 && val === confirmVal;

    reqLength.classList.toggle('met', isLength);
    reqUpper.classList.toggle('met', isUpper);
    reqNumber.classList.toggle('met', isNumber);
    reqMatch.classList.toggle('met', isMatch);

    [reqLength, reqUpper, reqNumber, reqMatch].forEach(li => {
      const icon = li.querySelector('i');
      if (li.classList.contains('met')) icon.classList.replace('fa-circle', 'fa-circle-check');
      else icon.classList.replace('fa-circle-check', 'fa-circle');
    });

    let allValid = isLength && isUpper && isNumber && isMatch;
    if (currentPass) allValid = allValid && currentPass.value.length > 0;
    submitBtn.disabled = !allValid;
  }

  newPass.addEventListener('input', validate);
  confirmPass.addEventListener('input', validate);
  if (currentPass) currentPass.addEventListener('input', validate);
});
</script>

<?php require __DIR__ . '/../includes/footer.php'; ?>