<?php
// owner/dashboard.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_role('owner');

$pdo = db();
$businessId = user_business_id();
$branches = $pdo->prepare("SELECT id, name FROM branches WHERE business_id = ? AND status='active' ORDER BY is_main DESC, name");
$branches->execute([$businessId]);
$branches = $branches->fetchAll();

// ---- Filter ----
$branchFilter = (int)get('branch', 0);
$whereBranch  = '';
$params       = [$businessId];
if ($branchFilter > 0 && in_array($branchFilter, array_map(fn($b)=>(int)$b['id'], $branches), true)) {
    $whereBranch = ' AND branch_id = ?';
    $params[] = $branchFilter;
} else {
    $branchFilter = 0;
}

// Today's sales + profit
$stmt = $pdo->prepare(
    "SELECT COALESCE(SUM(total_amount),0) AS revenue,
            COALESCE(SUM(gross_profit),0) AS gp,
            COUNT(*) AS sales_count
     FROM sales
     WHERE business_id = ? AND status IN ('completed','credit')
       AND DATE(sale_date) = CURDATE(){$whereBranch}"
);
$stmt->execute($params);
$today = $stmt->fetch();

// Total expenses (this month)
$stmt = $pdo->prepare(
    "SELECT COALESCE(SUM(amount),0) FROM expenses
     WHERE business_id = ? AND MONTH(expense_date)=MONTH(CURDATE())
       AND YEAR(expense_date)=YEAR(CURDATE()){$whereBranch}"
);
$stmt->execute($params);
$monthExpenses = (float)$stmt->fetchColumn();

// Inventory aggregate (stock value)
$stmt = $pdo->prepare(
    "SELECT COALESCE(SUM(inv.quantity * inv.weighted_avg_cost),0) AS stock_value,
            COUNT(DISTINCT inv.product_id) AS product_count
     FROM inventory inv
     WHERE inv.business_id = ?{$whereBranch}"
);
$stmt->execute($params);
$inv = $stmt->fetch();

// Low stock count
$stmt = $pdo->prepare(
    "SELECT COUNT(*) FROM inventory inv
     JOIN products p ON p.id = inv.product_id
     WHERE inv.business_id = ? AND inv.quantity > 0
       AND inv.quantity <= p.min_stock_level{$whereBranch}"
);
$stmt->execute($params);
$lowStockCount = (int)$stmt->fetchColumn();

// Net operating profit = GP - expenses
$netOperating = (float)$today['gp'] - (float)$monthExpenses;

// ---- Sales trend (last 7 days) ----
$stmt = $pdo->prepare(
    "SELECT DATE(sale_date) AS d,
            COALESCE(SUM(total_amount),0) AS revenue,
            COALESCE(SUM(gross_profit),0) AS profit
     FROM sales
     WHERE business_id = ? AND status IN ('completed','credit')
       AND sale_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY){$whereBranch}
     GROUP BY DATE(sale_date)
     ORDER BY d"
);
$stmt->execute($params);
$rawTrend = $stmt->fetchAll();

$trendMap = [];
foreach ($rawTrend as $r) $trendMap[$r['d']] = $r;
$trendLabels = $trendRevenue = $trendProfit = [];
for ($i = 6; $i >= 0; $i--) {
    $day = date('Y-m-d', strtotime("-{$i} days"));
    $trendLabels[]  = date('D d', strtotime($day));
    $trendRevenue[] = isset($trendMap[$day]) ? (float)$trendMap[$day]['revenue'] : 0;
    $trendProfit[]  = isset($trendMap[$day]) ? (float)$trendMap[$day]['profit']  : 0;
}

// ---- Top selling products (last 30 days) ----
$stmt = $pdo->prepare(
    "SELECT si.product_name,
            SUM(si.quantity) AS qty,
            SUM(si.line_total) AS revenue
     FROM sale_items si
     JOIN sales s ON s.id = si.sale_id
     WHERE s.business_id = ? AND s.status IN ('completed','credit')
       AND s.sale_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY){$whereBranch}
     GROUP BY si.product_id, si.product_name
     ORDER BY revenue DESC LIMIT 5"
);
$stmt->execute($params);
$topProducts = $stmt->fetchAll();

// ---- Low stock list ----
$stmt = $pdo->prepare(
    "SELECT p.name, p.unit, inv.quantity, p.min_stock_level, b.name AS branch_name
     FROM inventory inv
     JOIN products p ON p.id = inv.product_id
     JOIN branches b ON b.id = inv.branch_id
     WHERE inv.business_id = ? AND inv.quantity <= p.min_stock_level{$whereBranch}
     ORDER BY (inv.quantity - p.min_stock_level) ASC
     LIMIT 5"
);
$stmt->execute($params);
$lowStockList = $stmt->fetchAll();

// ---- Recent sales ----
$stmt = $pdo->prepare(
    "SELECT s.sale_number, s.total_amount, s.sale_date, b.name AS branch_name,
            u.full_name AS attendant
     FROM sales s
     JOIN branches b ON b.id = s.branch_id
     JOIN users u ON u.id = s.user_id
     WHERE s.business_id = ? AND s.status IN ('completed','credit'){$whereBranch}
     ORDER BY s.sale_date DESC LIMIT 5"
);
$stmt->execute($params);
$recentSales = $stmt->fetchAll();

// ---- Branch comparison ----
$stmt = $pdo->prepare(
    "SELECT b.name,
            COALESCE(SUM(s.total_amount),0) AS revenue
     FROM branches b
     LEFT JOIN sales s
       ON s.branch_id = b.id AND s.status IN ('completed','credit')
          AND s.sale_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
     WHERE b.business_id = ? AND b.status='active'
     GROUP BY b.id, b.name
     ORDER BY revenue DESC"
);
$stmt->execute([$businessId]);
$branchPerf = $stmt->fetchAll();

// Dynamic Greeting
$hour = (int)date('H');
if ($hour < 12) $greeting = 'Good morning';
elseif ($hour < 17) $greeting = 'Good afternoon';
else $greeting = 'Good evening';

$firstName = explode(' ', current_user()['full_name'])[0];

$pageTitle = 'Dashboard';
$breadcrumbs = ['Dashboard' => null];
$pageScripts = ['assets/js/dashboard.js'];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  
  /* Canvas background */
  .dashboard-canvas {
    background-color: #f8fafc;
    padding: 2rem 2rem 3rem;
    margin: -1.5rem; /* Negate the default rp-content padding */
    min-height: calc(100vh - 72px);
    font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
  }

  /* Premium Hero Banner */
  .hero-banner {
    background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%);
    border-radius: 20px;
    padding: 2.5rem 2rem;
    position: relative;
    overflow: hidden;
    box-shadow: 0 10px 30px -10px rgba(15, 23, 42, 0.5);
    margin-bottom: 2rem;
  }
  
  /* Subtle grid pattern overlay */
  .hero-banner::before {
    content: '';
    position: absolute; inset: 0;
    background-image: linear-gradient(rgba(255, 255, 255, 0.05) 1px, transparent 1px),
                      linear-gradient(90deg, rgba(255, 255, 255, 0.05) 1px, transparent 1px);
    background-size: 20px 20px;
    mask-image: linear-gradient(to bottom, black, transparent);
    -webkit-mask-image: linear-gradient(to bottom, black, transparent);
  }
  
  /* Glowing orb effect */
  .hero-banner::after {
    content: '';
    position: absolute; top: -50%; right: -10%;
    width: 400px; height: 400px;
    background: radial-gradient(circle, rgba(59, 130, 246, 0.4) 0%, transparent 70%);
    filter: blur(40px); border-radius: 50%;
    pointer-events: none;
  }
  
  .hero-banner h2 { font-weight: 800; letter-spacing: -0.02em; color: #fff; margin-bottom: 0.5rem; }
  .hero-banner p { color: #94a3b8; font-weight: 500; margin-bottom: 0; }
  .hero-badge {
    display: inline-block; background: #2563eb; color: #fff;
    font-size: 0.75rem; font-weight: 800; letter-spacing: 0.05em;
    padding: 0.4rem 0.85rem; border-radius: 8px; margin-bottom: 1rem; text-transform: uppercase;
  }

  /* Floating Panels */
  .dash-panel {
    background: #ffffff; border-radius: 16px; border: 1px solid #e2e8f0;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.02); height: 100%; display: flex; flex-direction: column;
  }
  .dash-panel-head {
    padding: 1.25rem 1.5rem; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #f1f5f9;
  }
  .dash-panel-title { font-size: 1rem; font-weight: 700; color: #0f172a; margin: 0; }

  /* Modern KPI Cards */
  .kpi-card {
    background: #ffffff; border-radius: 16px; border: 1px solid #e2e8f0;
    padding: 1.5rem; height: 100%; position: relative; overflow: hidden;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.02); transition: transform 0.2s ease;
  }
  .kpi-card:hover { transform: translateY(-2px); }
  .kpi-label { font-size: 0.8rem; font-weight: 600; color: #64748b; margin-bottom: 0.5rem; }
  .kpi-value { font-size: 1.75rem; font-weight: 800; color: #0f172a; line-height: 1.1; letter-spacing: -0.03em; margin-bottom: 0.25rem; }
  .kpi-sub { font-size: 0.75rem; font-weight: 500; color: #94a3b8; }

  /* Decorative blob */
  .kpi-blob { position: absolute; top: -20px; right: -20px; width: 80px; height: 80px; border-radius: 50%; opacity: 0.1; }
  .kpi-blob.blue { background: #3b82f6; }
  .kpi-blob.green { background: #10b981; }
  .kpi-blob.purple { background: #8b5cf6; }
  .kpi-blob.orange { background: #f59e0b; }
  .kpi-blob.red { background: #ef4444; }

  /* Elegant Lists */
  .elegant-list { list-style: none; margin: 0; padding: 0; flex: 1; }
  .elegant-item { display: flex; align-items: center; padding: 1rem 1.5rem; border-bottom: 1px solid #f8fafc; }
  .elegant-item:last-child { border-bottom: none; }
  .elegant-icon {
    width: 40px; height: 40px; border-radius: 12px; display: flex; align-items: center; justify-content: center;
    margin-right: 1rem; flex-shrink: 0; background: #f1f5f9; color: #475569; font-size: 1rem;
  }
  .elegant-icon.success { background: #f0fdf4; color: #16a34a; }
  .elegant-icon.warning { background: #fffbeb; color: #d97706; }
  .elegant-icon.danger { background: #fef2f2; color: #dc2626; }
  .elegant-content { flex: 1; min-width: 0; }
  .elegant-title { font-size: 0.875rem; font-weight: 700; color: #0f172a; margin-bottom: 0.15rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .elegant-sub { font-size: 0.75rem; font-weight: 500; color: #64748b; }
  .elegant-value { font-weight: 800; font-size: 0.9rem; color: #0f172a; text-align: right; }
  
  .chart-wrap { position: relative; height: 320px; width: 100%; padding: 1rem; }
</style>

<div class="dashboard-canvas">
  
  <!-- PREMIUM HERO BANNER -->
  <div class="hero-banner d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-4">
    <div style="position: relative; z-index: 2;">
      <span class="hero-badge">Workspace Overview</span>
      <h2><?= $greeting ?>, <?= e($firstName) ?>.</h2>
      <p>Here is what's happening in your business today.</p>
    </div>
    
    <div style="position: relative; z-index: 2;">
      <form method="get" class="m-0">
        <select name="branch" class="form-select fw-bold border-0 shadow-sm" style="border-radius: 12px; min-width: 200px; padding: 0.75rem 1rem; color: #1e3a8a; background: #fff;" onchange="this.form.submit()">
          <option value="0">All Branches</option>
          <?php foreach ($branches as $b): ?>
            <option value="<?= (int)$b['id'] ?>" <?= $branchFilter === (int)$b['id'] ? 'selected' : '' ?>>
              <?= e($b['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </form>
    </div>
  </div>

  <!-- KPI CARDS -->
  <div class="row g-4 mb-4">
    <div class="col-md-6 col-xl-3">
      <div class="kpi-card">
        <div class="kpi-blob blue"></div>
        <div class="kpi-label">Sales Today</div>
        <div class="kpi-value"><?= money((float)$today['revenue']) ?></div>
        <div class="kpi-sub"><?= (int)$today['sales_count'] ?> successful transactions</div>
      </div>
    </div>
    
    <div class="col-md-6 col-xl-3">
      <div class="kpi-card">
        <div class="kpi-blob green"></div>
        <div class="kpi-label">Gross Profit</div>
        <div class="kpi-value text-success"><?= money((float)$today['gp']) ?></div>
        <div class="kpi-sub">Realized profit today</div>
      </div>
    </div>

    <div class="col-md-6 col-xl-3">
      <div class="kpi-card">
        <div class="kpi-blob purple"></div>
        <div class="kpi-label">Net Operating</div>
        <div class="kpi-value <?= $netOperating < 0 ? 'text-danger' : '' ?>"><?= money($netOperating) ?></div>
        <div class="kpi-sub">Month to date (after expenses)</div>
      </div>
    </div>

    <div class="col-md-6 col-xl-3">
      <div class="kpi-card">
        <div class="kpi-blob red"></div>
        <div class="kpi-label">Low Stock Alerts</div>
        <div class="kpi-value text-danger"><?= $lowStockCount ?></div>
        <div class="kpi-sub">Products below minimum level</div>
      </div>
    </div>
  </div>

  <!-- CHARTS -->
  <div class="row g-4 mb-4">
    <div class="col-lg-8">
      <div class="dash-panel">
        <div class="dash-panel-head">
          <h3 class="dash-panel-title">Revenue Trend</h3>
          <span class="badge bg-light text-secondary border">Last 7 Days</span>
        </div>
        <div class="chart-wrap">
          <canvas id="salesTrendChart"></canvas>
        </div>
      </div>
    </div>
    <div class="col-lg-4">
      <div class="dash-panel">
        <div class="dash-panel-head">
          <h3 class="dash-panel-title">Branch Revenue</h3>
          <span class="badge bg-light text-secondary border">30 Days</span>
        </div>
        <div class="chart-wrap">
          <canvas id="branchChart"></canvas>
        </div>
      </div>
    </div>
  </div>

  <!-- LISTS -->
  <div class="row g-4">
    
    <!-- Top Products -->
    <div class="col-lg-4">
      <div class="dash-panel">
        <div class="dash-panel-head">
          <h3 class="dash-panel-title">Top Products</h3>
          <a href="<?= e(APP_URL) ?>/owner/reports.php" class="text-decoration-none small fw-bold" style="color: var(--rp-blue);">View Report</a>
        </div>
        <ul class="elegant-list">
          <?php if (!$topProducts): ?>
            <li class="p-4 text-center text-muted small">No sales recorded.</li>
          <?php else: foreach ($topProducts as $tp): ?>
            <li class="elegant-item">
              <div class="elegant-icon"><i class="fa-solid fa-box-open"></i></div>
              <div class="elegant-content">
                <div class="elegant-title"><?= e($tp['product_name']) ?></div>
                <div class="elegant-sub"><?= num((float)$tp['qty']) ?> units sold</div>
              </div>
              <div class="elegant-value"><?= money((float)$tp['revenue']) ?></div>
            </li>
          <?php endforeach; endif; ?>
        </ul>
      </div>
    </div>

    <!-- Low Stock -->
    <div class="col-lg-4">
      <div class="dash-panel">
        <div class="dash-panel-head">
          <h3 class="dash-panel-title">Low Stock Alerts</h3>
          <a href="<?= e(APP_URL) ?>/owner/inventory.php" class="text-decoration-none small fw-bold" style="color: var(--rp-blue);">Manage</a>
        </div>
        <ul class="elegant-list">
          <?php if (!$lowStockList): ?>
            <li class="p-4 text-center text-muted small">All products healthy.</li>
          <?php else: foreach ($lowStockList as $ls): ?>
            <?php $isOut = (float)$ls['quantity'] <= 0; ?>
            <li class="elegant-item">
              <div class="elegant-icon <?= $isOut ? 'danger' : 'warning' ?>">
                <i class="fa-solid fa-triangle-exclamation"></i>
              </div>
              <div class="elegant-content">
                <div class="elegant-title"><?= e($ls['name']) ?></div>
                <div class="elegant-sub"><?= e($ls['branch_name']) ?></div>
              </div>
              <div class="elegant-value <?= $isOut ? 'text-danger' : 'text-warning' ?>">
                <?= num((float)$ls['quantity']) ?> <span style="font-size:0.7rem;font-weight:600;"><?= e($ls['unit']) ?></span>
              </div>
            </li>
          <?php endforeach; endif; ?>
        </ul>
      </div>
    </div>

    <!-- Recent Sales -->
    <div class="col-lg-4">
      <div class="dash-panel">
        <div class="dash-panel-head">
          <h3 class="dash-panel-title">Recent Sales</h3>
          <a href="<?= e(APP_URL) ?>/owner/sales.php" class="text-decoration-none small fw-bold" style="color: var(--rp-blue);">View All</a>
        </div>
        <ul class="elegant-list">
          <?php if (!$recentSales): ?>
            <li class="p-4 text-center text-muted small">No sales recorded.</li>
          <?php else: foreach ($recentSales as $s): ?>
            <li class="elegant-item">
              <div class="elegant-icon success"><i class="fa-solid fa-receipt"></i></div>
              <div class="elegant-content">
                <div class="elegant-title"><?= e($s['attendant']) ?></div>
                <div class="elegant-sub"><?= e($s['branch_name']) ?></div>
              </div>
              <div class="text-end">
                <div class="elegant-value text-success"><?= money((float)$s['total_amount']) ?></div>
                <div class="elegant-sub" style="font-size:0.65rem;"><?= date('H:i A', strtotime($s['sale_date'])) ?></div>
              </div>
            </li>
          <?php endforeach; endif; ?>
        </ul>
      </div>
    </div>

  </div>
</div>

<script>
  window.__RP_TREND__ = {
    labels:  <?= json_encode($trendLabels) ?>,
    revenue: <?= json_encode($trendRevenue) ?>,
    profit:  <?= json_encode($trendProfit) ?>,
  };
  window.__RP_BRANCH__ = {
    labels:  <?= json_encode(array_column($branchPerf, 'name')) ?>,
    revenue: <?= json_encode(array_map(fn($r)=>(float)$r['revenue'], $branchPerf)) ?>,
  };
</script>

<?php require __DIR__ . '/../includes/footer.php'; ?>