<?php
// owner/reports.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_role('owner');
require_permission('report.view');

$pdo        = db();
$businessId = user_business_id();
$branches   = user_branch_ids();

$tab = get('tab', 'sales');
if (!in_array($tab, ['sales','profit','inventory','low_stock','branch'], true)) $tab = 'sales';

$from = get('from', date('Y-m-01'));
$to   = get('to',   date('Y-m-d'));
$branchFilter = (int)get('branch', 0);
$validBranch = $branchFilter > 0 && in_array($branchFilter, $branches, true);

$branchWhere  = $validBranch ? " AND s.branch_id = ?" : '';
$branchParams = $validBranch ? [$branchFilter] : [];

/* ---------------- CSV export ---------------- */
if (get('export') === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="retailpro-'.$tab.'-'.$from.'-'.$to.'.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['RetailPro Report', ucfirst(str_replace('_',' ', $tab)), 'From '.$from, 'To '.$to]);

    if ($tab === 'sales') {
        fputcsv($out, ['Receipt', 'Date', 'Attendant', 'Branch', 'Total', 'Gross Profit', 'Status']);
        $stmt = $pdo->prepare(
            "SELECT s.sale_number, s.sale_date, u.full_name, b.name, s.total_amount, s.gross_profit, s.status
             FROM sales s JOIN branches b ON b.id=s.branch_id JOIN users u ON u.id=s.user_id
             WHERE s.business_id=? AND DATE(s.sale_date) BETWEEN ? AND ?{$branchWhere}
             ORDER BY s.sale_date DESC"
        );
        $stmt->execute(array_merge([$businessId, $from, $to], $branchParams));
        foreach ($stmt as $r) fputcsv($out, array_values($r));
    } elseif ($tab === 'profit') {
        fputcsv($out, ['Product', 'Qty Sold', 'Revenue', 'Cost of Goods', 'Gross Profit']);
        $stmt = $pdo->prepare(
            "SELECT si.product_name, SUM(si.quantity), SUM(si.line_total), SUM(si.line_cost),
                    SUM(si.line_total - si.line_cost)
             FROM sale_items si JOIN sales s ON s.id=si.sale_id
             WHERE s.business_id=? AND s.status IN ('completed','credit')
               AND DATE(s.sale_date) BETWEEN ? AND ?{$branchWhere}
             GROUP BY si.product_id, si.product_name ORDER BY 5 DESC"
        );
        $stmt->execute(array_merge([$businessId, $from, $to], $branchParams));
        foreach ($stmt as $r) fputcsv($out, array_values($r));
    } elseif ($tab === 'inventory') {
        fputcsv($out, ['Product', 'SKU', 'Branch', 'Qty', 'Avg Cost', 'Stock Value']);
        $stmt = $pdo->prepare(
            "SELECT p.name, p.sku, b.name, i.quantity, i.weighted_avg_cost,
                    (i.quantity * i.weighted_avg_cost)
             FROM inventory i JOIN products p ON p.id=i.product_id JOIN branches b ON b.id=i.branch_id
             WHERE i.business_id=?{$branchWhere}
             ORDER BY p.name"
        );
        $stmt->execute(array_merge([$businessId], $branchParams));
        foreach ($stmt as $r) fputcsv($out, array_values($r));
    } elseif ($tab === 'low_stock') {
        fputcsv($out, ['Product', 'Branch', 'Qty', 'Min', 'Unit']);
        $stmt = $pdo->prepare(
            "SELECT p.name, b.name, i.quantity, p.min_stock_level, p.unit
             FROM inventory i JOIN products p ON p.id=i.product_id JOIN branches b ON b.id=i.branch_id
             WHERE i.business_id=? AND i.quantity <= p.min_stock_level{$branchWhere}
             ORDER BY (i.quantity - p.min_stock_level) ASC"
        );
        $stmt->execute(array_merge([$businessId], $branchParams));
        foreach ($stmt as $r) fputcsv($out, array_values($r));
    } elseif ($tab === 'branch') {
        fputcsv($out, ['Branch', 'Revenue', 'Gross Profit', 'Sales Count']);
        $stmt = $pdo->prepare(
            "SELECT b.name, COALESCE(SUM(s.total_amount),0), COALESCE(SUM(s.gross_profit),0), COUNT(s.id)
             FROM branches b LEFT JOIN sales s ON s.branch_id = b.id
                AND s.status IN ('completed','credit') AND DATE(s.sale_date) BETWEEN ? AND ?
             WHERE b.business_id = ?
             GROUP BY b.id, b.name ORDER BY 2 DESC"
        );
        $stmt->execute([$from, $to, $businessId]);
        foreach ($stmt as $r) fputcsv($out, array_values($r));
    }
    fclose($out);
    exit;
}

/* ---------------- Data ---------------- */
$sales = [];
$profitByProduct = [];
$inventory = [];
$lowStock = [];
$branchPerf = [];
$summary = ['revenue' => 0.0, 'gross_profit' => 0.0, 'count' => 0, 'aov' => 0.0];

if ($tab === 'sales') {
    $stmt = $pdo->prepare(
        "SELECT s.*, b.name AS branch_name, u.full_name AS attendant
         FROM sales s JOIN branches b ON b.id=s.branch_id JOIN users u ON u.id=s.user_id
         WHERE s.business_id=? AND DATE(s.sale_date) BETWEEN ? AND ?{$branchWhere}
         ORDER BY s.sale_date DESC LIMIT 500"
    );
    $stmt->execute(array_merge([$businessId, $from, $to], $branchParams));
    $sales = $stmt->fetchAll();

    $sums = $pdo->prepare(
        "SELECT COALESCE(SUM(total_amount),0), COALESCE(SUM(gross_profit),0), COUNT(*)
         FROM sales s WHERE s.business_id=? AND s.status IN ('completed','credit')
           AND DATE(s.sale_date) BETWEEN ? AND ?{$branchWhere}"
    );
    $sums->execute(array_merge([$businessId, $from, $to], $branchParams));
    [$rev, $gp, $n] = $sums->fetch(PDO::FETCH_NUM);
    $summary = ['revenue' => (float)$rev, 'gross_profit' => (float)$gp, 'count' => (int)$n,
                'aov' => $n > 0 ? (float)$rev / (int)$n : 0.0];
} elseif ($tab === 'profit') {
    $stmt = $pdo->prepare(
        "SELECT si.product_name, SUM(si.quantity) AS qty, SUM(si.line_total) AS revenue,
                SUM(si.line_cost) AS cost, SUM(si.line_total - si.line_cost) AS gp
         FROM sale_items si JOIN sales s ON s.id=si.sale_id
         WHERE s.business_id=? AND s.status IN ('completed','credit')
           AND DATE(s.sale_date) BETWEEN ? AND ?{$branchWhere}
         GROUP BY si.product_id, si.product_name ORDER BY gp DESC LIMIT 300"
    );
    $stmt->execute(array_merge([$businessId, $from, $to], $branchParams));
    $profitByProduct = $stmt->fetchAll();
} elseif ($tab === 'inventory') {
    $stmt = $pdo->prepare(
        "SELECT p.name, p.sku, p.unit, b.name AS branch_name, i.quantity, i.weighted_avg_cost,
                (i.quantity * i.weighted_avg_cost) AS stock_value
         FROM inventory i JOIN products p ON p.id=i.product_id JOIN branches b ON b.id=i.branch_id
         WHERE i.business_id=?{$branchWhere} ORDER BY stock_value DESC LIMIT 500"
    );
    $stmt->execute(array_merge([$businessId], $branchParams));
    $inventory = $stmt->fetchAll();
} elseif ($tab === 'low_stock') {
    $stmt = $pdo->prepare(
        "SELECT p.name, p.sku, p.unit, b.name AS branch_name, i.quantity, p.min_stock_level
         FROM inventory i JOIN products p ON p.id=i.product_id JOIN branches b ON b.id=i.branch_id
         WHERE i.business_id=? AND i.quantity <= p.min_stock_level{$branchWhere}
         ORDER BY (i.quantity - p.min_stock_level) ASC LIMIT 500"
    );
    $stmt->execute(array_merge([$businessId], $branchParams));
    $lowStock = $stmt->fetchAll();
} elseif ($tab === 'branch') {
    $stmt = $pdo->prepare(
        "SELECT b.name, COALESCE(SUM(s.total_amount),0) AS revenue, COALESCE(SUM(s.gross_profit),0) AS gp, COUNT(s.id) AS n
         FROM branches b LEFT JOIN sales s ON s.branch_id = b.id AND s.status IN ('completed','credit') AND DATE(s.sale_date) BETWEEN ? AND ?
         WHERE b.business_id = ? GROUP BY b.id, b.name ORDER BY revenue DESC"
    );
    $stmt->execute([$from, $to, $businessId]);
    $branchPerf = $stmt->fetchAll();
}

$allBranches = $pdo->prepare("SELECT id, name FROM branches WHERE business_id = ? AND status='active' ORDER BY is_main DESC, name");
$allBranches->execute([$businessId]);
$allBranches = $allBranches->fetchAll();

$pageTitle = 'Reports';
$breadcrumbs = ['Dashboard' => APP_URL . '/owner/dashboard.php', 'Reports' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; max-width: 1100px; }
  
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }

  /* Modern Pill Tabs */
  .report-tabs { display: inline-flex; background: #f1f5f9; padding: 0.35rem; border-radius: 12px; margin-bottom: 1.5rem; gap: 0.25rem; flex-wrap: wrap; }
  .report-tab { padding: 0.5rem 1rem; font-size: 0.85rem; font-weight: 600; color: #64748b; text-decoration: none; border-radius: 8px; transition: all 0.15s; }
  .report-tab:hover { color: #0f172a; }
  .report-tab.active { background: #fff; color: #2563eb; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }

  /* Filter Bar */
  .filter-bar { display: flex; gap: 0.5rem; background: #fff; padding: 0.35rem; border-radius: 10px; border: 1px solid #cbd5e1; margin-bottom: 1.5rem; flex-wrap: wrap; align-items: center; }
  .filter-bar input, .filter-bar select { border: none; border-radius: 6px; padding: 0.35rem 0.5rem; font-size: 0.8rem; font-weight: 500; color: #0f172a; background: transparent; }
  .filter-bar input:focus, .filter-bar select:focus { outline: none; background: #f8fafc; }

  /* KPI Cards */
  .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
  .kpi-card { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; padding: 1.25rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
  .kpi-label { font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b; margin-bottom: 0.25rem; }
  .kpi-value { font-size: 1.4rem; font-weight: 800; color: #0f172a; line-height: 1.2; }

  /* List View */
  .list-panel { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
  .list-item { display: flex; align-items: center; padding: 1rem 1.5rem; border-bottom: 1px solid #f1f5f9; transition: background 0.15s; flex-wrap: wrap; gap: 1rem; }
  .list-item:last-child { border-bottom: none; }
  .list-item:hover { background: #f8fafc; }
  .list-title { font-weight: 700; font-size: 0.9rem; color: #0f172a; margin-bottom: 0.15rem; }
  .list-sub { font-size: 0.75rem; color: #64748b; font-weight: 500; }
  .list-val { font-weight: 700; font-size: 0.9rem; color: #0f172a; text-align: right; min-width: 100px; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>Reports & Analytics</h1>
      <p>Analyze your business performance and export data.</p>
    </div>
  </div>

  <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">
    <div class="report-tabs">
      <?php $tabs = ['sales'=>'Sales','profit'=>'Profit','inventory'=>'Inventory','low_stock'=>'Low Stock','branch'=>'Branches']; foreach ($tabs as $k => $lbl): ?>
        <a class="report-tab <?= $tab === $k ? 'active' : '' ?>" href="?<?= e(http_build_query(array_merge($_GET, ['tab'=>$k]))) ?>"><?= e($lbl) ?></a>
      <?php endforeach; ?>
    </div>
    
    <a class="btn btn-sm btn-success fw-bold px-3" href="?<?= e(http_build_query(array_merge($_GET, ['export'=>'csv']))) ?>" style="border-radius: 8px;">
      <i class="fa-solid fa-file-csv me-1"></i>Export CSV
    </a>
  </div>

  <form class="filter-bar" method="get">
    <input type="hidden" name="tab" value="<?= e($tab) ?>">
    <input type="date" name="from" value="<?= e($from) ?>">
    <input type="date" name="to" value="<?= e($to) ?>">
    <select name="branch">
      <option value="0">All branches</option>
      <?php foreach ($allBranches as $b): ?>
        <option value="<?= (int)$b['id'] ?>" <?= $validBranch && $branchFilter === (int)$b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-sm btn-dark">Apply Filters</button>
  </form>

  <?php if ($tab === 'sales'): ?>
    <div class="kpi-grid">
      <div class="kpi-card"><div class="kpi-label">Revenue</div><div class="kpi-value"><?= money($summary['revenue']) ?></div></div>
      <div class="kpi-card"><div class="kpi-label">Gross Profit</div><div class="kpi-value text-success"><?= money($summary['gross_profit']) ?></div></div>
      <div class="kpi-card"><div class="kpi-label">Transactions</div><div class="kpi-value"><?= $summary['count'] ?></div></div>
      <div class="kpi-card"><div class="kpi-label">Avg Sale</div><div class="kpi-value"><?= money($summary['aov']) ?></div></div>
    </div>
    
    <div class="list-panel">
      <?php foreach ($sales as $s): ?>
        <div class="list-item">
          <div class="list-content flex-grow-1">
            <a href="<?= e(APP_URL) ?>/receipt.php?id=<?= (int)$s['id'] ?>" target="_blank" class="list-title"><?= e($s['sale_number']) ?></a>
            <div class="list-sub"><?= human_datetime($s['sale_date']) ?> • <?= e($s['attendant']) ?> • <?= e($s['branch_name']) ?></div>
          </div>
          <div class="list-val text-success"><?= money((float)$s['total_amount']) ?></div>
        </div>
      <?php endforeach; ?>
      <?php if (!$sales): ?><div class="text-center py-5 text-muted">No sales in this range.</div><?php endif; ?>
    </div>

  <?php elseif ($tab === 'profit'): ?>
    <div class="list-panel">
      <?php foreach ($profitByProduct as $p): ?>
        <div class="list-item">
          <div class="list-content flex-grow-1"><div class="list-title"><?= e($p['product_name']) ?></div><div class="list-sub"><?= num((float)$p['qty'], 2) ?> units sold</div></div>
          <div class="list-val text-success"><?= money((float)$p['gp']) ?> <span class="text-muted fw-normal small ms-2">(Rev: <?= money((float)$p['revenue']) ?>)</span></div>
        </div>
      <?php endforeach; ?>
      <?php if (!$profitByProduct): ?><div class="text-center py-5 text-muted">No products sold in this range.</div><?php endif; ?>
    </div>

  <?php elseif ($tab === 'inventory'): ?>
    <div class="list-panel">
      <?php foreach ($inventory as $i): ?>
        <div class="list-item">
          <div class="list-content flex-grow-1"><div class="list-title"><?= e($i['name']) ?></div><div class="list-sub">SKU: <?= e($i['sku']) ?> • <?= e($i['branch_name']) ?></div></div>
          <div class="list-val"><?= money((float)$i['stock_value']) ?> <div class="list-sub mt-1"><?= num((float)$i['quantity'], 2) ?> <?= e($i['unit']) ?></div></div>
        </div>
      <?php endforeach; ?>
      <?php if (!$inventory): ?><div class="text-center py-5 text-muted">No inventory found.</div><?php endif; ?>
    </div>

  <?php elseif ($tab === 'low_stock'): ?>
    <div class="list-panel">
      <?php foreach ($lowStock as $l): ?>
        <div class="list-item">
          <div class="list-content flex-grow-1"><div class="list-title"><?= e($l['name']) ?></div><div class="list-sub"><?= e($l['branch_name']) ?></div></div>
          <div class="list-val text-danger"><?= num((float)$l['quantity'], 2) ?> <?= e($l['unit']) ?> <div class="list-sub mt-1">Min: <?= num((float)$l['min_stock_level'], 2) ?></div></div>
        </div>
      <?php endforeach; ?>
      <?php if (!$lowStock): ?><div class="text-center py-5 text-muted">All products are above minimum levels.</div><?php endif; ?>
    </div>

  <?php elseif ($tab === 'branch'): ?>
    <div class="list-panel">
      <?php foreach ($branchPerf as $b): ?>
        <div class="list-item">
          <div class="list-content flex-grow-1"><div class="list-title"><?= e($b['name']) ?></div><div class="list-sub"><?= (int)$b['n'] ?> sales</div></div>
          <div class="list-val text-success"><?= money((float)$b['revenue']) ?> <div class="list-sub mt-1">GP: <?= money((float)$b['gp']) ?></div></div>
        </div>
      <?php endforeach; ?>
      <?php if (!$branchPerf): ?><div class="text-center py-5 text-muted">No branches found.</div><?php endif; ?>
    </div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>