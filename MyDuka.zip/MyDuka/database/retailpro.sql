-- ============================================================
-- RetailPro - Retail Inventory & Business Management System
-- Complete Database Schema  (MySQL 8.0 / InnoDB / utf8mb4)
-- ============================================================
-- Account creation rules enforced by this schema + app:
--   * ADMIN     -> inserted directly into DB (this file seeds one).
--                  No public signup path exists.
--   * OWNER     -> self-registers via register.php (creates business +
--                  main branch + owner user inside one transaction).
--   * EMPLOYEE  -> created ONLY by their owner via owner/employees.php.
--                  users.created_by records who created them.
-- ============================================================
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS retailpro
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE retailpro;

-- ------------------------------------------------------------
-- 1. ROLES & PERMISSIONS
-- ------------------------------------------------------------
CREATE TABLE roles (
  id            TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(50)  NOT NULL UNIQUE,   -- admin, owner, employee
  description   VARCHAR(255) NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO roles (id, name, description) VALUES
  (1,'admin','System administrator'),
  (2,'owner','Shop owner / employer'),
  (3,'employee','Shop attendant');

CREATE TABLE permissions (
  id          SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code        VARCHAR(100) NOT NULL UNIQUE,
  description VARCHAR(255) NULL
) ENGINE=InnoDB;

CREATE TABLE role_permissions (
  role_id       TINYINT  UNSIGNED NOT NULL,
  permission_id SMALLINT UNSIGNED NOT NULL,
  PRIMARY KEY (role_id, permission_id),
  CONSTRAINT fk_rp_role FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
  CONSTRAINT fk_rp_perm FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 2. BUSINESSES & BRANCHES
-- ------------------------------------------------------------
CREATE TABLE businesses (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name             VARCHAR(150) NOT NULL,
  owner_id         INT UNSIGNED NULL,          -- FK added after users
  phone            VARCHAR(30)  NULL,
  email            VARCHAR(150) NULL,
  address          VARCHAR(255) NULL,
  logo_path        VARCHAR(255) NULL,
  currency         CHAR(3) NOT NULL DEFAULT 'UGX',
  status           ENUM('active','suspended','pending') NOT NULL DEFAULT 'active',
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_business_status (status)
) ENGINE=InnoDB;

CREATE TABLE branches (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id   INT UNSIGNED NOT NULL,
  name          VARCHAR(120) NOT NULL,
  code          VARCHAR(30)  NULL,
  address       VARCHAR(255) NULL,
  phone         VARCHAR(30)  NULL,
  is_main       TINYINT(1)   NOT NULL DEFAULT 0,
  status        ENUM('active','inactive') NOT NULL DEFAULT 'active',
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_branch_name_per_business (business_id, name),
  KEY idx_branch_business (business_id),
  CONSTRAINT fk_branch_business FOREIGN KEY (business_id)
    REFERENCES businesses(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 3. USERS
-- ------------------------------------------------------------
CREATE TABLE users (
  id                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  role_id              TINYINT UNSIGNED NOT NULL,
  business_id          INT UNSIGNED NULL,            -- NULL for system admins
  created_by           INT UNSIGNED NULL,            -- NULL for admin & self-registered owners
  full_name            VARCHAR(150) NOT NULL,
  email                VARCHAR(150) NOT NULL,
  phone                VARCHAR(30)  NULL,
  password_hash        VARCHAR(255) NOT NULL,
  must_change_password TINYINT(1) NOT NULL DEFAULT 0,-- 1 for owner-created employees
  status               ENUM('active','inactive','suspended') NOT NULL DEFAULT 'active',
  last_login_at        DATETIME NULL,
  reset_token          VARCHAR(100) NULL,
  reset_expires_at     DATETIME NULL,
  created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_user_email (email),
  KEY idx_user_business (business_id),
  KEY idx_user_role_business (role_id, business_id),
  KEY idx_user_created_by (created_by),
  CONSTRAINT fk_user_role       FOREIGN KEY (role_id)       REFERENCES roles(id),
  CONSTRAINT fk_user_business   FOREIGN KEY (business_id)   REFERENCES businesses(id) ON DELETE CASCADE,
  CONSTRAINT fk_user_created_by FOREIGN KEY (created_by)    REFERENCES users(id)      ON DELETE SET NULL
) ENGINE=InnoDB;

-- Wire the owner FK on businesses
ALTER TABLE businesses
  ADD CONSTRAINT fk_business_owner
  FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE SET NULL;

-- Employee <-> Branch assignment (many-to-many)
CREATE TABLE user_branch_assignments (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  branch_id   INT UNSIGNED NOT NULL,
  assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_user_branch (user_id, branch_id),
  CONSTRAINT fk_uba_user   FOREIGN KEY (user_id)   REFERENCES users(id)    ON DELETE CASCADE,
  CONSTRAINT fk_uba_branch FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Per-user permission override (spec 2.3)
CREATE TABLE user_permissions (
  user_id        INT UNSIGNED NOT NULL,
  permission_id  SMALLINT UNSIGNED NOT NULL,
  granted        TINYINT(1) NOT NULL DEFAULT 1,   -- 1 grant, 0 revoke (override)
  PRIMARY KEY (user_id, permission_id),
  CONSTRAINT fk_up_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_up_perm FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 4. CATEGORIES & PRODUCTS
-- ------------------------------------------------------------
CREATE TABLE categories (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id INT UNSIGNED NOT NULL,
  name        VARCHAR(120) NOT NULL,
  description VARCHAR(255) NULL,
  status      ENUM('active','archived') NOT NULL DEFAULT 'active',
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_category_per_business (business_id, name),
  CONSTRAINT fk_cat_business FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE suppliers (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id    INT UNSIGNED NOT NULL,
  name           VARCHAR(150) NOT NULL,
  contact_person VARCHAR(120) NULL,
  phone          VARCHAR(30)  NULL,
  email          VARCHAR(150) NULL,
  address        VARCHAR(255) NULL,
  notes          TEXT NULL,
  status         ENUM('active','archived') NOT NULL DEFAULT 'active',
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_supplier_business (business_id),
  CONSTRAINT fk_supplier_business FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE products (
  id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id       INT UNSIGNED NOT NULL,
  category_id       INT UNSIGNED NULL,
  supplier_id       INT UNSIGNED NULL,
  name              VARCHAR(180) NOT NULL,
  sku               VARCHAR(60)  NOT NULL,
  barcode           VARCHAR(80)  NULL,
  description       TEXT NULL,
  image_path        VARCHAR(255) NULL,
  unit              VARCHAR(30)  NOT NULL DEFAULT 'pcs',
  buying_price      DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  selling_price     DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  min_stock_level   DECIMAL(15,3) NOT NULL DEFAULT 0.000,
  status            ENUM('active','archived') NOT NULL DEFAULT 'active',
  created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_product_sku_per_business (business_id, sku),
  KEY idx_product_category (category_id),
  KEY idx_product_barcode  (barcode),
  CONSTRAINT fk_product_business FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
  CONSTRAINT fk_product_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
  CONSTRAINT fk_product_supplier FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 5. INVENTORY (per product per branch)
-- ------------------------------------------------------------
CREATE TABLE inventory (
  id                 BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id        INT UNSIGNED NOT NULL,
  branch_id          INT UNSIGNED NOT NULL,
  product_id         INT UNSIGNED NOT NULL,
  quantity           DECIMAL(15,3) NOT NULL DEFAULT 0.000,
  weighted_avg_cost  DECIMAL(15,4) NOT NULL DEFAULT 0.0000,
  updated_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_inv_product_branch (product_id, branch_id),
  KEY idx_inv_branch (branch_id),
  CONSTRAINT fk_inv_business FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
  CONSTRAINT fk_inv_branch   FOREIGN KEY (branch_id)   REFERENCES branches(id) ON DELETE CASCADE,
  CONSTRAINT fk_inv_product  FOREIGN KEY (product_id)  REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE stock_movements (
  id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id     INT UNSIGNED NOT NULL,
  branch_id       INT UNSIGNED NOT NULL,
  product_id      INT UNSIGNED NOT NULL,
  movement_type   ENUM(
    'opening','purchase','sale','sale_return','adjustment',
    'transfer_out','transfer_in','damage','expiry','loss'
  ) NOT NULL,
  quantity        DECIMAL(15,3) NOT NULL,
  prev_balance    DECIMAL(15,3) NOT NULL,
  new_balance     DECIMAL(15,3) NOT NULL,
  unit_cost       DECIMAL(15,4) NULL,
  reference_table VARCHAR(60)  NULL,
  reference_id    BIGINT UNSIGNED NULL,
  reason          VARCHAR(255) NULL,
  user_id         INT UNSIGNED NOT NULL,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_sm_branch_product (branch_id, product_id),
  KEY idx_sm_ref (reference_table, reference_id),
  KEY idx_sm_created (created_at),
  CONSTRAINT fk_sm_business FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
  CONSTRAINT fk_sm_branch   FOREIGN KEY (branch_id)   REFERENCES branches(id) ON DELETE CASCADE,
  CONSTRAINT fk_sm_product  FOREIGN KEY (product_id)  REFERENCES products(id) ON DELETE CASCADE,
  CONSTRAINT fk_sm_user     FOREIGN KEY (user_id)     REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE stock_adjustments (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id  INT UNSIGNED NOT NULL,
  branch_id    INT UNSIGNED NOT NULL,
  product_id   INT UNSIGNED NOT NULL,
  qty_change   DECIMAL(15,3) NOT NULL,
  reason       VARCHAR(255) NOT NULL,
  movement_id  BIGINT UNSIGNED NULL,
  user_id      INT UNSIGNED NOT NULL,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_sa_business FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
  CONSTRAINT fk_sa_branch   FOREIGN KEY (branch_id)   REFERENCES branches(id) ON DELETE CASCADE,
  CONSTRAINT fk_sa_product  FOREIGN KEY (product_id)  REFERENCES products(id) ON DELETE CASCADE,
  CONSTRAINT fk_sa_movement FOREIGN KEY (movement_id) REFERENCES stock_movements(id) ON DELETE SET NULL,
  CONSTRAINT fk_sa_user     FOREIGN KEY (user_id)     REFERENCES users(id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 6. PURCHASES
-- ------------------------------------------------------------
CREATE TABLE purchases (
  id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id     INT UNSIGNED NOT NULL,
  branch_id       INT UNSIGNED NOT NULL,
  supplier_id     INT UNSIGNED NULL,
  purchase_number VARCHAR(40) NOT NULL,
  purchase_date   DATE NOT NULL,
  reference_no    VARCHAR(80) NULL,
  total_amount    DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  paid_amount     DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  balance_due     DECIMAL(15,2) GENERATED ALWAYS AS (total_amount - paid_amount) STORED,
  payment_status  ENUM('unpaid','partial','paid') NOT NULL DEFAULT 'unpaid',
  status          ENUM('draft','received','cancelled') NOT NULL DEFAULT 'draft',
  notes           TEXT NULL,
  created_by      INT UNSIGNED NOT NULL,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_purchase_number (business_id, purchase_number),
  KEY idx_purchase_branch (branch_id),
  KEY idx_purchase_supplier (supplier_id),
  CONSTRAINT fk_pur_business FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
  CONSTRAINT fk_pur_branch   FOREIGN KEY (branch_id)   REFERENCES branches(id),
  CONSTRAINT fk_pur_supplier FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL,
  CONSTRAINT fk_pur_user     FOREIGN KEY (created_by)  REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE purchase_items (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  purchase_id  BIGINT UNSIGNED NOT NULL,
  product_id   INT UNSIGNED NOT NULL,
  quantity     DECIMAL(15,3) NOT NULL,
  unit_cost    DECIMAL(15,4) NOT NULL,
  line_total   DECIMAL(15,2) NOT NULL,
  CONSTRAINT fk_pi_purchase FOREIGN KEY (purchase_id) REFERENCES purchases(id) ON DELETE CASCADE,
  CONSTRAINT fk_pi_product  FOREIGN KEY (product_id)  REFERENCES products(id)
) ENGINE=InnoDB;

CREATE TABLE supplier_payments (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id  INT UNSIGNED NOT NULL,
  purchase_id  BIGINT UNSIGNED NULL,
  supplier_id  INT UNSIGNED NOT NULL,
  amount       DECIMAL(15,2) NOT NULL,
  payment_date DATE NOT NULL,
  method       ENUM('cash','mobile_money','bank','credit','other') NOT NULL DEFAULT 'cash',
  reference    VARCHAR(100) NULL,
  notes        VARCHAR(255) NULL,
  user_id      INT UNSIGNED NOT NULL,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_sp_business FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
  CONSTRAINT fk_sp_purchase FOREIGN KEY (purchase_id) REFERENCES purchases(id) ON DELETE SET NULL,
  CONSTRAINT fk_sp_supplier FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE CASCADE,
  CONSTRAINT fk_sp_user     FOREIGN KEY (user_id)     REFERENCES users(id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 7. CUSTOMERS, SALES, RETURNS
-- ------------------------------------------------------------
CREATE TABLE customers (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id  INT UNSIGNED NOT NULL,
  name         VARCHAR(150) NOT NULL,
  phone        VARCHAR(30)  NULL,
  email        VARCHAR(150) NULL,
  address      VARCHAR(255) NULL,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_customer_business (business_id),
  CONSTRAINT fk_customer_business FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE sales (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id   INT UNSIGNED NOT NULL,
  branch_id     INT UNSIGNED NOT NULL,
  customer_id   INT UNSIGNED NULL,
  sale_number   VARCHAR(40) NOT NULL,
  sale_date     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  subtotal      DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  discount      DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  tax           DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  total_amount  DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  paid_amount   DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  cost_of_goods DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  gross_profit  DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  status        ENUM('completed','credit','cancelled','returned') NOT NULL DEFAULT 'completed',
  notes         VARCHAR(255) NULL,
  user_id       INT UNSIGNED NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_sale_number (business_id, sale_number),
  KEY idx_sale_branch_date (branch_id, sale_date),
  KEY idx_sale_user (user_id),
  CONSTRAINT fk_sale_business FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
  CONSTRAINT fk_sale_branch   FOREIGN KEY (branch_id)   REFERENCES branches(id),
  CONSTRAINT fk_sale_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
  CONSTRAINT fk_sale_user     FOREIGN KEY (user_id)     REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE sale_items (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  sale_id       BIGINT UNSIGNED NOT NULL,
  product_id    INT UNSIGNED NOT NULL,
  product_name  VARCHAR(180) NOT NULL,
  quantity      DECIMAL(15,3) NOT NULL,
  unit_price    DECIMAL(15,4) NOT NULL,
  unit_cost     DECIMAL(15,4) NOT NULL,
  line_total    DECIMAL(15,2) NOT NULL,
  line_cost     DECIMAL(15,2) NOT NULL,
  CONSTRAINT fk_si_sale    FOREIGN KEY (sale_id)    REFERENCES sales(id) ON DELETE CASCADE,
  CONSTRAINT fk_si_product FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB;

CREATE TABLE sale_payments (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  sale_id      BIGINT UNSIGNED NOT NULL,
  amount       DECIMAL(15,2) NOT NULL,
  method       ENUM('cash','mobile_money','bank','credit','other') NOT NULL DEFAULT 'cash',
  reference    VARCHAR(100) NULL,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_spay_sale FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE sales_returns (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id   INT UNSIGNED NOT NULL,
  branch_id     INT UNSIGNED NOT NULL,
  sale_id       BIGINT UNSIGNED NOT NULL,
  return_number VARCHAR(40) NOT NULL,
  reason        VARCHAR(255) NOT NULL,
  total_amount  DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  status        ENUM('pending','inspected','accepted','rejected') NOT NULL DEFAULT 'pending',
  user_id       INT UNSIGNED NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_return_number (business_id, return_number),
  CONSTRAINT fk_ret_business FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
  CONSTRAINT fk_ret_branch   FOREIGN KEY (branch_id)   REFERENCES branches(id),
  CONSTRAINT fk_ret_sale     FOREIGN KEY (sale_id)     REFERENCES sales(id),
  CONSTRAINT fk_ret_user     FOREIGN KEY (user_id)     REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE sales_return_items (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  return_id    BIGINT UNSIGNED NOT NULL,
  product_id   INT UNSIGNED NOT NULL,
  quantity     DECIMAL(15,3) NOT NULL,
  unit_price   DECIMAL(15,4) NOT NULL,
  line_total   DECIMAL(15,2) NOT NULL,
  CONSTRAINT fk_sri_return  FOREIGN KEY (return_id)  REFERENCES sales_returns(id) ON DELETE CASCADE,
  CONSTRAINT fk_sri_product FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 8. STOCK TRANSFERS
-- ------------------------------------------------------------
CREATE TABLE stock_transfers (
  id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id      INT UNSIGNED NOT NULL,
  transfer_number  VARCHAR(40) NOT NULL,
  from_branch_id   INT UNSIGNED NOT NULL,
  to_branch_id     INT UNSIGNED NOT NULL,
  status           ENUM('pending','dispatched','received','cancelled') NOT NULL DEFAULT 'pending',
  notes            VARCHAR(255) NULL,
  initiated_by     INT UNSIGNED NOT NULL,
  received_by      INT UNSIGNED NULL,
  dispatched_at    DATETIME NULL,
  received_at      DATETIME NULL,
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_transfer_number (business_id, transfer_number),
  CONSTRAINT fk_tr_business  FOREIGN KEY (business_id)    REFERENCES businesses(id) ON DELETE CASCADE,
  CONSTRAINT fk_tr_from      FOREIGN KEY (from_branch_id) REFERENCES branches(id),
  CONSTRAINT fk_tr_to        FOREIGN KEY (to_branch_id)   REFERENCES branches(id),
  CONSTRAINT fk_tr_initiator FOREIGN KEY (initiated_by)   REFERENCES users(id),
  CONSTRAINT fk_tr_receiver  FOREIGN KEY (received_by)    REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT chk_tr_diff     CHECK (from_branch_id <> to_branch_id)
) ENGINE=InnoDB;

CREATE TABLE stock_transfer_items (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  transfer_id  BIGINT UNSIGNED NOT NULL,
  product_id   INT UNSIGNED NOT NULL,
  quantity     DECIMAL(15,3) NOT NULL,
  CONSTRAINT fk_tri_transfer FOREIGN KEY (transfer_id) REFERENCES stock_transfers(id) ON DELETE CASCADE,
  CONSTRAINT fk_tri_product  FOREIGN KEY (product_id)  REFERENCES products(id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 9. EXPENSES
-- ------------------------------------------------------------
CREATE TABLE expense_categories (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id  INT UNSIGNED NOT NULL,
  name         VARCHAR(120) NOT NULL,
  CONSTRAINT fk_ec_business FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
  UNIQUE KEY uq_ec_name (business_id, name)
) ENGINE=InnoDB;

CREATE TABLE expenses (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id   INT UNSIGNED NOT NULL,
  branch_id     INT UNSIGNED NOT NULL,
  category_id   INT UNSIGNED NULL,
  description   VARCHAR(255) NOT NULL,
  amount        DECIMAL(15,2) NOT NULL,
  expense_date  DATE NOT NULL,
  method        ENUM('cash','mobile_money','bank','other') NOT NULL DEFAULT 'cash',
  attachment    VARCHAR(255) NULL,
  user_id       INT UNSIGNED NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_expense_branch_date (branch_id, expense_date),
  CONSTRAINT fk_exp_business FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
  CONSTRAINT fk_exp_branch   FOREIGN KEY (branch_id)   REFERENCES branches(id),
  CONSTRAINT fk_exp_category FOREIGN KEY (category_id) REFERENCES expense_categories(id) ON DELETE SET NULL,
  CONSTRAINT fk_exp_user     FOREIGN KEY (user_id)     REFERENCES users(id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 10. SYSTEM: AUDIT LOGS, NOTIFICATIONS, SETTINGS
-- ------------------------------------------------------------
CREATE TABLE audit_logs (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id   INT UNSIGNED NULL,
  branch_id     INT UNSIGNED NULL,
  user_id       INT UNSIGNED NULL,
  action        VARCHAR(120) NOT NULL,
  entity        VARCHAR(60)  NULL,
  entity_id     BIGINT UNSIGNED NULL,
  details       JSON NULL,
  ip_address    VARCHAR(45)  NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_al_business (business_id),
  KEY idx_al_user (user_id),
  KEY idx_al_created (created_at),
  CONSTRAINT fk_al_business FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE SET NULL,
  CONSTRAINT fk_al_branch   FOREIGN KEY (branch_id)   REFERENCES branches(id)   ON DELETE SET NULL,
  CONSTRAINT fk_al_user     FOREIGN KEY (user_id)     REFERENCES users(id)      ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE notifications (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id  INT UNSIGNED NOT NULL,
  branch_id    INT UNSIGNED NULL,
  user_id      INT UNSIGNED NULL,
  type         ENUM('low_stock','out_of_stock','transfer','system','other') NOT NULL,
  title        VARCHAR(150) NOT NULL,
  message      TEXT NOT NULL,
  is_read      TINYINT(1) NOT NULL DEFAULT 0,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_notif_user (user_id, is_read),
  CONSTRAINT fk_notif_business FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
  CONSTRAINT fk_notif_branch   FOREIGN KEY (branch_id)   REFERENCES branches(id)   ON DELETE SET NULL,
  CONSTRAINT fk_notif_user     FOREIGN KEY (user_id)     REFERENCES users(id)      ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE business_settings (
  id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  business_id           INT UNSIGNED NOT NULL UNIQUE,
  default_tax_rate      DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  allow_negative_stock  TINYINT(1) NOT NULL DEFAULT 0,
  receipt_footer        VARCHAR(255) NULL,
  updated_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_bs_business FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- SEED: SYSTEM ADMINISTRATOR (DB-INSERTED ONLY - NO SIGNUP PATH)
-- ============================================================
-- Email    : admin@retailpro.local
-- Password : Password123!
-- IMPORTANT: change this password immediately after first login.
-- ------------------------------------------------------------
INSERT INTO users (
  id, role_id, business_id, created_by,
  full_name, email, phone,
  password_hash, must_change_password, status
) VALUES (
  1, 1, NULL, NULL,
  'System Administrator',
  'admin@retailpro.local',
  '+256700000001',
  '$2y$10$NgHDlZGSPOILEoNsg9eamOux765TBDPKyHX5Fsv49jJWCqRPh/tDG',
  0, 'active'
);

-- ============================================================
-- SEED: PERMISSION CATALOGUE
-- ============================================================
INSERT INTO permissions (code, description) VALUES
  ('product.view',        'View products'),
  ('product.create',      'Create products'),
  ('product.update',      'Edit products'),
  ('product.delete',      'Archive products'),
  ('category.view',       'View categories'),
  ('category.manage',     'Create / edit categories'),
  ('inventory.view',      'View inventory & stock levels'),
  ('inventory.adjust',    'Perform stock adjustments'),
  ('purchase.view',       'View purchases'),
  ('purchase.create',     'Record new purchases'),
  ('purchase.cancel',     'Cancel purchases'),
  ('sale.create',         'Record sales (POS)'),
  ('sale.view',           'View all sales'),
  ('sale.view_own',       'View own sales only'),
  ('sale.cancel',         'Cancel / reverse sales'),
  ('sale.return',         'Process sales returns'),
  ('supplier.view',       'View suppliers'),
  ('supplier.manage',     'Create / edit suppliers'),
  ('customer.view',       'View customers'),
  ('customer.manage',     'Create / edit customers'),
  ('expense.view',        'View expenses'),
  ('expense.create',      'Record expenses'),
  ('employee.view',       'View employees'),
  ('employee.manage',     'Create / edit employees'),
  ('branch.view',         'View branches'),
  ('branch.manage',       'Create / edit branches'),
  ('transfer.view',       'View stock transfers'),
  ('transfer.create',     'Initiate stock transfers'),
  ('transfer.receive',    'Receive stock transfers'),
  ('report.view',         'View business reports'),
  ('audit.view',          'View activity logs');

-- ============================================================
-- SEED: ROLE -> PERMISSION DEFAULTS
-- ============================================================
-- OWNER: full business management (admin bypasses checks in code)
INSERT INTO role_permissions (role_id, permission_id)
SELECT 2, id FROM permissions;

-- EMPLOYEE: NO defaults on purpose.
-- The owner grants permissions explicitly when creating each employee,
-- storing overrides in user_permissions. This enforces least-privilege.

SET FOREIGN_KEY_CHECKS = 1;

ALTER TABLE users 
ADD COLUMN email_verified_at DATETIME NULL AFTER must_change_password,
ADD COLUMN verification_token VARCHAR(100) NULL AFTER email_verified_at;

UPDATE users SET email_verified_at = NOW() WHERE email = 'admin@retailpro.local';