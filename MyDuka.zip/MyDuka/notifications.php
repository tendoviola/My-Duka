<?php
// notifications.php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post('action');
    $businessId = user_business_id();
    if ($businessId && $action === 'mark_all_read') {
        db()->prepare("UPDATE notifications SET is_read = 1 WHERE business_id = ? AND is_read = 0")
            ->execute([$businessId]);
        audit_log('notifications.read_all', 'notifications', null);
        flash('success', 'All notifications marked as read.');
    }
    $ref = $_SERVER['HTTP_REFERER'] ?? (APP_URL . '/index.php');
    header('Location: ' . $ref);
    exit;
}

// Simple full list page (optional) for anyone who navigates here directly
$businessId = user_business_id();
$notifs = [];
if ($businessId) {
    $stmt = db()->prepare(
        "SELECT * FROM notifications WHERE business_id = ?
         ORDER BY created_at DESC LIMIT 100"
    );
    $stmt->execute([$businessId]);
    $notifs = $stmt->fetchAll();
}

$pageTitle = 'Notifications';
$breadcrumbs = ['Notifications' => null];
require __DIR__ . '/includes/header.php';
?>
<div class="rp-panel">
  <div class="rp-panel-head"><h2>All notifications</h2></div>
  <div class="rp-panel-body p-0">
    <table class="rp-table mb-0">
      <thead><tr><th>Type</th><th>Title</th><th>Message</th><th>Date</th><th></th></tr></thead>
      <tbody>
        <?php if (!$notifs): ?>
          <tr><td colspan="5" class="text-center text-muted py-5">No notifications.</td></tr>
        <?php else: foreach ($notifs as $n): ?>
          <tr class="<?= $n['is_read'] ? '' : 'fw-semibold' ?>">
            <td><span class="badge badge-soft-blue"><?= e($n['type']) ?></span></td>
            <td><?= e($n['title']) ?></td>
            <td class="small text-muted"><?= e($n['message']) ?></td>
            <td><small><?= human_datetime($n['created_at']) ?></small></td>
            <td class="text-end">
              <?php if (!$n['is_read']): ?>
                <span class="badge badge-soft-orange">New</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>