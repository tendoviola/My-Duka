<?php
// index.php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) {
    $role = user_role();
    $map = [
        'admin'    => 'admin/dashboard.php',
        'owner'    => 'owner/dashboard.php',
        'employee' => 'employee/dashboard.php'
    ];
    redirect($map[$role] ?? 'login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>My Duka — Smart Retail Management</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500&display=swap');

  :root {
    --navy: #0a0f1e;
    --navy-2: #0f172a;
    --navy-3: #131c31;
    --blue: #2563eb;
    --blue-dark: #1d4ed8;
    --blue-light: #60a5fa;
    --muted: #64748b;
    --line: #e2e8f0;
    --surface: #f8fafc;
    --green: #16a34a;
  }

  * { box-sizing: border-box; }
  html { scroll-behavior: smooth; }
  
  body {
    font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
    background: var(--navy);
    margin: 0; padding: 0;
    overflow-x: hidden;
    color: #fff;
    -webkit-font-smoothing: antialiased;
  }

  a { text-decoration: none; color: inherit; }
  .mono { font-family: 'JetBrains Mono', monospace; }

  /* ============================================
     NAVBAR
     ============================================ */
  .landing-nav-wrap {
    position: fixed;
    top: 1.5rem;
    left: 0; right: 0;
    z-index: 100;
    display: flex;
    justify-content: center;
  }
  
  .landing-nav {
    background: rgba(10, 15, 30, 0.75);
    backdrop-filter: blur(24px) saturate(180%);
    -webkit-backdrop-filter: blur(24px) saturate(180%);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 100px;
    padding: 0.6rem 0.6rem 0.6rem 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 92%;
    max-width: 1100px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.4);
  }

  .landing-logo img { height: 34px; width: auto; }
  
  .nav-cta { display: flex; gap: 0.5rem; align-items: center; }
  
  .btn-nav-login {
    font-weight: 600; color: rgba(255,255,255,0.8);
    padding: 0.6rem 1.15rem; font-size: 0.88rem;
    border-radius: 100px; transition: all 0.15s;
  }
  .btn-nav-login:hover { color: #fff; background: rgba(255,255,255,0.06); }
  
  .btn-nav-register {
    font-weight: 700; background: #fff; color: var(--navy-2);
    padding: 0.6rem 1.25rem; border-radius: 100px; font-size: 0.88rem;
    transition: all 0.15s;
  }
  .btn-nav-register:hover { background: #e2e8f0; transform: scale(1.03); }

  /* ============================================
     HERO
     ============================================ */
  .hero {
    position: relative;
    min-height: 100vh;
    background: #0a0f1e;
    overflow: hidden;
    padding: 10rem 2rem 6rem;
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  /* Background image with high visibility */
  .hero-bg {
    position: absolute;
    inset: 0;
    z-index: 0;
    background-image: url('https://images.unsplash.com/photo-1578916171728-46686eac8d58?q=80&w=2000&auto=format&fit=crop');
    background-size: cover;
    background-position: center;
    /* Slight blur and darkening so text remains readable, but image is clearly visible */
    filter: blur(2px) brightness(0.5);
    transform: scale(1.05);
  }
  
  /* Subtle gradient overlay to anchor the hero text */
  .hero-gradient {
    position: absolute; inset: 0; z-index: 1;
    background: 
      radial-gradient(ellipse 80% 60% at 50% 20%, rgba(37,99,235,0.2) 0%, transparent 60%),
      linear-gradient(180deg, rgba(10, 15, 30, 0.6) 0%, rgba(10, 15, 30, 0.8) 60%, rgba(10, 15, 30, 0.95) 100%);
  }

  /* Grid pattern overlay for that premium tech look */
  .hero-grid {
    position: absolute; inset: 0; z-index: 2;
    background-image: 
      linear-gradient(rgba(255,255,255,0.04) 1px, transparent 1px),
      linear-gradient(90deg, rgba(255,255,255,0.04) 1px, transparent 1px);
    background-size: 60px 60px;
    mask-image: radial-gradient(ellipse 70% 60% at 50% 40%, black, transparent 90%);
    -webkit-mask-image: radial-gradient(ellipse 70% 60% at 50% 40%, black, transparent 90%);
    pointer-events: none;
  }

  .hero-inner {
    position: relative;
    z-index: 3;
    max-width: 900px;
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  .hero-pill {
    display: inline-flex;
    align-items: center;
    gap: 0.6rem;
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(255,255,255,0.12);
    padding: 0.4rem 0.4rem 0.4rem 1rem;
    border-radius: 100px;
    font-size: 0.8rem;
    color: rgba(255,255,255,0.7);
    margin-bottom: 2.5rem;
    font-weight: 500;
    backdrop-filter: blur(10px);
  }
  
  .hero-pill .pill-tag {
    background: var(--blue);
    color: #fff;
    font-size: 0.7rem;
    font-weight: 700;
    padding: 0.2rem 0.6rem;
    border-radius: 100px;
    letter-spacing: 0.03em;
  }
  
  .hero-pill i { font-size: 0.7rem; opacity: 0.5; }

  .hero h1 {
    font-weight: 800;
    font-size: clamp(3rem, 7vw, 6rem);
    line-height: 0.95;
    letter-spacing: -0.05em;
    color: #fff;
    margin-bottom: 2rem;
    text-shadow: 0 10px 40px rgba(0,0,0,0.6);
  }
  
  .hero h1 .accent {
    background: linear-gradient(180deg, #93c5fd 0%, #3b82f6 100%);
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
    text-shadow: none;
  }

  .hero p {
    font-size: clamp(1rem, 1.5vw, 1.25rem);
    color: rgba(255,255,255,0.75);
    max-width: 620px;
    margin: 0 auto 3rem;
    line-height: 1.65;
    font-weight: 400;
    text-shadow: 0 2px 10px rgba(0,0,0,0.5);
  }

  .hero-cta {
    display: flex; gap: 0.75rem; justify-content: center;
    flex-wrap: wrap; margin-bottom: 5rem;
  }

  .btn-hero {
    display: inline-flex; align-items: center; gap: 0.5rem;
    font-weight: 700; font-size: 1rem;
    padding: 1rem 2rem;
    border-radius: 100px;
    transition: all 0.2s;
  }
  
  .btn-hero.primary {
    background: #fff; color: var(--navy-2);
    box-shadow: 0 10px 40px rgba(255,255,255,0.15);
  }
  .btn-hero.primary:hover { transform: translateY(-3px); box-shadow: 0 15px 50px rgba(255,255,255,0.3); }
  
  .btn-hero.secondary {
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    color: #fff;
    backdrop-filter: blur(10px);
  }
  .btn-hero.secondary:hover { background: rgba(255,255,255,0.2); transform: translateY(-3px); }

  /* ============================================
     PRODUCT SHOT
     ============================================ */
  .hero-product-shot {
    position: relative;
    max-width: 1150px;
    width: 100%;
    margin: 0 auto;
    perspective: 2500px;
    z-index: 3;
  }

  .product-shot-inner {
    position: relative;
    border-radius: 18px;
    overflow: hidden;
    background: #0f172a;
    border: 1px solid rgba(255,255,255,0.1);
    box-shadow: 
      0 80px 150px -30px rgba(37,99,235,0.5),
      0 60px 100px -20px rgba(0,0,0,0.9),
      0 0 0 1px rgba(255,255,255,0.05),
      inset 0 1px 0 rgba(255,255,255,0.1);
    transform: rotateX(12deg) scale(0.97);
    transition: transform 1.2s cubic-bezier(0.16, 1, 0.3, 1);
  }
  
  .product-shot-inner:hover { transform: rotateX(0deg) scale(1); }

  .browser-bar {
    background: #1e293b;
    padding: 0.75rem 1rem;
    display: flex; align-items: center; gap: 0.5rem;
    border-bottom: 1px solid rgba(255,255,255,0.05);
  }
  .browser-dots { display: flex; gap: 6px; }
  .browser-dots span { width: 11px; height: 11px; border-radius: 50%; }
  .browser-dots .red { background: #ff5f57; }
  .browser-dots .yellow { background: #febc2e; }
  .browser-dots .green { background: #28c840; }
  
  .browser-url {
    flex: 1;
    background: rgba(255,255,255,0.06);
    border-radius: 6px;
    padding: 0.3rem 0.75rem;
    font-size: 0.7rem;
    color: rgba(255,255,255,0.5);
    text-align: center;
    margin: 0 1rem;
    font-family: 'JetBrains Mono', monospace;
  }

  .app-preview {
    display: grid;
    grid-template-columns: 220px 1fr;
    min-height: 540px;
    background: #f8fafc;
  }

  .app-sidebar {
    background: #0a0f1e;
    padding: 1.5rem 0.85rem;
    border-right: 1px solid rgba(255,255,255,0.05);
  }

  .app-logo {
    display: flex; align-items: center; gap: 0.5rem;
    padding: 0 0.5rem; margin-bottom: 2rem;
    color: #fff; font-weight: 800; font-size: 0.9rem;
  }
  .app-logo i { color: var(--blue-light); }

  .app-nav-section { margin-bottom: 1.75rem; }
  
  .app-nav-label {
    font-size: 0.6rem; color: rgba(255,255,255,0.3);
    text-transform: uppercase; letter-spacing: 0.08em;
    font-weight: 700; padding: 0 0.5rem; margin-bottom: 0.5rem;
  }
  
  .app-nav-item {
    display: flex; align-items: center; gap: 0.65rem;
    padding: 0.5rem 0.55rem; border-radius: 6px;
    color: rgba(255,255,255,0.5);
    font-size: 0.8rem; font-weight: 500; margin-bottom: 2px;
  }
  .app-nav-item i { width: 14px; text-align: center; font-size: 0.72rem; }
  .app-nav-item.active { background: var(--blue); color: #fff; }

  .app-main { padding: 1.75rem; overflow: hidden; background: #f8fafc; }

  .app-header {
    display: flex; justify-content: space-between; align-items: center;
    margin-bottom: 1.75rem;
  }
  .app-greeting h2 { font-size: 1.25rem; font-weight: 800; color: var(--navy-2); margin: 0 0 0.2rem 0; }
  .app-greeting p { font-size: 0.8rem; color: var(--muted); margin: 0; }
  
  .app-avatar {
    width: 36px; height: 36px; border-radius: 50%;
    background: linear-gradient(135deg, var(--blue), var(--blue-dark));
    color: #fff; display: flex; align-items: center; justify-content: center;
    font-weight: 700; font-size: 0.8rem;
    box-shadow: 0 4px 10px rgba(37,99,235,0.3);
  }

  .app-kpis {
    display: grid; grid-template-columns: repeat(4, 1fr);
    gap: 0.85rem; margin-bottom: 1.25rem;
  }
  
  .app-kpi {
    background: #fff; border: 1px solid var(--line);
    border-radius: 12px; padding: 1rem;
  }
  
  .app-kpi-label {
    font-size: 0.65rem; color: var(--muted);
    font-weight: 700; text-transform: uppercase;
    letter-spacing: 0.04em; margin-bottom: 0.4rem;
  }
  
  .app-kpi-value { font-size: 1.05rem; font-weight: 800; color: var(--navy-2); }
  .app-kpi-value.green { color: var(--green); }
  .app-kpi-value.blue { color: var(--blue); }
  
  .app-chart {
    background: #fff; border: 1px solid var(--line);
    border-radius: 12px; padding: 1.25rem; height: 200px;
  }
  
  .app-chart-header { display: flex; justify-content: space-between; margin-bottom: 1rem; }
  .app-chart-title { font-size: 0.85rem; font-weight: 800; color: var(--navy-2); }
  .app-chart-badge {
    font-size: 0.7rem; background: #f0f7ff; color: var(--blue);
    padding: 0.2rem 0.6rem; border-radius: 5px; font-weight: 700;
  }

  .app-chart-bars {
    display: flex; align-items: flex-end; gap: 10px;
    height: 115px; padding-top: 0.5rem;
  }
  
  .app-chart-bar {
    flex: 1;
    background: linear-gradient(180deg, var(--blue), #93c5fd);
    border-radius: 4px 4px 0 0;
    transform-origin: bottom;
    animation: bar-grow 1.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    transform: scaleY(0);
  }
  .app-chart-bar:nth-child(1) { animation-delay: 0.15s; height: 45%; }
  .app-chart-bar:nth-child(2) { animation-delay: 0.25s; height: 65%; }
  .app-chart-bar:nth-child(3) { animation-delay: 0.35s; height: 55%; }
  .app-chart-bar:nth-child(4) { animation-delay: 0.45s; height: 80%; }
  .app-chart-bar:nth-child(5) { animation-delay: 0.55s; height: 70%; }
  .app-chart-bar:nth-child(6) { animation-delay: 0.65s; height: 95%; }
  .app-chart-bar:nth-child(7) { animation-delay: 0.75s; height: 85%; }
  .app-chart-bar:nth-child(8) { animation-delay: 0.85s; height: 100%; }
  
  @keyframes bar-grow { to { transform: scaleY(1); } }

  /* ============================================
     SOCIAL PROOF
     ============================================ */
  .social-proof-bar {
    background: var(--navy-2);
    border-top: 1px solid rgba(255,255,255,0.05);
    border-bottom: 1px solid rgba(255,255,255,0.05);
    padding: 3rem 2rem;
    position: relative;
    z-index: 4;
  }
  
  .proof-inner {
    max-width: 1080px; margin: 0 auto;
    display: flex; justify-content: space-between; align-items: center;
    flex-wrap: wrap; gap: 2rem;
  }
  
  .proof-stats { display: flex; gap: 4rem; flex-wrap: wrap; }
  
  .proof-stat-number {
    font-size: 2rem; font-weight: 800; color: #fff;
    line-height: 1; letter-spacing: -0.03em;
    background: linear-gradient(180deg, #fff, #94a3b8);
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
  }
  
  .proof-stat-label { font-size: 0.8rem; color: rgba(255,255,255,0.5); font-weight: 500; margin-top: 0.4rem; }
  
  .proof-brands { display: flex; gap: 2.5rem; align-items: center; flex-wrap: wrap; opacity: 0.4; }
  
  .proof-brand {
    font-weight: 800; font-size: 1rem; color: #fff;
    display: flex; align-items: center; gap: 0.5rem;
  }

  /* ============================================
     FEATURES
     ============================================ */
  .features-section {
    padding: 9rem 2rem;
    background: #fff;
    position: relative;
    z-index: 4;
  }

  .section-header { max-width: 720px; margin: 0 auto 5rem; text-align: center; }

  .section-tag {
    display: inline-block; font-size: 0.75rem; font-weight: 700;
    color: var(--blue); text-transform: uppercase; letter-spacing: 0.1em;
    margin-bottom: 1rem; background: #f0f7ff;
    padding: 0.35rem 0.85rem; border-radius: 100px;
  }

  .section-title {
    font-weight: 800; font-size: clamp(2rem, 4vw, 3.5rem);
    letter-spacing: -0.045em; color: var(--navy-2);
    margin-bottom: 1rem; line-height: 1.05;
  }

  .section-desc {
    font-size: 1.1rem; color: var(--muted); line-height: 1.7;
    max-width: 560px; margin: 0 auto;
  }

  .bento-grid {
    display: grid; grid-template-columns: repeat(6, 1fr);
    gap: 1.25rem; max-width: 1200px; margin: 0 auto;
  }

  .bento-card {
    background: #fff; border: 1px solid var(--line);
    border-radius: 24px; padding: 2.25rem; position: relative; overflow: hidden;
    transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
  }
  
  .bento-card:hover {
    transform: translateY(-6px);
    box-shadow: 0 30px 60px -20px rgba(37,99,235,0.15);
    border-color: #bfdbfe;
  }
  
  .bento-card.large { grid-column: span 3; }
  .bento-card.small { grid-column: span 2; }
  
  .bento-icon {
    width: 52px; height: 52px; background: #eff6ff;
    border: 1px solid #dbeafe; border-radius: 14px;
    display: flex; align-items: center; justify-content: center;
    color: var(--blue); font-size: 1.35rem; margin-bottom: 1.75rem;
    transition: all 0.3s;
  }
  
  .bento-card:hover .bento-icon {
    background: var(--blue); color: #fff; border-color: var(--blue);
    transform: rotate(-6deg) scale(1.08);
  }
  
  .bento-card h3 {
    font-size: 1.25rem; font-weight: 800; margin-bottom: 0.75rem;
    color: var(--navy-2); letter-spacing: -0.025em;
  }
  
  .bento-card p { font-size: 0.95rem; color: var(--muted); line-height: 1.7; margin: 0; }

  .bento-visual {
    margin-top: 2rem; background: var(--surface);
    border: 1px solid var(--line); border-radius: 14px;
    padding: 1.25rem; display: flex; flex-direction: column; gap: 0.6rem;
  }
  
  .bento-visual-row {
    display: flex; justify-content: space-between;
    font-size: 0.8rem; padding: 0.6rem 0;
    border-bottom: 1px solid var(--line);
  }
  .bento-visual-row:last-child { border-bottom: none; }
  .bento-visual-row b { color: var(--navy-2); font-weight: 800; }
  .bento-visual-row span { color: var(--green); font-weight: 800; font-size: 0.75rem; }

  @media (max-width: 991px) {
    .bento-card.large { grid-column: span 6; }
    .bento-card.small { grid-column: span 3; }
  }
  @media (max-width: 640px) {
    .bento-card.small { grid-column: span 6; }
  }

  /* ============================================
     FINAL CTA
     ============================================ */
  .final-cta {
    padding: 10rem 2rem;
    background: linear-gradient(180deg, #0a0f1e 0%, #0f172a 100%);
    text-align: center;
    position: relative;
    overflow: hidden;
  }

  .final-cta::before {
    content: '';
    position: absolute;
    top: 50%; left: 50%;
    transform: translate(-50%, -50%);
    width: 1000px; height: 1000px;
    background: radial-gradient(ellipse, rgba(37,99,235,0.15), transparent 60%);
    border-radius: 50%;
  }

  .final-cta-inner { position: relative; z-index: 2; max-width: 700px; margin: 0 auto; }

  .final-cta h2 {
    font-size: clamp(2.5rem, 5vw, 4.5rem);
    font-weight: 800; letter-spacing: -0.05em;
    line-height: 1.05; color: #fff; margin-bottom: 1.5rem;
  }
  .final-cta h2 span { color: var(--blue-light); }

  .final-cta p {
    font-size: 1.15rem; color: rgba(255,255,255,0.6);
    max-width: 500px; margin: 0 auto 2.5rem; line-height: 1.6;
  }

  .final-cta-buttons { display: flex; gap: 0.75rem; justify-content: center; flex-wrap: wrap; }

  .btn-cta-primary {
    display: inline-flex; align-items: center; gap: 0.5rem;
    font-weight: 700; background: #fff; color: var(--navy-2);
    padding: 1.1rem 2.25rem; border-radius: 100px; font-size: 1rem;
    transition: all 0.2s; box-shadow: 0 10px 40px rgba(255,255,255,0.15);
  }
  .btn-cta-primary:hover {
    transform: translateY(-3px); box-shadow: 0 20px 50px rgba(255,255,255,0.25);
  }

  .btn-cta-secondary {
    display: inline-flex; align-items: center; gap: 0.5rem;
    font-weight: 700; background: transparent; color: #fff;
    padding: 1.1rem 2.25rem; border-radius: 100px; font-size: 1rem;
    border: 1px solid rgba(255,255,255,0.2); transition: all 0.2s;
  }
  .btn-cta-secondary:hover { background: rgba(255,255,255,0.05); border-color: rgba(255,255,255,0.4); }

  /* ============================================
     SIMPLE FOOTER
     ============================================ */
  .site-footer {
    background: #060a15;
    padding: 2.5rem 2rem;
    border-top: 1px solid rgba(255,255,255,0.05);
    position: relative;
    z-index: 4;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .footer-simple {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 1rem;
    text-align: center;
  }

  .footer-simple img {
    height: 32px;
    width: auto;
    opacity: 0.8;
  }

  .footer-copy {
    color: rgba(255,255,255,0.4);
    font-size: 0.85rem;
    font-weight: 500;
    letter-spacing: 0.01em;
    margin: 0;
  }

  /* ============================================
     RESPONSIVE
     ============================================ */
  @media (max-width: 991px) {
    .app-preview { grid-template-columns: 1fr; }
    .app-sidebar { display: none; }
    .app-kpis { grid-template-columns: repeat(2, 1fr); }
  }

  @media (max-width: 640px) {
    .hero { padding: 8rem 1rem 3rem; background-attachment: scroll; }
    .hero-cta { flex-direction: column; width: 100%; }
    .btn-hero { width: 100%; justify-content: center; }
    .proof-inner { flex-direction: column; align-items: flex-start; }
    .proof-stats { gap: 2rem; }
  }
</style>
</head>
<body>

<!-- NAVIGATION -->
<div class="landing-nav-wrap">
  <nav class="landing-nav">
    <a href="index.php" class="landing-logo">
      <img src="<?= e(APP_URL) ?>/assets/logo/logo.png" alt="My Duka">
    </a>
    
    <div class="nav-cta">
      <a href="login.php" class="btn-nav-login">Sign in</a>
      <a href="register.php" class="btn-nav-register">Get started →</a>
    </div>
  </nav>
</div>

<!-- HERO -->
<section class="hero">
  <div class="hero-bg"></div>
  <div class="hero-gradient"></div>
  <div class="hero-grid"></div>
  
  <div class="hero-inner">
    
    <div class="hero-pill">
      <span class="pill-tag">NEW</span>
      <span>Built for Ugandan retailers</span>
      <i class="fa-solid fa-arrow-right"></i>
    </div>
    
    <h1>
      The operating system<br>
      for <span class="accent">modern retail.</span>
    </h1>
    
    <p>
      Track inventory, process sales, manage your team, and understand your business — all from one beautiful dashboard.
    </p>
    
    <div class="hero-cta">
      <a href="register.php" class="btn-hero primary">
        Register Now <i class="fa-solid fa-arrow-right"></i>
      </a>
      <a href="login.php" class="btn-hero secondary">
         Get Back in
      </a>
    </div>
    
    <div class="hero-product-shot">
      <div class="product-shot-inner">
        
        <div class="browser-bar">
          <div class="browser-dots">
            <span class="red"></span>
            <span class="yellow"></span>
            <span class="green"></span>
          </div>
          <div class="browser-url">myduka.app/dashboard</div>
        </div>
        
        <div class="app-preview">
          <aside class="app-sidebar">
            <div class="app-logo"><i class="fa-solid fa-store"></i> My Duka</div>
            
            <div class="app-nav-section">
              <div class="app-nav-label">Main</div>
              <div class="app-nav-item active"><i class="fa-solid fa-gauge-high"></i> Dashboard</div>
              <div class="app-nav-item"><i class="fa-solid fa-cash-register"></i> Point of Sale</div>
            </div>
            
            <div class="app-nav-section">
              <div class="app-nav-label">Catalog</div>
              <div class="app-nav-item"><i class="fa-solid fa-box"></i> Products</div>
              <div class="app-nav-item"><i class="fa-solid fa-warehouse"></i> Inventory</div>
            </div>
            
            <div class="app-nav-section">
              <div class="app-nav-label">Manage</div>
              <div class="app-nav-item"><i class="fa-solid fa-users"></i> Employees</div>
              <div class="app-nav-item"><i class="fa-solid fa-chart-line"></i> Reports</div>
            </div>
          </aside>
          
          <div class="app-main">
            <div class="app-header">
              <div class="app-greeting">
                <h2>Good evening, Sarah 👋</h2>
                <p>Here's what's happening in your business today.</p>
              </div>
              <div class="app-avatar">SN</div>
            </div>
            
            <div class="app-kpis">
              <div class="app-kpi">
                <div class="app-kpi-label">Sales Today</div>
                <div class="app-kpi-value">UGX 2.4M</div>
              </div>
              <div class="app-kpi">
                <div class="app-kpi-label">Gross Profit</div>
                <div class="app-kpi-value green">UGX 850K</div>
              </div>
              <div class="app-kpi">
                <div class="app-kpi-label">Low Stock</div>
                <div class="app-kpi-value" style="color: #dc2626;">4 items</div>
              </div>
              <div class="app-kpi">
                <div class="app-kpi-label">Branches</div>
                <div class="app-kpi-value blue">3 active</div>
              </div>
            </div>
            
            <div class="app-chart">
              <div class="app-chart-header">
                <div class="app-chart-title">Revenue Trend</div>
                <div class="app-chart-badge">Last 7 days</div>
              </div>
              <div class="app-chart-bars">
                <div class="app-chart-bar"></div>
                <div class="app-chart-bar"></div>
                <div class="app-chart-bar"></div>
                <div class="app-chart-bar"></div>
                <div class="app-chart-bar"></div>
                <div class="app-chart-bar"></div>
                <div class="app-chart-bar"></div>
                <div class="app-chart-bar"></div>
              </div>
            </div>
          </div>
        </div>
        
      </div>
    </div>
    
  </div>
</section>

<!-- SOCIAL PROOF -->
<section class="social-proof-bar">
  <div class="proof-inner">
    <div class="proof-stats">
      <div>
        <div class="proof-stat-number">500+</div>
        <div class="proof-stat-label">Businesses running on My Duka</div>
      </div>
      <div>
        <div class="proof-stat-number">2M+</div>
        <div class="proof-stat-label">Transactions processed</div>
      </div>
    </div>
    <div class="proof-brands">
      <div class="proof-brand"><i class="fa-solid fa-store"></i> Kampala Mart</div>
      <div class="proof-brand"><i class="fa-solid fa-basket-shopping"></i> Quality Grocers</div>
      <div class="proof-brand"><i class="fa-solid fa-cash-register"></i> Mukono Retail</div>
    </div>
  </div>
</section>

<!-- FEATURES -->
<section class="features-section" id="features">
  <div class="section-header">
    <span class="section-tag">Everything you need</span>
    <h2 class="section-title">Built for the way<br>you actually work.</h2>
    <p class="section-desc">Every feature is designed to save you time and give you clarity — no bloat, no complicated setup.</p>
  </div>

  <div class="bento-grid">
    
    <div class="bento-card large">
      <div class="bento-icon"><i class="fa-solid fa-cash-register"></i></div>
      <h3>Lightning-fast POS</h3>
      <p>Process sales in seconds. Accept cash, mobile money, and bank transfers. Every transaction updates your inventory instantly.</p>
      <div class="bento-visual">
        <div class="bento-visual-row"><span>Cash Payment</span><b>UGX 45,000</b> <span>✓</span></div>
        <div class="bento-visual-row"><span>Mobile Money</span><b>UGX 120,000</b> <span>✓</span></div>
        <div class="bento-visual-row"><span>Bank Transfer</span><b>UGX 200,000</b> <span>✓</span></div>
      </div>
    </div>

    <div class="bento-card large">
      <div class="bento-icon"><i class="fa-solid fa-chart-line"></i></div>
      <h3>Real business intelligence</h3>
      <p>Know exactly where your money is going. Beautiful reports on sales, profit, expenses, and employee performance.</p>
      <div class="bento-visual">
        <div class="bento-visual-row"><span>Revenue</span><b>UGX 12.4M</b></div>
        <div class="bento-visual-row"><span>Gross Profit</span><b>UGX 4.8M</b> <span>+38%</span></div>
        <div class="bento-visual-row"><span>Net Profit</span><b>UGX 3.2M</b> <span>+24%</span></div>
      </div>
    </div>

    <div class="bento-card small">
      <div class="bento-icon"><i class="fa-solid fa-boxes-stacked"></i></div>
      <h3>Smart inventory</h3>
      <p>Real-time stock tracking with automatic low-stock alerts.</p>
    </div>

    <div class="bento-card small">
      <div class="bento-icon"><i class="fa-solid fa-users"></i></div>
      <h3>Team access</h3>
      <p>Give employees their own accounts with role-based permissions.</p>
    </div>

    <div class="bento-card small">
      <div class="bento-icon"><i class="fa-solid fa-store"></i></div>
      <h3>Multi-branch</h3>
      <p>Manage multiple shops from one account. Compare performance across branches.</p>
    </div>

  </div>
</section>

<!-- FINAL CTA -->
<section class="final-cta" id="get-started">
  <div class="final-cta-inner">
    <h2>Ready to take<br><span>control of your business?</span></h2>
    <p>Join hundreds of Ugandan retailers who've already made the switch. Free to start, no credit card required.</p>
    <div class="final-cta-buttons">
      <a href="register.php" class="btn-cta-primary">
        Create free account <i class="fa-solid fa-arrow-right"></i>
      </a>
      <a href="login.php" class="btn-cta-secondary">
        Sign in
      </a>
    </div>
  </div>
</section>

<!-- SIMPLE FOOTER -->
<footer class="site-footer">
  <div class="footer-simple">
    <img src="<?= e(APP_URL) ?>/assets/logo/logo.png" alt="My Duka">
    <p class="footer-copy">&copy; <?= date('Y') ?> My Duka. All rights reserved.</p>
  </div>
</footer>

</body>
</html>