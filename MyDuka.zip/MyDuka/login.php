<?php
// login.php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) redirect('index.php');

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email    = post('email');
    $password = post('password');

    if ($email === '' || $password === '') {
        $error = 'Please enter your email and password.';
    } else {
        $res = attempt_login($email, $password);
        if ($res['ok']) {
            $role = $res['user']['role_name'];
            $map  = ['admin' => 'admin/dashboard.php',
                     'owner' => 'owner/dashboard.php',
                     'employee' => 'employee/dashboard.php'];
            redirect($map[$role] ?? 'index.php');
        }
        $error = $res['msg'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign in · <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

  :root {
    --navy: #0a0f1e;
    --navy-2: #0f172a;
    --navy-3: #131c31;
    --blue: #2563eb;
    --blue-dark: #1d4ed8;
    --blue-light: #60a5fa;
    --line: #e2e8f0;
    --muted: #64748b;
    --green: #16a34a;
  }

  body {
    font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
    background-color: var(--navy-2);
    margin: 0; padding: 0; height: 100vh; overflow: hidden;
    -webkit-font-smoothing: antialiased;
  }

  .login-wrapper { display: flex; height: 100vh; width: 100vw; }

  /* ============================================
     LEFT PANEL — BRANDING
     ============================================ */
  .login-left {
    display: none; flex: 1;
    background: #0a0f1e;
    position: relative; overflow: hidden; padding: 4rem;
    flex-direction: column; justify-content: space-between; align-items: center;
    color: #fff;
  }

  @media (min-width: 992px) { .login-left { display: flex; } }

  /* Subtle grid pattern */
  .login-left::before {
    content: ''; position: absolute; inset: 0;
    background-image: 
      linear-gradient(rgba(255, 255, 255, 0.04) 1px, transparent 1px),
      linear-gradient(90deg, rgba(255, 255, 255, 0.04) 1px, transparent 1px);
    background-size: 60px 60px;
    mask-image: radial-gradient(ellipse 70% 60% at 50% 40%, black, transparent 90%);
    -webkit-mask-image: radial-gradient(ellipse 70% 60% at 50% 40%, black, transparent 90%);
  }
  
  /* Blue glow orb */
  .login-left::after {
    content: ''; position: absolute; top: -20%; right: -10%;
    width: 600px; height: 600px;
    background: radial-gradient(circle, rgba(37, 99, 235, 0.25) 0%, transparent 70%);
    filter: blur(60px); border-radius: 50%;
    pointer-events: none;
  }

  .brand-content {
    text-align: center;
    position: relative; 
    z-index: 2;
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-top: auto;
    margin-bottom: auto;
  }

  .login-logo-wrap {
    margin-bottom: 3rem;
    display: inline-block;
    text-decoration: none;
    transition: transform 0.2s ease;
  }
  .login-logo-wrap:hover { transform: scale(1.05); }
  
  .login-logo-img {
    height: 100px;
    width: auto;
    max-width: 320px;
    object-fit: contain;
    transform: scale(1.3); 
  }

  .login-left h1 {
    font-weight: 800; font-size: 3rem;
    letter-spacing: -0.03em; line-height: 1.1; margin-bottom: 1.5rem;
    color: #fff;
  }
  
  .login-left p { 
    color: #94a3b8; 
    font-size: 1.1rem; 
    line-height: 1.6; 
    max-width: 450px; 
    margin: 0 auto; 
  }

  /* ============================================
     RIGHT PANEL — FORM
     ============================================ */
  .login-right {
    flex: 1; display: flex; align-items: center; justify-content: center;
    padding: 2rem; background: #fff; position: relative;
  }

  .form-wrapper { width: 100%; max-width: 420px; }

  .form-header { margin-bottom: 2.5rem; text-align: center; }
  .form-header h3 { font-weight: 800; font-size: 1.75rem; color: var(--navy-2); letter-spacing: -0.02em; margin-bottom: 0.5rem; }
  .form-header p { color: var(--muted); font-size: 0.95rem; }

  /* Inputs */
  .form-group { margin-bottom: 1.25rem; }
  .form-group label { display: block; font-size: 0.85rem; font-weight: 700; color: #334155; margin-bottom: 0.4rem; }

  .input-wrapper { position: relative; }
  .input-wrapper input {
    width: 100%; padding: 0.85rem 1rem; padding-right: 3rem;
    border-radius: 10px; border: 1px solid var(--line);
    font-size: 0.95rem; font-weight: 500; color: var(--navy-2);
    background: #f8fafc; transition: all 0.2s;
  }
  .input-wrapper input:focus {
    outline: none; background: #fff; border-color: var(--blue);
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
  }

  .toggle-password {
    position: absolute; right: 0.85rem; top: 50%; transform: translateY(-50%);
    background: none; border: none; color: #94a3b8; cursor: pointer; padding: 0.25rem;
    font-size: 1.1rem; transition: color 0.2s;
  }
  .toggle-password:hover { color: var(--navy-2); }

  /* Alerts */
  .alert-custom {
    background: #fef2f2; color: #991b1b; border: 1px solid #fecaca;
    border-radius: 10px; padding: 0.85rem 1rem; font-size: 0.85rem; font-weight: 600;
    margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.5rem;
  }

  /* Submit Button */
  .btn-submit {
    width: 100%; background: var(--blue); color: #fff; border: none;
    border-radius: 10px; padding: 0.9rem; font-weight: 700; font-size: 1rem;
    transition: all 0.2s; margin-top: 1rem; display: flex; justify-content: center; align-items: center; gap: 0.5rem;
    box-shadow: 0 8px 20px rgba(37, 99, 235, 0.25);
  }
  .btn-submit:hover { background: var(--blue-dark); transform: translateY(-2px); box-shadow: 0 12px 25px rgba(37, 99, 235, 0.35); }

  /* Footer Links */
  .footer-text { text-align: center; font-size: 0.9rem; color: var(--muted); margin-top: 2rem; }
  .footer-text a { font-weight: 700; color: var(--blue); text-decoration: none; }
  .footer-text a:hover { text-decoration: underline; }
  
  .back-link {
    display: block;
    text-align: center;
    font-size: 0.85rem;
    color: #94a3b8;
    text-decoration: none;
    margin-top: 1.5rem;
    transition: color 0.2s;
  }
  .back-link:hover { color: var(--navy-2); }

  /* Forgot Password link */
  .forgot-link {
    font-size: 0.8rem;
    font-weight: 600;
    color: var(--blue);
    text-decoration: none;
    transition: color 0.2s;
  }
  .forgot-link:hover { color: var(--blue-dark); text-decoration: underline; }
</style>
</head>
<body>

<div class="login-wrapper">
  <!-- LEFT SIDE: BRANDING -->
  <div class="login-left">
    
    <div class="brand-content">
      <a href="index.php" class="login-logo-wrap" title="Back to Home">
        <img src="<?= e(APP_URL) ?>/assets/logo/logo.png" alt="<?= e(APP_NAME) ?> Logo" class="login-logo-img">
      </a>
      
      <h1>Run your business <br> smarter, not harder.</h1>
      <p>The all-in-one platform for modern retail management, inventory tracking, and point of sale operations.</p>
    </div>
    
    <div style="position: relative; z-index: 2;">
      <p class="small mb-0" style="opacity: 0.6;">&copy; <?= date('Y') ?> <?= e(APP_NAME) ?>. All rights reserved.</p>
    </div>
  </div>

  <!-- RIGHT SIDE: FORM -->
  <div class="login-right">
    <div class="form-wrapper">
      <div class="form-header">
        <h3>Welcome back</h3>
        <p>Enter your credentials to access your workspace.</p>
      </div>

      <?= render_flashes() ?>
      <?php if ($error): ?>
        <div class="alert-custom">
          <i class="fa-solid fa-circle-exclamation fs-5"></i> <?= e($error) ?>
        </div>
      <?php endif; ?>

      <form method="post" novalidate>
        <?= csrf_field() ?>
        
        <div class="form-group">
          <label for="email">Email Address</label>
          <div class="input-wrapper">
            <input type="email" name="email" id="email" class="form-control" value="<?= e($email) ?>" required autofocus placeholder="name@company.com">
          </div>
        </div>

        <div class="form-group">
          <div class="d-flex justify-content-between align-items-center mb-1">
            <label for="password" class="mb-0">Password</label>
            <a href="forgot_password.php" class="forgot-link">Forgot password?</a>
          </div>
          <div class="input-wrapper">
            <input type="password" name="password" id="password" class="form-control" required placeholder="••••••••">
            <button type="button" class="toggle-password" id="toggleBtn">
              <i class="fa-regular fa-eye"></i>
            </button>
          </div>
        </div>

        <button type="submit" class="btn-submit">
          Sign In <i class="fa-solid fa-arrow-right"></i>
        </button>
      </form>

      <p class="footer-text">
        Don't have an account? <a href="register.php">Create one</a>
      </p>

      <a href="index.php" class="back-link">
        <i class="fa-solid fa-arrow-left me-1" style="font-size: 0.75rem;"></i> Back to Home
      </a>
    </div>
  </div>
</div>

<script>
  // Eye Toggle Logic
  const toggleBtn = document.getElementById('toggleBtn');
  const passwordInput = document.getElementById('password');
  const icon = toggleBtn.querySelector('i');

  toggleBtn.addEventListener('click', function() {
    if (passwordInput.type === 'password') {
      passwordInput.type = 'text';
      icon.classList.replace('fa-eye', 'fa-eye-slash');
      this.style.color = '#2563eb';
    } else {
      passwordInput.type = 'password';
      icon.classList.replace('fa-eye-slash', 'fa-eye');
      this.style.color = '#94a3b8';
    }
  });
</script>

</body>
</html>