<?php
require_once __DIR__ . '/includes/auth.php';

// The password you want to use
$newPassword = 'Password123!';
$hash = password_hash($newPassword, PASSWORD_DEFAULT);

// Update the admin user
$stmt = db()->prepare("UPDATE users SET password_hash = ? WHERE email = 'admin@retailpro.local'");
$stmt->execute([$hash]);

echo "<h1>Success!</h1>";
echo "<p>Admin password has been updated to: <strong>" . $newPassword . "</strong></p>";
echo "<p>Hash used: " . $hash . "</p>";
echo "<p><a href='login.php'>Go to Login</a></p>";