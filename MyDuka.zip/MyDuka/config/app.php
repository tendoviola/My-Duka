<?php
// config/app.php
declare(strict_types=1);

// ---- Environment ----
define('APP_ENV',        'development');           // 'production' when live
define('APP_NAME',       'My Duka');
define('APP_URL',        'http://localhost/MyDuka');
define('APP_TIMEZONE',   'Africa/Kampala');
define('APP_CURRENCY',   'UGX');

// ---- Session hardening ----
define('SESSION_NAME',      'retailpro_sid');
define('SESSION_LIFETIME',  60 * 60 * 8);   // 8 hours
define('SESSION_COOKIE_SECURE', false);      // true when running on HTTPS

// ---- Security ----
define('CSRF_TOKEN_NAME',   '_csrf');
define('PASSWORD_MIN_LEN',  8);

// ---- Uploads ----
define('UPLOAD_DIR',      __DIR__ . '/../assets/uploads');
define('UPLOAD_MAX_SIZE', 2 * 1024 * 1024);  // 2MB
define('UPLOAD_MIME',     ['image/jpeg', 'image/png', 'image/webp', 'image/gif']);

// ---- Error display ----
date_default_timezone_set(APP_TIMEZONE);

if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
}

// ---- Session ----
if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_set_cookie_params([
        'lifetime' => SESSION_LIFETIME,
        'path'     => '/',
        'secure'   => SESSION_COOKIE_SECURE,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}