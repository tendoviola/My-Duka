<?php
// includes/functions.php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';

/* ------------------------------------------------------------------
 |  Output / escaping
 * ------------------------------------------------------------------ */
function e(?string $v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $path): void {
    header('Location: ' . $path);
    exit;
}

function old(string $key, $default = '') {
    return $_SESSION['_old'][$key] ?? $default;
}

function clear_old(): void {
    unset($_SESSION['_old']);
}

/* ------------------------------------------------------------------
 |  Flash messages
 * ------------------------------------------------------------------ */
function flash(string $type, string $message): void {
    $_SESSION['_flash'][] = ['type' => $type, 'message' => $message];
}

function get_flashes(): array {
    $f = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return $f;
}

function render_flashes(): string {
    $out = '';
    foreach (get_flashes() as $f) {
        $type = e($f['type']);
        $msg  = e($f['message']);
        $out .= "<div class=\"alert alert-{$type} alert-dismissible fade show\" role=\"alert\">"
              . $msg
              . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>'
              . '</div>';
    }
    return $out;
}

/* ------------------------------------------------------------------
 |  CSRF
 * ------------------------------------------------------------------ */
function csrf_token(): string {
    if (empty($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

function csrf_field(): string {
    return '<input type="hidden" name="' . CSRF_TOKEN_NAME . '" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void {
    $sent = $_POST[CSRF_TOKEN_NAME] ?? '';
    if (!is_string($sent) || !hash_equals($_SESSION[CSRF_TOKEN_NAME] ?? '', $sent)) {
        http_response_code(419);
        flash('danger', 'Security token expired. Please try again.');
        redirect($_SERVER['HTTP_REFERER'] ?? '/retailpro/login.php');
    }
}

/* ------------------------------------------------------------------
 |  Input helpers
 * ------------------------------------------------------------------ */
function post(string $key, $default = '') {
    return isset($_POST[$key]) ? trim((string)$_POST[$key]) : $default;
}

function get(string $key, $default = '') {
    return isset($_GET[$key]) ? trim((string)$_GET[$key]) : $default;
}

function post_int(string $key, int $default = 0): int {
    return isset($_POST[$key]) ? (int)$_POST[$key] : $default;
}

function post_float(string $key, float $default = 0.0): float {
    return isset($_POST[$key]) ? (float)$_POST[$key] : $default;
}

/* ------------------------------------------------------------------
 |  Formatting
 * ------------------------------------------------------------------ */
function money(float $amount): string {
    return APP_CURRENCY . ' ' . number_format($amount, 2);
}

function num(float $n, int $dec = 2): string {
    return number_format($n, $dec);
}

function human_date(?string $dt): string {
    if (!$dt) return '—';
    return date('d M Y', strtotime($dt));
}

function human_datetime(?string $dt): string {
    if (!$dt) return '—';
    return date('d M Y, H:i', strtotime($dt));
}

/* ------------------------------------------------------------------
 |  Unique-number generators (per business)
 * ------------------------------------------------------------------ */
function generate_number(string $prefix, string $table, string $column, int $businessId): string {
    $pdo = db();
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM {$table} WHERE business_id = ?"
    );
    $stmt->execute([$businessId]);
    $seq = ((int)$stmt->fetchColumn()) + 1;
    $date = date('Ymd');
    $num  = sprintf('%s-%s-%05d', $prefix, $date, $seq);

    // Ensure uniqueness under race (loop safely)
    $check = $pdo->prepare("SELECT 1 FROM {$table} WHERE business_id = ? AND {$column} = ? LIMIT 1");
    while (true) {
        $check->execute([$businessId, $num]);
        if (!$check->fetchColumn()) break;
        $seq++;
        $num = sprintf('%s-%s-%05d', $prefix, $date, $seq);
    }
    return $num;
}

/* ------------------------------------------------------------------
 |  Validation
 * ------------------------------------------------------------------ */
function validate_required(array $fields, array $data): array {
    $errors = [];
    foreach ($fields as $key => $label) {
        if (!isset($data[$key]) || trim((string)$data[$key]) === '') {
            $errors[$key] = "{$label} is required.";
        }
    }
    return $errors;
}

function valid_email(string $email): bool {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function valid_phone(string $phone): bool {
    // Uganda + general: allow digits, spaces, +, -, ()
    return (bool)preg_match('/^[0-9+\-\s()]{7,20}$/', $phone);
}

/* ------------------------------------------------------------------
 |  Slug / SKU helpers
 * ------------------------------------------------------------------ */
function slugify(string $text): string {
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    return trim($text, '-');
}

/* ------------------------------------------------------------------
 |  Small utility for JSON responses (used by /api later)
 * ------------------------------------------------------------------ */
function json_out(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}