<?php
// includes/auth.php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';

/* ------------------------------------------------------------------
 |  Current user
 * ------------------------------------------------------------------ */
function current_user(): ?array {
    static $cached = null;
    if ($cached !== null) return $cached;
    if (empty($_SESSION['user_id'])) return null;

    $stmt = db()->prepare(
        "SELECT u.*, r.name AS role_name, b.name AS business_name, b.status AS business_status
         FROM users u
         JOIN roles r ON r.id = u.role_id
         LEFT JOIN businesses b ON b.id = u.business_id
         WHERE u.id = ? AND u.status = 'active'
         LIMIT 1"
    );
    $stmt->execute([$_SESSION['user_id']]);
    $u = $stmt->fetch();
    $cached = $u ?: null;
    return $cached;
}

function is_logged_in(): bool {
    return current_user() !== null;
}

function user_role(): ?string {
    return current_user()['role_name'] ?? null;
}

function user_business_id(): ?int {
    $u = current_user();
    return $u && $u['business_id'] ? (int)$u['business_id'] : null;
}

/* ------------------------------------------------------------------
 |  Login / Logout
 * ------------------------------------------------------------------ */
function attempt_login(string $email, string $password): array {
    $stmt = db()->prepare(
        "SELECT u.*, r.name AS role_name, b.status AS business_status
         FROM users u
         JOIN roles r ON r.id = u.role_id
         LEFT JOIN businesses b ON b.id = u.business_id
         WHERE u.email = ? LIMIT 1"
    );
    $stmt->execute([$email]);
    $u = $stmt->fetch();

    if (!$u || !password_verify($password, $u['password_hash'])) {
        return ['ok' => false, 'msg' => 'Invalid email or password.'];
    }
    if ($u['status'] !== 'active') {
        return ['ok' => false, 'msg' => 'Your account is not active. Contact the administrator.'];
    }

    // ── NEW: Block unverified users ──
    // Admins are always considered verified (created via SQL).
    if ($u['role_name'] !== 'admin' && empty($u['email_verified_at'])) {
        return ['ok' => false, 'msg' => 'Please verify your email address first. Check your inbox for the verification link.'];
    }
    // ─────────────────────────────────

    if ($u['role_name'] !== 'admin'
        && $u['business_status'] !== null
        && $u['business_status'] !== 'active') {
        return ['ok' => false, 'msg' => 'Your business account is suspended or pending approval.'];
    }

    // Regenerate session ID on login (session fixation protection)
    session_regenerate_id(true);
    $_SESSION['user_id']     = (int)$u['id'];
    $_SESSION['role']        = $u['role_name'];
    $_SESSION['business_id'] = $u['business_id'] ? (int)$u['business_id'] : null;
    $_SESSION['login_at']    = time();

    // Update last login
    db()->prepare("UPDATE users SET last_login_at = NOW() WHERE id = ?")
        ->execute([$u['id']]);

    return ['ok' => true, 'user' => $u];
}

function logout(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

/* ------------------------------------------------------------------
 |  Forced password change
 |    Users with must_change_password = 1 (e.g. owner-created employees)
 |    are redirected to password_change.php before accessing any other
 |    protected page. Login, logout, and the change page itself are
 |    the only allowed destinations.
 * ------------------------------------------------------------------ */
function maybe_force_password_change(): void {
    $u = current_user();
    if (!$u) return;
    if ((int)$u['must_change_password'] !== 1) return;

    $current = basename($_SERVER['PHP_SELF']);
    $allowed = ['password_change.php', 'logout.php', 'login.php'];
    if (!in_array($current, $allowed, true)) {
        redirect(APP_URL . '/password_change.php');
    }
}

/* ------------------------------------------------------------------
 |  Route protection
 * ------------------------------------------------------------------ */
function require_login(): void {
    if (!is_logged_in()) {
        flash('warning', 'Please log in to continue.');
        redirect(APP_URL . '/login.php');
    }
    maybe_force_password_change();
}

function require_role(string ...$roles): void {
    require_login();
    $r = user_role();
    if (!in_array($r, $roles, true)) {
        http_response_code(403);
        flash('danger', 'You are not authorized to access this page.');
        redirect(APP_URL . '/index.php');
    }
}

/* ------------------------------------------------------------------
 |  Permission checks
 |    1. Admins bypass (mostly).
 |    2. Check user_permissions override first (granted/revoked).
 |    3. Fall back to role_permissions.
 * ------------------------------------------------------------------ */
function has_permission(string $code): bool {
    $u = current_user();
    if (!$u) return false;
    if ($u['role_name'] === 'admin') return true;

    static $cache = [];
    $key = $u['id'] . '|' . $code;
    if (isset($cache[$key])) return $cache[$key];

    $stmt = db()->prepare(
        "SELECT p.id,
                (SELECT granted FROM user_permissions up
                  WHERE up.user_id = :uid AND up.permission_id = p.id LIMIT 1) AS override_granted,
                (SELECT 1 FROM role_permissions rp
                  WHERE rp.role_id = :rid AND rp.permission_id = p.id LIMIT 1) AS role_granted
         FROM permissions p WHERE p.code = :code LIMIT 1"
    );
    $stmt->execute([':uid' => $u['id'], ':rid' => $u['role_id'], ':code' => $code]);
    $row = $stmt->fetch();

    $allowed = false;
    if ($row) {
        if ($row['override_granted'] !== null) {
            $allowed = (bool)$row['override_granted'];
        } else {
            $allowed = (bool)$row['role_granted'];
        }
    }
    return $cache[$key] = $allowed;
}

function require_permission(string $code): void {
    require_login();
    if (!has_permission($code)) {
        http_response_code(403);
        flash('danger', 'Permission denied.');
        redirect(APP_URL . '/index.php');
    }
}

/* ------------------------------------------------------------------
 |  Branch access
 * ------------------------------------------------------------------ */
function user_branch_ids(): array {
    $u = current_user();
    if (!$u) return [];
    if ($u['role_name'] === 'owner') {
        // Owner sees all branches of own business
        $stmt = db()->prepare("SELECT id FROM branches WHERE business_id = ? AND status = 'active'");
        $stmt->execute([$u['business_id']]);
        return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
    }
    $stmt = db()->prepare("SELECT branch_id FROM user_branch_assignments WHERE user_id = ?");
    $stmt->execute([$u['id']]);
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}

function can_access_branch(int $branchId): bool {
    return in_array($branchId, user_branch_ids(), true);
}

function require_branch_access(int $branchId): void {
    if (!can_access_branch($branchId)) {
        http_response_code(403);
        flash('danger', 'You do not have access to that branch.');
        redirect(APP_URL . '/index.php');
    }
}

/* ------------------------------------------------------------------
 |  Audit log helper — append-only
 * ------------------------------------------------------------------ */
function audit_log(string $action, ?string $entity = null, ?int $entityId = null,
                   ?array $details = null, ?int $branchId = null): void {
    $u = current_user();
    $stmt = db()->prepare(
        "INSERT INTO audit_logs (business_id, branch_id, user_id, action, entity, entity_id, details, ip_address)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt->execute([
        $u['business_id'] ?? null,
        $branchId,
        $u['id'] ?? null,
        $action,
        $entity,
        $entityId,
        $details ? json_encode($details, JSON_UNESCAPED_UNICODE) : null,
        $_SERVER['REMOTE_ADDR'] ?? null,
    ]);
}