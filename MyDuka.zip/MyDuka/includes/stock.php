<?php
// includes/stock.php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';

/**
 * Ensure an inventory row exists for (product, branch).
 */
function inventory_row(PDO $pdo, int $businessId, int $branchId, int $productId): array {
    $stmt = $pdo->prepare(
        "SELECT id, quantity, weighted_avg_cost
         FROM inventory
         WHERE business_id = ? AND branch_id = ? AND product_id = ?
         LIMIT 1
         FOR UPDATE"
    );
    $stmt->execute([$businessId, $branchId, $productId]);
    $row = $stmt->fetch();
    if ($row) return $row;

    $pdo->prepare(
        "INSERT INTO inventory (business_id, branch_id, product_id, quantity, weighted_avg_cost)
         VALUES (?, ?, ?, 0, 0)"
    )->execute([$businessId, $branchId, $productId]);

    return [
        'id'                => (int)$pdo->lastInsertId(),
        'quantity'          => 0.0,
        'weighted_avg_cost' => 0.0,
    ];
}

/**
 * Apply a stock increase/decrease in one atomic step:
 *  - updates inventory.quantity and (optionally) weighted_avg_cost
 *  - writes a stock_movements ledger row
 *
 * @param float $qty       positive = add, negative = deduct
 * @param float|null $unitCost  when adding purchased stock, pass the buying price so
 *                              weighted_avg_cost is recalculated. Pass null to leave it untouched.
 * @return array ['prev_balance','new_balance','new_avg_cost','movement_id']
 */
function apply_stock_change(
    PDO $pdo,
    int $businessId,
    int $branchId,
    int $productId,
    float $qty,
    string $movementType,
    ?float $unitCost,
    ?string $referenceTable,
    ?int $referenceId,
    ?string $reason,
    int $userId
): array {
    if ($qty == 0.0) {
        throw new InvalidArgumentException('Quantity cannot be zero.');
    }

    $inv = inventory_row($pdo, $businessId, $branchId, $productId);
    $prevQty = (float)$inv['quantity'];
    $prevAvg = (float)$inv['weighted_avg_cost'];

    if ($qty < 0 && ($prevQty + $qty) < 0) {
        $allowNeg = (bool)db_business_setting($businessId, 'allow_negative_stock', false);
        if (!$allowNeg) {
            throw new RuntimeException('Insufficient stock for this operation.');
        }
    }

    $newQty = $prevQty + $qty;
    $newAvg = $prevAvg;

    // Recalculate weighted average ONLY when we're adding purchased stock with a known cost
    if ($qty > 0 && $unitCost !== null) {
        $prevValue = $prevQty * $prevAvg;
        $newValue  = $qty * $unitCost;
        $totalQty  = $prevQty + $qty;
        if ($totalQty > 0) {
            $newAvg = ($prevValue + $newValue) / $totalQty;
        } else {
            $newAvg = $unitCost;
        }
    }

    // Update inventory cached balance
    $pdo->prepare(
        "UPDATE inventory SET quantity = ?, weighted_avg_cost = ? WHERE id = ?"
    )->execute([$newQty, $newAvg, (int)$inv['id']]);

    // Append ledger row
    $pdo->prepare(
        "INSERT INTO stock_movements
            (business_id, branch_id, product_id, movement_type, quantity,
             prev_balance, new_balance, unit_cost, reference_table, reference_id,
             reason, user_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    )->execute([
        $businessId, $branchId, $productId, $movementType, $qty,
        $prevQty, $newQty, $unitCost, $referenceTable, $referenceId,
        $reason, $userId,
    ]);
    $movementId = (int)$pdo->lastInsertId();

    // Fire low-stock notification if crossing threshold
    maybe_notify_low_stock($pdo, $businessId, $branchId, $productId, $newQty);

    return [
        'prev_balance' => $prevQty,
        'new_balance'  => $newQty,
        'new_avg_cost' => $newAvg,
        'movement_id'  => $movementId,
    ];
}

/**
 * Read a business setting with a default.
 */
function db_business_setting(int $businessId, string $key, mixed $default = null): mixed {
    static $cache = [];
    if (!isset($cache[$businessId])) {
        $stmt = db()->prepare("SELECT * FROM business_settings WHERE business_id = ? LIMIT 1");
        $stmt->execute([$businessId]);
        $cache[$businessId] = $stmt->fetch() ?: [];
    }
    return $cache[$businessId][$key] ?? $default;
}

/**
 * Create a low_stock notification if this product has just fallen to or below
 * min_stock_level. Idempotent within a 24h window.
 */
function maybe_notify_low_stock(PDO $pdo, int $businessId, int $branchId, int $productId, float $newQty): void {
    $stmt = $pdo->prepare(
        "SELECT p.name, p.min_stock_level, p.unit, b.name AS branch_name
         FROM products p JOIN branches b ON b.id = ?
         WHERE p.id = ? LIMIT 1"
    );
    $stmt->execute([$branchId, $productId]);
    $p = $stmt->fetch();
    if (!$p) return;
    if ($newQty > (float)$p['min_stock_level'] && $newQty > 0) return;

    // Skip if an unread low_stock notification for the same product/branch exists in last 24h
    $dupe = $pdo->prepare(
        "SELECT 1 FROM notifications
         WHERE business_id = ? AND branch_id = ? AND type = 'low_stock'
           AND title LIKE ? AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR) LIMIT 1"
    );
    $dupe->execute([$businessId, $branchId, '%' . $p['name'] . '%']);
    if ($dupe->fetchColumn()) return;

    $out = $newQty <= 0;
    $pdo->prepare(
        "INSERT INTO notifications (business_id, branch_id, user_id, type, title, message)
         VALUES (?, ?, NULL, ?, ?, ?)"
    )->execute([
        $businessId, $branchId,
        $out ? 'out_of_stock' : 'low_stock',
        ($out ? 'Out of stock: ' : 'Low stock: ') . $p['name'],
        sprintf('%s at %s is now %s %s (min %s).',
            $p['name'], $p['branch_name'], num($newQty), $p['unit'], num((float)$p['min_stock_level'])),
    ]);
}