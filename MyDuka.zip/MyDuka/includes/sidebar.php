<?php
// includes/sidebar.php
declare(strict_types=1);
if (!function_exists('current_user')) require_once __DIR__ . '/auth.php';

$__u        = current_user();
$__role     = $__u['role_name'] ?? '';
$__current  = basename($_SERVER['PHP_SELF']);
$__dir      = basename(dirname($_SERVER['PHP_SELF']));
$__business = user_business_id();

/* ---------------------------------------------------------------
 | Active-link detection
 * --------------------------------------------------------------- */
function rp_nav_active(mixed $target): string {
    global $__current, $__dir;
    if (is_array($target)) {
        foreach ($target as $t) if (rp_nav_active($t) === 'active') return 'active';
        return '';
    }
    $target = (string)$target;
    if (str_contains($target, '/')) {
        [$dir, $file] = explode('/', $target, 2);
        return ($dir === $__dir && $file === $__current) ? 'active' : '';
    }
    return $target === $__current ? 'active' : '';
}

/* ---------------------------------------------------------------
 | Batch permission check
 * --------------------------------------------------------------- */
function rp_can(?string $perm): bool {
    if ($perm === null) return true;
    static $map = [];
    if (!array_key_exists($perm, $map)) $map[$perm] = has_permission($perm);
    return $map[$perm];
}

/* ---------------------------------------------------------------
 | Badges
 * --------------------------------------------------------------- */
function rp_low_stock_count(int $businessId): int {
    static $n = null;
    if ($n !== null) return $n;
    $stmt = db()->prepare("SELECT COUNT(*) FROM inventory i JOIN products p ON p.id = i.product_id WHERE i.business_id = ? AND i.quantity <= p.min_stock_level");
    $stmt->execute([$businessId]);
    return $n = (int)$stmt->fetchColumn();
}

function rp_unread_notifications(int $businessId): int {
    static $n = null;
    if ($n !== null) return $n;
    $stmt = db()->prepare("SELECT COUNT(*) FROM notifications WHERE business_id = ? AND is_read = 0");
    $stmt->execute([$businessId]);
    return $n = (int)$stmt->fetchColumn();
}

$__lowStock   = ($__role === 'owner' && $__business) ? rp_low_stock_count($__business) : 0;
$__unread     = $__business ? rp_unread_notifications($__business) : 0;
$__initials   = '';
if ($__u) {
    foreach (array_slice(preg_split('/\s+/', trim($__u['full_name'])), 0, 2) as $p) {
        $__initials .= mb_strtoupper(mb_substr($p, 0, 1));
    }
}

/* ---------------------------------------------------------------
 | Menu
 * --------------------------------------------------------------- */
$__nav = [];
if ($__role === 'owner') {
    $__nav = [
        'Main' => [
            ['Dashboard',     'fa-gauge-high',      'owner/dashboard.php',   null,           null],
            ['Point of Sale', 'fa-cash-register',   'owner/pos.php',         'sale.create',  null],
        ],
        'Catalog' => [
            ['Products',      'fa-box',             'owner/products.php',    'product.view', null],
            ['Categories',    'fa-tags',            'owner/categories.php',  'category.view',null],
            ['Inventory',     'fa-warehouse',       'owner/inventory.php',   'inventory.view','low_stock'],
        ],
        'Operations' => [
            ['Purchases',     'fa-truck-ramp-box',  'owner/purchases.php',   'purchase.view',null],
            ['Sales',         'fa-receipt',         'owner/sales.php',       'sale.view',    null],
            ['Stock Transfers','fa-right-left',     'owner/transfers.php',   'transfer.view',null],
        ],
        'Partners & Finance' => [
            ['Suppliers',     'fa-handshake',       'owner/suppliers.php',   'supplier.view',null],
            ['Customers',     'fa-users',           'owner/customers.php',   'customer.view',null],
            ['Expenses',      'fa-wallet',          'owner/expenses.php',    'expense.view', null],
        ],
        'Manage' => [
            ['Employees',     'fa-user-tie',        'owner/employees.php',   'employee.view',null],
            ['Branches',      'fa-store',           'owner/branches.php',    'branch.view',  null],
            ['Reports',       'fa-chart-line',      'owner/reports.php',     'report.view',  null],
            ['Activity Logs', 'fa-shield-halved',   'owner/activity.php',    'audit.view',   null],
            ['Settings',      'fa-gear',            'owner/settings.php',    null,           null],
        ],
    ];
} elseif ($__role === 'employee') {
    $__nav = [
        'Main' => [
            ['Dashboard',     'fa-gauge-high',      'employee/dashboard.php',  null,           null],
            ['Point of Sale', 'fa-cash-register',   'employee/pos.php',        'sale.create',  null],
        ],
        'Catalog' => [
            ['Products',      'fa-box',             'employee/products.php',   'product.view', null],
            ['Stock Info',    'fa-warehouse',       'employee/stock_info.php', 'inventory.view',null],
        ],
        'Sales' => [
            ['Sales History', 'fa-receipt',         'employee/sales_history.php','sale.view_own',null],
        ],
        'Account' => [
            ['Profile',       'fa-user',            'employee/profile.php',    null,           null],
        ],
    ];
} elseif ($__role === 'admin') {
    $__nav = [
        'Overview' => [
            ['Dashboard',     'fa-gauge-high',      'admin/dashboard.php',     null,           null],
        ],
        'Platform' => [
            ['Businesses',    'fa-building',        'admin/businesses.php',    null,           null],
            ['Users',         'fa-users-gear',      'admin/users.php',         null,           null],
            ['Branches',      'fa-store',           'admin/branches.php',      null,           null],
            ['Categories',    'fa-tags',            'admin/categories.php',    null,           null],
        ],
        'System' => [
            ['Activity',      'fa-shield-halved',   'admin/activity.php',      null,           null],
            ['Settings',      'fa-gear',            'admin/settings.php',      null,           null],
        ],
    ];
}

$__badges = [
    'low_stock' => $__lowStock,
    'unread'    => $__unread,
];
?>
<aside class="rp-sidebar" id="rpSidebar" aria-label="Main navigation">

     <!-- Brand -->
<a href="<?= e(APP_URL) ?>/index.php" class="rp-sidebar-brand" aria-label="MY DUKA Dashboard">
  <div class="rp-brand-logo-wrap">
    <img src="<?= e(APP_URL) ?>/assets/logo/logo.png" alt="MY DUKA Logo" class="rp-brand-logo">
  </div>
</a>
  <nav class="rp-nav" aria-label="Site sections">
    <?php foreach ($__nav as $section => $items):
      $visible = array_filter($items, fn($it) => rp_can($it[3]));
      if (!$visible) continue;
    ?>
      <div class="rp-nav-section">
        <div class="rp-nav-heading"><?= e($section) ?></div>
        <?php foreach ($items as [$label, $icon, $target, $perm, $badgeKey]):
          if (!rp_can($perm)) continue;
          $isActive = rp_nav_active($target) === 'active';
          $badgeCount = $badgeKey !== null ? ($__badges[$badgeKey] ?? 0) : 0;
        ?>
          <a href="<?= e(APP_URL . '/' . $target) ?>"
             class="rp-nav-link <?= $isActive ? 'active' : '' ?>"
             <?= $isActive ? 'aria-current="page"' : '' ?>>
            <i class="fa-solid <?= e($icon) ?>"></i>
            <span class="rp-nav-label"><?= e($label) ?></span>
            <?php if ($badgeCount > 0): ?>
              <span class="rp-nav-badge"><?= $badgeCount > 99 ? '99+' : (int)$badgeCount ?></span>
            <?php endif; ?>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endforeach; ?>
  </nav>

  <!-- User Footer -->
  <div class="rp-sidebar-footer">
    <div class="rp-sidebar-user">
      <div class="rp-user-avatar"><?= e($__initials ?: 'U') ?></div>
      <div class="rp-user-info">
        <div class="rp-user-name"><?= e($__u['full_name'] ?? 'User') ?></div>
        <div class="rp-user-role"><?= e(ucfirst($__role)) ?></div>
      </div>
      <a href="<?= e(APP_URL) ?>/logout.php" class="rp-logout-btn" title="Sign out">
        <i class="fa-solid fa-arrow-right-from-bracket"></i>
      </a>
    </div>
  </div>

</aside>