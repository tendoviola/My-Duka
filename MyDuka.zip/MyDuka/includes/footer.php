<?php
// includes/footer.php
declare(strict_types=1);
?>
    </main>

    <footer class="rp-footer">
      <span>&copy; <?= date('Y') ?> <?= e(APP_NAME) ?>. All rights reserved.</span>
      <span class="text-muted small">v1.0</span>
    </footer>
  </div><!-- /.rp-main -->
</div><!-- /.rp-layout -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script src="<?= e(APP_URL) ?>/assets/js/main.js"></script>
<?php if (!empty($pageScripts)): ?>
  <?php foreach ((array)$pageScripts as $__s): ?>
    <script src="<?= e(APP_URL . '/' . $__s) ?>"></script>
  <?php endforeach; ?>
<?php endif; ?>
</body>
</html>