<?php
// includes/uploads.php
declare(strict_types=1);

/**
 * Handles a single image upload safely.
 * Returns the relative path (e.g. "products/2026/03/abc123.jpg")
 * or null if no file was uploaded.
 * Throws RuntimeException on validation failures.
 */
function handle_image_upload(array $file, string $subdir = 'products'): ?string {
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Upload failed (code ' . $file['error'] . ').');
    }
    if ($file['size'] > UPLOAD_MAX_SIZE) {
        throw new RuntimeException('File exceeds ' . (UPLOAD_MAX_SIZE / 1024 / 1024) . 'MB limit.');
    }

    // Verify actual MIME — not the browser-supplied type
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime  = $finfo->file($file['tmp_name']);
    if (!in_array($mime, UPLOAD_MIME, true)) {
        throw new RuntimeException('Only JPG, PNG, WEBP or GIF images are allowed.');
    }

    $ext = match ($mime) {
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',
        default      => 'bin',
    };

    $rel = $subdir . '/' . date('Y') . '/' . date('m');
    $abs = rtrim(UPLOAD_DIR, '/') . '/' . $rel;
    if (!is_dir($abs) && !mkdir($abs, 0775, true) && !is_dir($abs)) {
        throw new RuntimeException('Could not create upload directory.');
    }

    $name = bin2hex(random_bytes(10)) . '.' . $ext;
    $dest = $abs . '/' . $name;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        throw new RuntimeException('Could not save uploaded file.');
    }
    @chmod($dest, 0644);

    return $rel . '/' . $name;
}

/**
 * Best-effort deletion of a previously uploaded file.
 */
function delete_upload(?string $relPath): void {
    if (!$relPath) return;
    $abs = rtrim(UPLOAD_DIR, '/') . '/' . ltrim($relPath, '/');
    if (is_file($abs)) @unlink($abs);
}

/**
 * Public URL for a stored file, or null.
 */
function upload_url(?string $relPath): ?string {
    if (!$relPath) return null;
    return APP_URL . '/assets/uploads/' . ltrim($relPath, '/');
}