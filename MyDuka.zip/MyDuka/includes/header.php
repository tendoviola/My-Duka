<?php
// includes/header.php
declare(strict_types=1);
if (!function_exists('current_user')) {
    require_once __DIR__ . '/auth.php';
}
$__user = current_user();
$__pageTitle = $pageTitle ?? APP_NAME;
$__role = $__user['role_name'] ?? '';
$__initials = '';
if ($__user) {
    $parts = preg_split('/\s+/', trim($__user['full_name']));
    foreach (array_slice($parts, 0, 2) as $p) $__initials .= mb_strtoupper(mb_substr($p, 0, 1));
}

// Determine the correct settings/profile URL based on role
$__profileUrl = APP_URL . '/index.php';
if ($__role === 'owner') $__profileUrl = APP_URL . '/owner/settings.php';
elseif ($__role === 'employee') $__profileUrl = APP_URL . '/employee/profile.php';
elseif ($__role === 'admin') $__profileUrl = APP_URL . '/admin/settings.php?tab=security';

// Fetch Notifications
$__notifs = [];
if ($__user && !empty($__user['business_id'])) {
    $__nstmt = db()->prepare(
        "SELECT id, title, message, created_at
         FROM notifications
         WHERE business_id = ? AND is_read = 0
         ORDER BY created_at DESC LIMIT 5"
    );
    $__nstmt->execute([$__user['business_id']]);
    $__notifs = $__nstmt->fetchAll();
}

// Ensure $breadcrumbs is an array. If empty, fallback to the page title.
if (empty($breadcrumbs) || !is_array($breadcrumbs)) {
    $breadcrumbs = [$__pageTitle => null];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($__pageTitle) ?> · <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="<?= e(APP_URL) ?>/assets/css/style.css" rel="stylesheet">
<link href="<?= e(APP_URL) ?>/assets/css/dashboard.css" rel="stylesheet">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700&display=swap');

  /* --- Enterprise Header Styling --- */
  .rp-topbar {
    background: rgba(255, 255, 255, 0.88) !important;
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border-bottom: 1px solid #e2e8f0;
    height: 72px; 
    padding: 0 1.5rem;
    display: flex;
    align-items: center;
    gap: 1.5rem;
    position: sticky;
    top: 0;
    z-index: 1020;
    box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.03);
  }

  /* --- PROFESSIONAL BREADCRUMB SYSTEM --- */
  .rp-breadcrumb {
    font-family: 'Outfit', sans-serif;
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 0.6rem;
    margin: 0;
    padding: 0;
    line-height: 1.2;
  }

  .rp-breadcrumb-item {
    display: inline-flex;
    align-items: center;
    font-size: 1.25rem;
    font-weight: 600;
    letter-spacing: -0.01em;
  }

  /* Previous links (Black / Interactive) */
  .rp-breadcrumb-item a {
    color: #0f172a;
    text-decoration: none;
    transition: color 0.2s;
  }

  .rp-breadcrumb-item a:hover {
    color: #2563eb;
  }

  /* The active current page (Blue) */
  .rp-breadcrumb-item.active {
    color: #2563eb;
    font-weight: 800;
  }

  /* Elegant Chevron Separator */
  .rp-breadcrumb-sep {
    color: #cbd5e1;
    font-size: 0.8rem;
    font-weight: 400;
    margin: 0 0.15rem;
  }

  /* --- Responsive Logic --- */
  /* On mobile, hide all crumbs EXCEPT the last one */
  @media (max-width: 767.98px) {
    .rp-breadcrumb-item:not(.active),
    .rp-breadcrumb-sep {
      display: none;
    }
  }

  /* Notification Button */
  .rp-action-btn {
    width: 40px; height: 40px;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    color: #64748b;
    cursor: pointer;
    transition: all 0.2s;
    position: relative;
  }
  .rp-action-btn:hover { background: #f1f5f9; color: #0f172a; border-color: #cbd5e1; }
  
  .rp-notif-dot {
    position: absolute; top: 9px; right: 11px;
    width: 8px; height: 8px; border-radius: 50%;
    background: #ef4444; border: 2px solid #fff;
  }

  /* Notification Dropdown */
  .rp-notif-menu {
    width: 340px;
    border-radius: 12px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 10px 30px -5px rgba(0,0,0,0.1);
    overflow: hidden;
    margin-top: 12px !important;
  }
  .rp-notif-header {
    padding: 1rem 1.25rem;
    background: #f8fafc;
    border-bottom: 1px solid #e2e8f0;
    display: flex; justify-content: space-between; align-items: center;
  }
  .rp-notif-row {
    padding: 1rem 1.25rem;
    border-bottom: 1px solid #f1f5f9;
    transition: background 0.15s;
  }
  .rp-notif-row:hover { background: #f8fafc; }
  .rp-notif-row:last-child { border-bottom: none; }
  .rp-notif-title { font-family: 'Inter', sans-serif; font-weight: 700; font-size: 0.85rem; color: #0f172a; margin-bottom: 2px; }
  .rp-notif-desc { font-family: 'Inter', sans-serif; font-size: 0.8rem; color: #64748b; margin-bottom: 6px; line-height: 1.3; }
  .rp-notif-time { font-family: 'Inter', sans-serif; font-size: 0.7rem; font-weight: 500; color: #94a3b8; }

  /* User Profile Menu */
  .rp-user-btn {
    display: flex; align-items: center; gap: 0.75rem;
    background: transparent; border: 1px solid transparent;
    border-radius: 10px; padding: 0.35rem 0.5rem 0.35rem 0.35rem;
    cursor: pointer; transition: all 0.2s;
  }
  .rp-user-btn:hover { background: #f8fafc; border-color: #e2e8f0; }
  
  .rp-avatar {
    width: 38px; height: 38px; border-radius: 10px;
    display: inline-flex; align-items: center; justify-content: center;
    background: linear-gradient(135deg, #2563eb, #1d4ed8);
    color: #fff; font-family: 'Outfit', sans-serif; font-weight: 700; font-size: 0.9rem;
    box-shadow: 0 4px 10px rgba(37,99,235,0.2);
  }
  
  .rp-user-meta strong { font-family: 'Inter', sans-serif; font-size: 0.85rem; font-weight: 700; color: #0f172a; line-height: 1.2; }
  .rp-user-meta small { font-family: 'Inter', sans-serif; font-size: 0.75rem; color: #64748b; font-weight: 500; line-height: 1.2; }
  
  .rp-user-dropdown {
    width: 220px; border-radius: 12px; border: 1px solid #e2e8f0;
    box-shadow: 0 10px 30px -5px rgba(0,0,0,0.1); margin-top: 12px !important;
    padding: 0.5rem 0;
  }
  .rp-user-dropdown .dropdown-item {
    font-family: 'Inter', sans-serif;
    font-size: 0.85rem; font-weight: 500; padding: 0.6rem 1.25rem; color: #334155;
  }
  .rp-user-dropdown .dropdown-item:hover { background: #f8fafc; color: #0f172a; }
  .rp-user-dropdown .dropdown-item i { width: 20px; text-align: center; }
</style>
</head>
<body class="rp-app">

<div class="rp-layout">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="rp-main">
    <!-- Top bar -->
    <header class="rp-topbar">
      <button class="rp-burger" id="rpBurger" aria-label="Toggle menu">
        <i class="fa-solid fa-bars"></i>
      </button>

      <!-- Professional Breadcrumb Title -->
      <div class="flex-grow-1">
        <nav aria-label="breadcrumb">
          <ol class="rp-breadcrumb">
            <?php 
              $__crumbs = array_keys($breadcrumbs);
              $__lastIndex = count($__crumbs) - 1;
              foreach ($__crumbs as $i => $label): 
                $href = $breadcrumbs[$label];
                $isLast = ($i === $__lastIndex);
            ?>
              <li class="rp-breadcrumb-item <?= $isLast ? 'active' : '' ?>">
                <?php if ($href === null || $isLast): ?>
                  <span aria-current="page"><?= e($label) ?></span>
                <?php else: ?>
                  <a href="<?= e($href) ?>"><?= e($label) ?></a>
                <?php endif; ?>
              </li>
              
              <?php if (!$isLast): ?>
                <span class="rp-breadcrumb-sep"><i class="fa-solid fa-chevron-right"></i></span>
              <?php endif; ?>
            <?php endforeach; ?>
          </ol>
        </nav>
      </div>

      <div class="rp-topbar-actions d-flex align-items-center gap-2">
        
        <!-- Notifications -->
        <div class="dropdown">
          <button class="rp-action-btn" data-bs-toggle="dropdown" aria-label="Notifications">
            <i class="fa-regular fa-bell"></i>
            <?php if (!empty($__notifs)): ?>
              <span class="rp-notif-dot"></span>
            <?php endif; ?>
          </button>
          
          <div class="dropdown-menu dropdown-menu-end p-0 rp-notif-menu">
            <div class="rp-notif-header">
              <strong class="small text-dark fw-bold">Notifications</strong>
              <?php if (!empty($__notifs)): ?>
                <form method="post" action="<?= e(APP_URL) ?>/notifications.php" class="m-0">
                  <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
                  <input type="hidden" name="action" value="mark_all_read">
                  <button class="btn btn-sm btn-link p-0 text-decoration-none fw-semibold" style="font-size: 0.75rem;">Mark all read</button>
                </form>
              <?php endif; ?>
            </div>
            
            <div style="max-height: 300px; overflow-y: auto;">
              <?php if (!$__notifs): ?>
                <div class="px-3 py-4 text-center">
                  <i class="fa-regular fa-bell-slash text-muted mb-2" style="font-size: 1.5rem; opacity: 0.5;"></i>
                  <div class="text-muted small">You're all caught up!</div>
                </div>
              <?php else: foreach ($__notifs as $n): ?>
                <div class="rp-notif-row">
                  <div class="rp-notif-title"><?= e($n['title']) ?></div>
                  <div class="rp-notif-desc"><?= e(mb_strimwidth($n['message'], 0, 70, '…')) ?></div>
                  <div class="rp-notif-time"><?= human_datetime($n['created_at']) ?></div>
                </div>
              <?php endforeach; endif; ?>
            </div>
          </div>
        </div>

        <!-- User Menu -->
        <div class="dropdown">
          <button class="rp-user-btn" data-bs-toggle="dropdown" aria-expanded="false">
            <span class="rp-avatar"><?= e($__initials ?: 'U') ?></span>
            <span class="rp-user-meta d-none d-md-flex flex-column text-start">
              <strong><?= e($__user['full_name'] ?? 'User') ?></strong>
              <small><?= e(ucfirst($__role)) ?></small>
            </span>
            <i class="fa-solid fa-chevron-down small ms-1 d-none d-md-inline text-muted" style="font-size: 0.75rem;"></i>
          </button>
          
          <ul class="dropdown-menu dropdown-menu-end rp-user-dropdown">
            <li>
              <div class="px-3 py-2 border-bottom mb-1 d-md-none">
                <div class="fw-bold text-dark"><?= e($__user['full_name'] ?? 'User') ?></div>
                <div class="text-muted small"><?= e(ucfirst($__role)) ?></div>
              </div>
            </li>
            <li><a class="dropdown-item" href="<?= e($__profileUrl) ?>"><i class="fa-regular fa-user text-muted me-2"></i>My Profile</a></li>
            <li><a class="dropdown-item" href="<?= e(APP_URL) ?>/password_change.php"><i class="fa-solid fa-key text-muted me-2"></i>Change Password</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="<?= e(APP_URL) ?>/logout.php"><i class="fa-solid fa-arrow-right-from-bracket me-2"></i>Log out</a></li>
          </ul>
        </div>
        
      </div>
    </header>

    <main class="rp-content">
      <?= render_flashes() ?>