<?php
// employee/dashboard.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_role('employee');

$pdo = db();
$userId = (int)current_user()['id'];
$businessId = user_business_id();
$branchIds = user_branch_ids();
$activeBranch = (int)($_SESSION['active_branch_id'] ?? ($branchIds[0] ?? 0));

if (!$branchIds) {
    $pageTitle = 'Dashboard';
    require __DIR__ . '/../includes/header.php';
    echo '<div class="alert alert-warning">You are not assigned to any branch. Please contact your employer.</div>';
    require __DIR__ . '/../includes/footer.php';
    exit;
}

// Today's sales for THIS employee
$stmt = $pdo->prepare(
    "SELECT COALESCE(SUM(total_amount),0) AS revenue,
            COUNT(*) AS txn
     FROM sales
     WHERE user_id = ? AND DATE(sale_date) = CURDATE()
       AND status IN ('completed','credit')"
);
$stmt->execute([$userId]);
$today = $stmt->fetch();

// Recent transactions (own)
$stmt = $pdo->prepare(
    "SELECT sale_number, total_amount, sale_date, status
     FROM sales WHERE user_id = ?
     ORDER BY sale_date DESC LIMIT 5"
);
$stmt->execute([$userId]);
$recent = $stmt->fetchAll();

// Available products in active branch
$stmt = $pdo->prepare(
    "SELECT COUNT(*) FROM inventory WHERE branch_id = ? AND quantity > 0"
);
$stmt->execute([$activeBranch]);
$availableProducts = (int)$stmt->fetchColumn();

// Low stock (permitted view)
$stmt = $pdo->prepare(
    "SELECT p.name, p.unit, inv.quantity, p.min_stock_level
     FROM inventory inv JOIN products p ON p.id = inv.product_id
     WHERE inv.branch_id = ? AND inv.quantity <= p.min_stock_level
     ORDER BY inv.quantity ASC LIMIT 5"
);
$stmt->execute([$activeBranch]);
$lowStock = $stmt->fetchAll();

$firstName = explode(' ', current_user()['full_name'])[0];

$pageTitle = 'Dashboard';
$breadcrumbs = ['Dashboard' => null];
require __DIR__ . '/../includes/header.php';
?>

<!-- Custom CSS for Pro Dashboard -->
<style>
  /* Import a premium font */
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

  .pro-dashboard {
    font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
    color: #1e293b;
  }

  /* Premium Hero Banner */
  .hero-banner {
    background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%);
    border-radius: 20px;
    padding: 2.5rem 2rem;
    position: relative;
    overflow: hidden;
    box-shadow: 0 10px 30px -10px rgba(15, 23, 42, 0.5);
  }
  
  /* Subtle grid pattern overlay for texture */
  .hero-banner::before {
    content: '';
    position: absolute;
    inset: 0;
    background-image: linear-gradient(rgba(255, 255, 255, 0.05) 1px, transparent 1px),
                      linear-gradient(90deg, rgba(255, 255, 255, 0.05) 1px, transparent 1px);
    background-size: 20px 20px;
    mask-image: linear-gradient(to bottom, black, transparent);
    -webkit-mask-image: linear-gradient(to bottom, black, transparent);
  }
  
  /* Glowing orb effect */
  .hero-banner::after {
    content: '';
    position: absolute;
    top: -50%; right: -10%;
    width: 400px; height: 400px;
    background: radial-gradient(circle, rgba(59, 130, 246, 0.4) 0%, transparent 70%);
    filter: blur(40px);
    border-radius: 50%;
    pointer-events: none;
  }

  .hero-banner h2 { font-weight: 800; letter-spacing: -0.02em; }
  .hero-banner p { color: #94a3b8; font-weight: 500; }
  
  /* Premium Action Tiles */
  .pro-action-btn {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 16px;
    padding: 1.25rem 1rem;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    color: #334155;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.02), 0 2px 4px -2px rgba(0, 0, 0, 0.02);
  }
  
  .pro-action-btn:hover {
    transform: translateY(-4px);
    box-shadow: 0 12px 20px -8px rgba(0, 0, 0, 0.08);
    border-color: #cbd5e1;
    color: #1e293b;
  }

  .pro-action-btn .icon-wrapper {
    width: 48px; height: 48px;
    border-radius: 12px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.25rem;
    margin-bottom: 0.75rem;
    transition: transform 0.3s ease;
  }
  
  .pro-action-btn:hover .icon-wrapper { transform: scale(1.1); }

  /* Premium KPI Cards */
  .pro-kpi {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 16px;
    padding: 1.5rem;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.02);
    transition: box-shadow 0.3s ease;
    height: 100%;
  }
  
  .pro-kpi:hover { box-shadow: 0 12px 24px -10px rgba(0, 0, 0, 0.08); }
  
  .pro-kpi-label {
    font-size: 0.75rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: #64748b;
    margin-bottom: 0.5rem;
  }
  
  .pro-kpi-value {
    font-size: 1.85rem;
    font-weight: 800;
    letter-spacing: -0.03em;
    color: #0f172a;
    line-height: 1.2;
    margin-bottom: 0.25rem;
  }

  .pro-kpi-sub { font-size: 0.85rem; color: #64748b; font-weight: 500; }

  /* Premium Panels */
  .pro-panel {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.02);
    height: 100%;
    display: flex;
    flex-direction: column;
  }
  
  .pro-panel-header {
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid #e2e8f0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: #f8fafc;
  }
  
  .pro-panel-header h5 {
    font-weight: 700;
    font-size: 1rem;
    margin: 0;
    color: #0f172a;
  }

  /* Premium Lists */
  .pro-list { flex: 1; overflow-y: auto; max-height: 400px; }
  
  .pro-list-item {
    display: flex;
    align-items: center;
    padding: 1rem 1.5rem;
    border-bottom: 1px solid #f1f5f9;
    transition: background 0.15s ease;
  }
  
  .pro-list-item:last-child { border-bottom: none; }
  .pro-list-item:hover { background: #f8fafc; }
  
  .pro-list-icon {
    width: 40px; height: 40px;
    border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    margin-right: 1rem;
    font-size: 1rem;
    flex-shrink: 0;
  }

  /* Custom Scrollbar for lists */
  .pro-list::-webkit-scrollbar { width: 6px; }
  .pro-list::-webkit-scrollbar-track { background: transparent; }
  .pro-list::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
  .pro-list::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
</style>

<div class="pro-dashboard">

  <!-- HERO BANNER -->
  <div class="hero-banner mb-4 d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-4">
    <div style="position: relative; z-index: 2;">
      <span class="badge bg-primary mb-2 px-3 py-2 text-uppercase" style="font-weight: 700; letter-spacing: 0.05em; border-radius: 8px;">Workspace Overview</span>
      <h2 class="text-white mb-2">Welcome back, <?= e($firstName) ?>.</h2>
      <p class="mb-0">Here is what is happening in your branch today.</p>
    </div>
    
    <?php if (has_permission('sale.create')): ?>
      <a href="<?= e(APP_URL) ?>/employee/pos.php" class="btn btn-light btn-lg px-4 py-3 fw-bold shadow-sm d-flex align-items-center gap-2" style="border-radius: 12px; position: relative; z-index: 2; color: #1e3a8a;">
        <i class="fa-solid fa-cash-register"></i> Launch POS
      </a>
    <?php endif; ?>
  </div>

  <!-- QUICK ACTIONS -->
  <div class="row g-3 mb-4">
    <?php if (has_permission('sale.create')): ?>
      <div class="col-6 col-md-3">
        <a href="<?= e(APP_URL) ?>/employee/pos.php" class="pro-action-btn">
          <div class="icon-wrapper" style="background: #eff6ff; color: #2563eb;"><i class="fa-solid fa-cart-plus"></i></div>
          <span class="fw-bold fs-6">New Sale</span>
        </a>
      </div>
    <?php endif; ?>

    <?php if (has_permission('sale.view_own') || has_permission('sale.view')): ?>
      <div class="col-6 col-md-3">
        <a href="<?= e(APP_URL) ?>/employee/sales_history.php" class="pro-action-btn">
          <div class="icon-wrapper" style="background: #f0fdf4; color: #16a34a;"><i class="fa-solid fa-receipt"></i></div>
          <span class="fw-bold fs-6">Sales History</span>
        </a>
      </div>
    <?php endif; ?>

    <?php if (has_permission('inventory.view')): ?>
      <div class="col-6 col-md-3">
        <a href="<?= e(APP_URL) ?>/employee/stock_info.php" class="pro-action-btn">
          <div class="icon-wrapper" style="background: #fffbeb; color: #d97706;"><i class="fa-solid fa-boxes-stacked"></i></div>
          <span class="fw-bold fs-6">Check Stock</span>
        </a>
      </div>
    <?php endif; ?>

    <?php if (has_permission('product.view')): ?>
      <div class="col-6 col-md-3">
        <a href="<?= e(APP_URL) ?>/employee/products.php" class="pro-action-btn">
          <div class="icon-wrapper" style="background: #f8fafc; color: #475569;"><i class="fa-solid fa-tags"></i></div>
          <span class="fw-bold fs-6">Product Catalog</span>
        </a>
      </div>
    <?php endif; ?>
  </div>

  <!-- KPI CARDS -->
  <div class="row g-3 mb-4">
    <div class="col-md-4">
      <div class="pro-kpi">
        <div class="d-flex justify-content-between align-items-start mb-3">
          <div class="pro-kpi-label">Today's Revenue</div>
          <div style="width: 32px; height: 32px; border-radius: 8px; background: #eff6ff; color: #2563eb; display:flex; align-items:center; justify-content:center;">
            <i class="fa-solid fa-arrow-trend-up"></i>
          </div>
        </div>
        <div class="pro-kpi-value"><?= money((float)$today['revenue']) ?></div>
        <div class="pro-kpi-sub"><span class="text-success fw-bold"><i class="fa-solid fa-check-circle me-1"></i>Active</span> · <?= (int)$today['txn'] ?> transactions</div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="pro-kpi">
        <div class="d-flex justify-content-between align-items-start mb-3">
          <div class="pro-kpi-label">Available Products</div>
          <div style="width: 32px; height: 32px; border-radius: 8px; background: #f0fdf4; color: #16a34a; display:flex; align-items:center; justify-content:center;">
            <i class="fa-solid fa-box-open"></i>
          </div>
        </div>
        <div class="pro-kpi-value"><?= $availableProducts ?></div>
        <div class="pro-kpi-sub">In current branch</div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="pro-kpi">
        <div class="d-flex justify-content-between align-items-start mb-3">
          <div class="pro-kpi-label">Low Stock Alerts</div>
          <div style="width: 32px; height: 32px; border-radius: 8px; background: #fef2f2; color: #dc2626; display:flex; align-items:center; justify-content:center;">
            <i class="fa-solid fa-triangle-exclamation"></i>
          </div>
        </div>
        <div class="pro-kpi-value"><?= count($lowStock) ?></div>
        <div class="pro-kpi-sub">Require your attention</div>
      </div>
    </div>
  </div>

  <!-- LISTS -->
  <div class="row g-4">
    
    <!-- Recent Transactions -->
    <div class="col-lg-7">
      <div class="pro-panel">
        <div class="pro-panel-header">
          <h5>Recent Transactions</h5>
          <a href="<?= e(APP_URL) ?>/employee/sales_history.php" class="text-decoration-none fw-bold small" style="color: #2563eb;">View All &rarr;</a>
        </div>
        <div class="pro-list">
          <?php if (!$recent): ?>
            <div class="text-center text-muted py-5">
              <div class="mb-3"><i class="fa-solid fa-receipt" style="font-size: 3rem; opacity: 0.2;"></i></div>
              <h6 class="fw-bold text-dark mb-1">No transactions yet</h6>
              <p class="small mb-0">When you make a sale, it will appear here.</p>
            </div>
          <?php else: foreach ($recent as $s): ?>
            <div class="pro-list-item">
              <div class="pro-list-icon" style="background: #f8fafc; color: #64748b; border: 1px solid #e2e8f0;">
                <i class="fa-regular fa-file-lines"></i>
              </div>
              <div class="flex-grow-1 min-width-0">
                <h6 class="mb-0 fw-bold text-dark"><?= e($s['sale_number']) ?></h6>
                <small class="text-muted fw-medium"><?= human_datetime($s['sale_date']) ?></small>
              </div>
              <div class="text-end ms-3">
                <div class="fw-bolder text-dark fs-6"><?= money((float)$s['total_amount']) ?></div>
                <span class="badge rounded-pill <?= $s['status']==='completed' ? 'text-success bg-success-subtle' : ($s['status']==='credit' ? 'text-warning bg-warning-subtle' : 'text-secondary bg-secondary-subtle') ?>" style="font-size: 0.65rem; letter-spacing: 0.03em;">
                  <?= e(strtoupper($s['status'])) ?>
                </span>
              </div>
            </div>
          <?php endforeach; endif; ?>
        </div>
      </div>
    </div>

    <!-- Low Stock Alerts -->
    <div class="col-lg-5">
      <div class="pro-panel">
        <div class="pro-panel-header">
          <h5>Low Stock Alerts</h5>
          <?php if (count($lowStock) > 0): ?>
            <span class="badge bg-danger rounded-pill px-2 py-1" style="font-size: 0.7rem;">Action Needed</span>
          <?php endif; ?>
        </div>
        <div class="pro-list">
          <?php if (!$lowStock): ?>
            <div class="text-center text-muted py-5">
              <div class="mb-3"><i class="fa-solid fa-shield-check text-success" style="font-size: 3rem; opacity: 0.3;"></i></div>
              <h6 class="fw-bold text-dark mb-1">Inventory Health Good</h6>
              <p class="small mb-0">All products are above minimum levels.</p>
            </div>
          <?php else: foreach ($lowStock as $ls): ?>
            <div class="pro-list-item">
              <div class="pro-list-icon <?= ((float)$ls['quantity'] <= 0) ? 'bg-danger-subtle text-danger' : 'bg-warning-subtle text-warning' ?>">
                <i class="fa-solid fa-box-open"></i>
              </div>
              <div class="flex-grow-1 min-width-0">
                <h6 class="mb-0 fw-bold text-dark text-truncate"><?= e($ls['name']) ?></h6>
                <small class="text-muted fw-medium">Min required: <?= num((float)$ls['min_stock_level']) ?></small>
              </div>
              <div class="text-end ms-3">
                <div class="fw-bolder <?= ((float)$ls['quantity'] <= 0) ? 'text-danger' : 'text-warning' ?> fs-6">
                  <?= num((float)$ls['quantity']) ?> <span class="fs-7 fw-normal"><?= e($ls['unit']) ?></span>
                </div>
                <small class="text-muted" style="font-size: 0.7rem;">left in stock</small>
              </div>
            </div>
          <?php endforeach; endif; ?>
        </div>
      </div>
    </div>

  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>