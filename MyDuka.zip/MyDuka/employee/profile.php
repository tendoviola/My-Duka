<?php
// employee/profile.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_role('employee');

$pdo = db();
$user = current_user();

$branches = $pdo->prepare(
    "SELECT b.name FROM branches b
     JOIN user_branch_assignments uba ON uba.branch_id = b.id
     WHERE uba.user_id = ? ORDER BY b.name"
);
$branches->execute([(int)$user['id']]);
$branches = $branches->fetchAll(PDO::FETCH_COLUMN);

$initials = '';
foreach (array_slice(explode(' ', $user['full_name']), 0, 2) as $part) {
    $initials .= mb_strtoupper(mb_substr($part, 0, 1));
}

$pageTitle = 'My Profile';
$breadcrumbs = ['Dashboard' => APP_URL . '/employee/dashboard.php', 'Profile' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; max-width: 900px; }
  .page-header { margin-bottom: 1.5rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }

  .profile-grid { display: grid; grid-template-columns: 1fr; gap: 1.5rem; }
  @media (min-width: 768px) { .profile-grid { grid-template-columns: 280px 1fr; } }

  /* Left Sidebar Card */
  .profile-card { background: #fff; border: 1px solid #e2e8f0; border-radius: 16px; padding: 1.5rem; text-align: center; height: fit-content; }
  .profile-avatar { width: 80px; height: 80px; border-radius: 50%; background: linear-gradient(135deg, #2563eb, #1d4ed8); color: #fff; font-size: 1.75rem; font-weight: 800; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem; box-shadow: 0 8px 20px rgba(37,99,235,0.25); }
  .profile-name { font-size: 1.1rem; font-weight: 800; color: #0f172a; margin-bottom: 0.15rem; }
  .profile-role { font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: #2563eb; background: #eff6ff; padding: 0.25rem 0.75rem; border-radius: 20px; display: inline-block; margin-bottom: 1rem; }

  /* Right Content Area */
  .info-section { background: #fff; border: 1px solid #e2e8f0; border-radius: 16px; overflow: hidden; margin-bottom: 1.5rem; }
  .info-header { padding: 1rem 1.25rem; border-bottom: 1px solid #e2e8f0; background: #f8fafc; font-weight: 700; font-size: 0.9rem; color: #0f172a; }
  
  .info-row { display: flex; padding: 0.85rem 1.25rem; border-bottom: 1px solid #f1f5f9; font-size: 0.85rem; }
  .info-row:last-child { border-bottom: none; }
  .info-label { width: 140px; font-weight: 600; color: #64748b; flex-shrink: 0; }
  .info-value { font-weight: 600; color: #0f172a; flex: 1; }
  
  .security-panel { background: #fff; border: 1px solid #e2e8f0; border-radius: 16px; padding: 1.25rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem; }
  .security-text h5 { font-size: 0.95rem; font-weight: 700; color: #0f172a; margin-bottom: 0.25rem; }
  .security-text p { font-size: 0.8rem; color: #64748b; margin: 0; max-width: 400px; }
  
  .btn-primary { background: #0f172a; border-color: #0f172a; font-weight: 600; font-size: 0.85rem; padding: 0.5rem 1rem; border-radius: 8px; }
  .btn-primary:hover { background: #1e293b; border-color: #1e293b; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <h1>My Profile</h1>
  </div>

  <div class="profile-grid">
    <!-- Left Card -->
    <div class="profile-card">
      <div class="profile-avatar"><?= e($initials) ?></div>
      <div class="profile-name"><?= e($user['full_name']) ?></div>
      <div class="profile-role"><?= e($user['role_name']) ?></div>
      
      <div class="text-start mt-4 pt-3 border-top" style="font-size: 0.8rem;">
        <div class="d-flex justify-content-between mb-2">
          <span class="text-muted fw-semibold">Business</span>
          <span class="fw-bold text-dark text-truncate ms-2" style="max-width: 140px;"><?= e($user['business_name'] ?? '—') ?></span>
        </div>
        <div class="d-flex justify-content-between">
          <span class="text-muted fw-semibold">Last Login</span>
          <span class="fw-bold text-dark"><?= $user['last_login_at'] ? human_date($user['last_login_at']) : '—' ?></span>
        </div>
      </div>
    </div>

    <!-- Right Content -->
    <div>
      <div class="info-section">
        <div class="info-header"><i class="fa-regular fa-address-card me-2"></i>Contact Details</div>
        <div class="info-row">
          <div class="info-label">Full Name</div>
          <div class="info-value"><?= e($user['full_name']) ?></div>
        </div>
        <div class="info-row">
          <div class="info-label">Email</div>
          <div class="info-value"><?= e($user['email']) ?></div>
        </div>
        <div class="info-row">
          <div class="info-label">Phone</div>
          <div class="info-value"><?= e($user['phone'] ?: 'Not provided') ?></div>
        </div>
      </div>

      <div class="info-section">
        <div class="info-header"><i class="fa-solid fa-store me-2"></i>Assigned Branches</div>
        <?php if (!$branches): ?>
          <div class="info-row"><div class="info-value text-muted">No branches assigned.</div></div>
        <?php else: foreach ($branches as $b): ?>
          <div class="info-row">
            <div class="info-value d-flex align-items-center">
              <i class="fa-solid fa-check-circle text-success me-2"></i><?= e($b) ?>
            </div>
          </div>
        <?php endforeach; endif; ?>
      </div>

      <div class="security-panel">
        <div class="security-text">
          <h5>Account Security</h5>
          <p>Ensure your account stays secure by using a strong, unique password that you don't use elsewhere.</p>
        </div>
        <a href="<?= e(APP_URL) ?>/password_change.php" class="btn btn-primary">
          <i class="fa-solid fa-key me-1"></i>Change Password
        </a>
      </div>
    </div>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>