<?php
// employee/pos.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/stock.php';
require_login();
require_permission('sale.create');

$pdo        = db();
$businessId = user_business_id();
$userId     = (int)current_user()['id'];
$branchIds  = user_branch_ids();

if (!$branchIds) {
    $pageTitle = 'Point of Sale';
    require __DIR__ . '/../includes/header.php';
    echo '<div class="alert alert-warning">You are not assigned to any branch. Contact your employer.</div>';
    require __DIR__ . '/../includes/footer.php';
    exit;
}

$activeBranch = (int)($_SESSION['active_branch_id'] ?? $branchIds[0]);
if (!in_array($activeBranch, $branchIds, true)) $activeBranch = $branchIds[0];
$_SESSION['active_branch_id'] = $activeBranch;

$taxRate = (float)db_business_setting($businessId, 'default_tax_rate', 0);

/* ------------------------------------------------------------------
 |  AJAX: product search
 * ------------------------------------------------------------------ */
if (($_GET['api'] ?? '') === 'search') {
    header('Content-Type: application/json');
    $q = trim((string)($_GET['q'] ?? ''));
    
    $sql = "SELECT p.id, p.name, p.sku, p.barcode, p.unit, p.selling_price,
                   COALESCE(i.quantity, 0) AS stock, 
                   c.id AS category_id, c.name AS category_name
            FROM products p
            LEFT JOIN inventory i ON i.product_id = p.id AND i.branch_id = ?
            LEFT JOIN categories c ON c.id = p.category_id
            WHERE p.business_id = ? AND p.status = 'active'";
            
    $params = [$activeBranch, $businessId];
    if ($q !== '') {
        $sql .= " AND (p.name LIKE ? OR p.sku LIKE ? OR p.barcode = ?)";
        $params[] = "%{$q}%";
        $params[] = "%{$q}%";
        $params[] = $q;
    }
    $sql .= " ORDER BY p.name LIMIT 80";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    echo json_encode(['items' => $stmt->fetchAll()]);
    exit;
}

/* ------------------------------------------------------------------
 |  POST: finalize sale
 * ------------------------------------------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && post('action') === 'checkout') {
    verify_csrf();

    $cartRaw   = $_POST['cart'] ?? '[]';
    $cart      = json_decode($cartRaw, true);
    $discount  = max(0, (float)post('discount', '0'));
    $payMethod = post('payment_method', 'cash');
    $payRef    = post('payment_reference');
    $customerId = post_int('customer_id') ?: null;

    $validMethods = ['cash', 'mobile_money', 'bank', 'credit'];
    if (!in_array($payMethod, $validMethods, true)) {
        flash('danger', 'Invalid payment method.');
        redirect('pos.php');
    }

    if (!is_array($cart) || !$cart) {
        flash('danger', 'Cart is empty.');
        redirect('pos.php');
    }

    try {
        $pdo->beginTransaction();
        $ids = [];
        foreach ($cart as $line) {
            $pid = (int)($line['product_id'] ?? 0);
            if ($pid > 0) $ids[] = $pid;
        }
        $ids = array_values(array_unique($ids));
        if (!$ids) throw new RuntimeException('No valid products in cart.');

        $in = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $pdo->prepare(
            "SELECT p.id, p.name, p.unit, p.selling_price, p.status,
                    COALESCE(i.quantity, 0) AS stock,
                    COALESCE(i.weighted_avg_cost, 0) AS avg_cost
             FROM products p
             LEFT JOIN inventory i ON i.product_id = p.id AND i.branch_id = ?
             WHERE p.business_id = ? AND p.id IN ({$in})
             FOR UPDATE"
        );
        $stmt->execute(array_merge([$activeBranch, $businessId], $ids));
        $products = [];
        foreach ($stmt->fetchAll() as $p) $products[(int)$p['id']] = $p;

        $subtotal = 0.0;
        $lineItems = [];
        foreach ($cart as $line) {
            $pid = (int)($line['product_id'] ?? 0);
            $qty = (float)($line['quantity'] ?? 0);
            if (!isset($products[$pid])) throw new RuntimeException('Unknown product in cart.');
            if ($products[$pid]['status'] !== 'active') throw new RuntimeException("Product unavailable: {$products[$pid]['name']}");
            if ($qty <= 0) continue;

            $prod      = $products[$pid];
            $unitPrice = (float)$prod['selling_price'];
            $unitCost  = (float)$prod['avg_cost'];
            $lineTotal = round($unitPrice * $qty, 2);
            $lineCost  = round($unitCost  * $qty, 2);
            $subtotal += $lineTotal;

            $lineItems[] = [
                'product_id'   => $pid,
                'product_name' => $prod['name'],
                'quantity'     => $qty,
                'unit_price'   => $unitPrice,
                'unit_cost'    => $unitCost,
                'line_total'   => $lineTotal,
                'line_cost'    => $lineCost,
            ];
        }
        if (!$lineItems) throw new RuntimeException('Cart is empty.');

        $discount    = min($discount, $subtotal);
        $taxable     = $subtotal - $discount;
        $taxAmount   = round($taxable * ($taxRate / 100), 2);
        $totalAmount = round($taxable + $taxAmount, 2);
        $costOfGoods = round(array_sum(array_column($lineItems, 'line_cost')), 2);
        $grossProfit = round($totalAmount - $taxAmount - $costOfGoods, 2);

        $saleNumber = generate_number('SALE', 'sales', 'sale_number', $businessId);
        $saleStatus = $payMethod === 'credit' ? 'credit' : 'completed';
        $paidAmount = $payMethod === 'credit' ? 0.0 : $totalAmount;

        $pdo->prepare(
            "INSERT INTO sales
                (business_id, branch_id, customer_id, sale_number, sale_date,
                 subtotal, discount, tax, total_amount, paid_amount,
                 cost_of_goods, gross_profit, status, user_id)
             VALUES (?, ?, ?, ?, NOW(), ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        )->execute([
            $businessId, $activeBranch, $customerId, $saleNumber,
            $subtotal, $discount, $taxAmount, $totalAmount, $paidAmount,
            $costOfGoods, $grossProfit, $saleStatus, $userId,
        ]);
        $saleId = (int)$pdo->lastInsertId();

        $itemIns = $pdo->prepare(
            "INSERT INTO sale_items
                (sale_id, product_id, product_name, quantity, unit_price, unit_cost, line_total, line_cost)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        );
        foreach ($lineItems as $it) {
            $itemIns->execute([
                $saleId, $it['product_id'], $it['product_name'],
                $it['quantity'], $it['unit_price'], $it['unit_cost'],
                $it['line_total'], $it['line_cost'],
            ]);

            apply_stock_change(
                $pdo, $businessId, $activeBranch, (int)$it['product_id'],
                -(float)$it['quantity'], 'sale', (float)$it['unit_cost'],
                'sales', $saleId, 'Sale ' . $saleNumber, $userId
            );
        }

        $pdo->prepare(
            "INSERT INTO sale_payments (sale_id, amount, method, reference)
             VALUES (?, ?, ?, ?)"
        )->execute([$saleId, $paidAmount, $payMethod, $payRef ?: null]);

        audit_log('sale.create', 'sales', $saleId, [
            'sale_number' => $saleNumber,
            'total'       => $totalAmount,
            'items'       => count($lineItems),
            'method'      => $payMethod,
        ], $activeBranch);

        $pdo->commit();
        flash('success', "Sale {$saleNumber} completed.");
        redirect(APP_URL . '/receipt.php?id=' . $saleId . '&print=1');
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('danger', APP_ENV === 'development' ? $ex->getMessage() : 'Sale failed. Please try again.');
        redirect('pos.php');
    }
}

/* ------------------------------------------------------------------
 |  Load POS data
 * ------------------------------------------------------------------ */
$categories = $pdo->prepare("SELECT id, name FROM categories WHERE business_id = ? AND status='active' ORDER BY name");
$categories->execute([$businessId]);
$categories = $categories->fetchAll();

$customers = $pdo->prepare("SELECT id, name, phone FROM customers WHERE business_id = ? ORDER BY name LIMIT 200");
$customers->execute([$businessId]);
$customers = $customers->fetchAll();

$allBranches = $pdo->prepare("SELECT id, name FROM branches WHERE business_id = ? AND id IN (" . implode(',', array_map('intval', $branchIds)) . ") AND status='active'");
$allBranches->execute([$businessId]);
$allBranches = $allBranches->fetchAll();

$activeBranchName = '';
foreach ($allBranches as $b) if ((int)$b['id'] === $activeBranch) $activeBranchName = $b['name'];

$pageTitle = 'Point of Sale';
$breadcrumbs = ['Dashboard' => APP_URL . '/employee/dashboard.php', 'POS' => null];
$pageScripts = ['assets/js/pos.js'];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

  /* FULL SCREEN APP LAYOUT */
  body { background-color: #f4f6fb; }
  .rp-content { padding: 0 !important; display: flex; flex-direction: column; height: calc(100vh - 64px); overflow: hidden; }
  
  .pro-pos-app {
    font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
    display: flex;
    height: 100%;
    width: 100%;
    background: #fff;
  }

  /* LEFT PANEL - PRODUCTS */
  .pos-left-panel {
    flex: 1;
    display: flex;
    flex-direction: column;
    border-right: 1px solid #e2e8f0;
    min-width: 0; 
    background: #f8fafc;
  }

  .pos-top-bar {
    padding: 1rem 1.25rem;
    background: #fff;
    border-bottom: 1px solid #e2e8f0;
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
  }

  .pos-search-box {
    position: relative;
    width: 100%;
    max-width: 400px;
  }
  
  .pos-search-box i {
    position: absolute;
    left: 0.85rem; top: 50%; transform: translateY(-50%);
    color: #94a3b8; font-size: 0.95rem;
  }
  
  .pos-search-box input {
    width: 100%;
    padding: 0.6rem 1rem 0.6rem 2.25rem;
    border-radius: 8px;
    border: 1px solid #cbd5e1;
    background: #f8fafc;
    font-weight: 500;
    font-size: 0.9rem;
    color: #0f172a;
    transition: all 0.2s;
  }
  
  .pos-search-box input:focus {
    background: #fff;
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
    outline: none;
  }

  .pos-tabs {
    display: flex;
    gap: 0.4rem;
    overflow-x: auto;
    padding-bottom: 0.15rem;
  }
  
  .pos-tabs::-webkit-scrollbar { display: none; }
  
  .pos-tab {
    padding: 0.35rem 0.8rem;
    border-radius: 6px;
    font-size: 0.75rem;
    font-weight: 700;
    white-space: nowrap;
    cursor: pointer;
    border: 1px solid #e2e8f0;
    background: #fff;
    color: #475569;
    transition: all 0.15s;
  }
  
  .pos-tab:hover { background: #f1f5f9; }
  .pos-tab.active { background: #0f172a; border-color: #0f172a; color: #fff; }

  /* PRODUCT GRID */
  .pos-products-grid {
    padding: 1.25rem;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 0.85rem;
    overflow-y: auto;
    flex: 1;
    align-content: start;
  }

  .pos-card {
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 0.85rem;
    cursor: pointer;
    transition: all 0.15s ease;
    text-align: left;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    user-select: none;
  }
  
  .pos-card:hover:not(.out) {
    border-color: #3b82f6;
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.08);
    transform: translateY(-2px);
  }
  
  .pos-card.out { opacity: 0.5; cursor: not-allowed; background: #f8fafc; }
  
  .pos-card-title { font-weight: 700; font-size: 0.85rem; color: #0f172a; margin-bottom: 0.2rem; line-height: 1.3; }
  .pos-card-sku { font-size: 0.65rem; font-weight: 600; color: #94a3b8; margin-bottom: 0.5rem; }
  .pos-card-price { font-weight: 800; font-size: 0.95rem; color: #2563eb; }
  .pos-card-stock { font-size: 0.68rem; font-weight: 600; color: #64748b; margin-top: 0.4rem; display: flex; justify-content: space-between; }

  /* RIGHT PANEL - CART */
  .pos-right-panel {
    width: 360px;
    display: flex;
    flex-direction: column;
    background: #fff;
    flex-shrink: 0;
    position: relative;
  }

  .pos-cart-header {
    padding: 1rem 1.25rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #e2e8f0;
    background: #f8fafc;
  }

  .pos-cart-header h4 { font-weight: 800; margin: 0; font-size: 1.1rem; color: #0f172a; }
  
  /* RECEIPT LIKE LIST */
  .pos-cart-list {
    flex: 1;
    overflow-y: auto;
    padding: 0.75rem 1.25rem;
    background: #fff;
  }
  
  .pos-cart-list::-webkit-scrollbar { width: 4px; }
  .pos-cart-list::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }

  .cart-receipt-item {
    display: flex;
    align-items: center;
    padding: 0.75rem 0;
    border-bottom: 1px dashed #e2e8f0;
    gap: 0.75rem;
  }

  .cart-item-info { flex: 1; min-width: 0; }
  .cart-item-name { font-weight: 700; font-size: 0.85rem; color: #0f172a; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .cart-item-meta { font-size: 0.7rem; color: #64748b; font-weight: 500; }
  
  .cart-qty-controls {
    display: flex;
    align-items: center;
    background: #f1f5f9;
    border-radius: 6px;
    overflow: hidden;
    border: 1px solid #e2e8f0;
    height: 28px;
  }
  
  .cart-qty-controls button {
    background: transparent;
    border: none;
    width: 26px;
    height: 100%;
    color: #475569;
    font-weight: bold;
    cursor: pointer;
    transition: background 0.1s;
  }
  
  .cart-qty-controls button:hover { background: #e2e8f0; color: #0f172a; }
  .cart-qty-controls input {
    width: 30px;
    border: none;
    background: transparent;
    text-align: center;
    font-weight: 700;
    font-size: 0.8rem;
    color: #0f172a;
    padding: 0;
  }
  
  .cart-item-price { font-weight: 800; font-size: 0.9rem; color: #0f172a; text-align: right; min-width: 70px; }
  .cart-item-remove { color: #ef4444; background: none; border: none; padding: 0; margin-left: 0.25rem; font-size: 1rem; cursor: pointer; opacity: 0.5; transition: opacity 0.2s; }
  .cart-item-remove:hover { opacity: 1; }

  /* TOTALS & CHECKOUT */
  .pos-checkout-area {
    background: #f8fafc;
    border-top: 1px solid #e2e8f0;
    padding: 1rem 1.25rem;
    box-shadow: 0 -4px 15px rgba(0,0,0,0.02);
  }
  
  .total-row { display: flex; justify-content: space-between; font-size: 0.85rem; font-weight: 600; color: #475569; margin-bottom: 0.4rem; }
  .grand-total { display: flex; justify-content: space-between; align-items: center; border-top: 2px dashed #cbd5e1; padding-top: 0.75rem; margin-top: 0.4rem; margin-bottom: 0.75rem; }
  .grand-total-label { font-size: 1rem; font-weight: 800; color: #0f172a; }
  .grand-total-value { font-size: 1.4rem; font-weight: 900; color: #2563eb; letter-spacing: -0.03em; line-height: 1; }

  .discount-input {
    width: 80px;
    text-align: right;
    border: 1px solid #cbd5e1;
    border-radius: 4px;
    padding: 0.15rem 0.4rem;
    font-size: 0.8rem;
    font-weight: 700;
  }

  .pay-methods-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.4rem; margin-bottom: 0.85rem; }
  
  .pay-btn {
    border: 1px solid #cbd5e1;
    background: #fff;
    border-radius: 6px;
    padding: 0.4rem 0;
    font-size: 0.7rem;
    font-weight: 700;
    color: #475569;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.2rem;
    transition: all 0.15s;
  }
  
  .pay-btn i { font-size: 0.95rem; }
  .pay-btn:hover { background: #f1f5f9; border-color: #94a3b8; }
  .pay-btn.active { background: #eff6ff; border-color: #3b82f6; color: #1d4ed8; }
  .pay-btn.active i { color: #2563eb; }

  .checkout-btn {
    width: 100%;
    background: #2563eb;
    color: #fff;
    border: none;
    border-radius: 8px;
    padding: 0.75rem;
    font-size: 0.95rem;
    font-weight: 800;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 0.5rem;
    transition: all 0.2s;
    box-shadow: 0 4px 12px rgba(37, 99, 235, 0.25);
  }
  
  .checkout-btn:hover:not(:disabled) { background: #1d4ed8; transform: translateY(-1px); box-shadow: 0 6px 16px rgba(37, 99, 235, 0.35); }
  .checkout-btn:disabled { background: #94a3b8; box-shadow: none; cursor: not-allowed; }

  /* Empty State */
  .empty-cart-state {
    height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; color: #94a3b8;
  }
  .empty-cart-state i { font-size: 2.5rem; margin-bottom: 0.75rem; opacity: 0.3; }
</style>

<div class="pro-pos-app">
  
  <!-- LEFT: PRODUCTS -->
  <div class="pos-left-panel">
    <div class="pos-top-bar">
      <div class="d-flex align-items-center justify-content-between gap-3">
        <div class="pos-search-box">
          <i class="fa-solid fa-magnifying-glass"></i>
          <input type="text" id="posSearch" placeholder="Scan barcode or search product... (F2)" autocomplete="off">
        </div>
        <?php if (count($allBranches) > 1): ?>
          <form method="get" class="m-0">
            <select name="branch" class="form-select fw-bold border-secondary text-dark" style="width: auto; min-width: 130px; border-radius: 8px; background:#f8fafc; font-size: 0.85rem; padding: 0.4rem 2rem 0.4rem 0.75rem;" onchange="this.form.submit()">
              <?php foreach ($allBranches as $b): ?>
                <option value="<?= (int)$b['id'] ?>" <?= $activeBranch === (int)$b['id'] ? 'selected' : '' ?>>
                  <?= e($b['name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </form>
        <?php endif; ?>
      </div>
      
      <div class="pos-tabs" id="posCategories">
        <button type="button" class="pos-tab active" data-cat="0">All Items</button>
        <?php foreach ($categories as $c): ?>
          <button type="button" class="pos-tab" data-cat="<?= (int)$c['id'] ?>">
            <?= e($c['name']) ?>
          </button>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="pos-products-grid" id="posGrid">
      <!-- JS Injects Cards Here -->
    </div>
  </div>

  <!-- RIGHT: CART -->
  <div class="pos-right-panel">
    <form method="post" id="posForm" class="d-flex flex-column h-100">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="checkout">
      <input type="hidden" name="cart" id="posCartJson">
      <input type="hidden" name="payment_method" id="posPayMethod" value="cash">

      <div class="pos-cart-header">
        <h4>Current Order</h4>
        <button type="button" class="btn btn-sm btn-light text-danger fw-bold border" id="posClear" style="border-radius: 6px; font-size: 0.75rem; padding: 0.25rem 0.5rem;">Clear</button>
      </div>

      <div class="pos-cart-list" id="posCart">
        <!-- JS Injects Cart Receipt Here -->
      </div>

      <div class="pos-checkout-area">
        <div class="total-row">
          <span>Subtotal</span>
          <span id="posSubtotal">UGX 0</span>
        </div>
        <div class="total-row align-items-center mb-0">
          <span>Discount</span>
          <input type="number" min="0" step="0.01" name="discount" id="posDiscount" class="discount-input" value="0">
        </div>
        <?php if ($taxRate > 0): ?>
          <div class="total-row mt-1">
            <span>Tax (<?= num($taxRate, 2) ?>%)</span>
            <span id="posTax">UGX 0</span>
          </div>
        <?php endif; ?>

        <div class="grand-total">
          <span class="grand-total-label">Total</span>
          <span class="grand-total-value" id="posTotal">UGX 0</span>
        </div>

        <div class="pay-methods-grid" id="posPayMethods">
          <button type="button" class="pay-btn active" data-method="cash">
            <i class="fa-solid fa-money-bill"></i> Cash
          </button>
          <button type="button" class="pay-btn" data-method="mobile_money">
            <i class="fa-solid fa-mobile-screen"></i> MoMo
          </button>
          <button type="button" class="pay-btn" data-method="bank">
            <i class="fa-solid fa-building-columns"></i> Bank
          </button>
          <button type="button" class="pay-btn" data-method="credit" <?= !has_permission('sale.create') ? 'disabled' : '' ?>>
            <i class="fa-solid fa-clock"></i> Credit
          </button>
        </div>

        <div class="row g-2 mb-2">
          <div class="col-6">
            <select name="customer_id" class="form-select form-select-sm fw-bold text-dark border-secondary" style="font-size: 0.75rem;">
              <option value="0">Walk-in Customer</option>
              <?php foreach ($customers as $c): ?>
                <option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-6">
            <input type="text" name="payment_reference" class="form-control form-control-sm fw-bold border-secondary" style="font-size: 0.75rem;" placeholder="Ref / Note">
          </div>
        </div>

        <button type="submit" class="checkout-btn" id="posCheckoutBtn" disabled>
          <i class="fa-solid fa-check-circle"></i> Complete Sale (F4)
        </button>
      </div>
    </form>
  </div>
</div>

<script>
  window.__RP_POS__ = {
    taxRate: <?= json_encode($taxRate) ?>,
    branchId: <?= (int)$activeBranch ?>,
    appUrl: <?= json_encode(APP_URL) ?>,
    searchUrl: <?= json_encode(APP_URL . '/employee/pos.php?api=search') ?>
  };
</script>

<?php require __DIR__ . '/../includes/footer.php'; ?>