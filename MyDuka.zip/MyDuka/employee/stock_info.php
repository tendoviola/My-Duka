<?php
// employee/stock_info.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
require_permission('inventory.view');

$pdo        = db();
$businessId = user_business_id();
$branchIds  = user_branch_ids();
if (!$branchIds) {
    $pageTitle = 'Stock';
    require __DIR__ . '/../includes/header.php';
    echo '<div class="alert alert-warning">You are not assigned to any branch.</div>';
    require __DIR__ . '/../includes/footer.php';
    exit;
}

$activeBranch = (int)($_SESSION['active_branch_id'] ?? $branchIds[0]);
if (!in_array($activeBranch, $branchIds, true)) $activeBranch = $branchIds[0];

$search = get('q');
$where  = "i.business_id = ? AND i.branch_id = ?";
$params = [$businessId, $activeBranch];
if ($search !== '') {
    $where .= " AND (p.name LIKE ? OR p.sku LIKE ?)";
    $like = "%{$search}%";
    array_push($params, $like, $like);
}

$stmt = $pdo->prepare(
    "SELECT i.quantity, p.name, p.sku, p.unit, p.min_stock_level
     FROM inventory i JOIN products p ON p.id = i.product_id
     WHERE {$where}
     ORDER BY p.name LIMIT 300"
);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$allBranches = $pdo->prepare(
    "SELECT id, name FROM branches WHERE id IN (" . implode(',', array_map('intval', $branchIds)) . ") AND status='active'"
);
$allBranches->execute();
$allBranches = $allBranches->fetchAll();

$pageTitle = 'Stock Info';
$breadcrumbs = ['Dashboard' => APP_URL . '/employee/dashboard.php', 'Stock' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; max-width: 900px; }
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }
  
  .controls-wrap { display: flex; gap: 0.5rem; flex-wrap: wrap; }
  
  .search-input-wrap { position: relative; width: 220px; }
  .search-input-wrap i { position: absolute; left: 0.85rem; top: 50%; transform: translateY(-50%); color: #94a3b8; font-size: 0.85rem; }
  .search-input-wrap input { width: 100%; padding: 0.5rem 1rem 0.5rem 2.25rem; border-radius: 8px; border: 1px solid #cbd5e1; background: #fff; font-size: 0.8rem; font-weight: 500; transition: all 0.2s; }
  .search-input-wrap input:focus { outline: none; border-color: #3b82f6; box-shadow: 0 0 0 3px rgba(59,130,246,0.1); }
  
  .branch-select { padding: 0.5rem 2rem 0.5rem 1rem; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 0.8rem; font-weight: 600; color: #0f172a; background: #fff; }

  .stock-panel { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
  
  .stock-row { display: flex; align-items: center; padding: 1rem 1.25rem; border-bottom: 1px solid #f1f5f9; transition: background 0.15s; }
  .stock-row:last-child { border-bottom: none; }
  .stock-row:hover { background: #f8fafc; }
  
  .stock-icon { width: 40px; height: 40px; border-radius: 10px; background: #f1f5f9; color: #64748b; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; margin-right: 1rem; }
  
  .stock-info { flex: 1; min-width: 0; }
  .stock-name { font-weight: 700; font-size: 0.9rem; color: #0f172a; margin-bottom: 0.1rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .stock-meta { font-size: 0.75rem; font-weight: 500; color: #64748b; }
  
  .stock-values { text-align: right; }
  .stock-qty { font-weight: 800; font-size: 0.95rem; margin-bottom: 0.15rem; }
  .stock-min { font-size: 0.7rem; font-weight: 600; color: #94a3b8; }
  
  .val-out { color: #dc2626; }
  .val-low { color: #d97706; }
  .val-good { color: #16a34a; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>Stock Information</h1>
      <p>Read-only inventory levels for your branch</p>
    </div>
    
    <div class="controls-wrap">
      <?php if (count($allBranches) > 1): ?>
        <form method="get" class="m-0">
          <select name="branch" class="branch-select" onchange="this.form.submit()">
            <?php foreach ($allBranches as $b): ?>
              <option value="<?= (int)$b['id'] ?>" <?= $activeBranch === (int)$b['id'] ? 'selected' : '' ?>>
                <?= e($b['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </form>
      <?php endif; ?>
      
      <form method="get" class="search-input-wrap m-0">
        <?php if (isset($_GET['branch'])): ?>
          <input type="hidden" name="branch" value="<?= (int)$_GET['branch'] ?>">
        <?php endif; ?>
        <i class="fa-solid fa-magnifying-glass"></i>
        <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search product...">
      </form>
    </div>
  </div>

  <div class="stock-panel">
    <?php if (!$rows): ?>
      <div class="text-center py-5">
        <i class="fa-solid fa-boxes-stacked text-muted mb-3" style="font-size: 3rem; opacity: 0.2;"></i>
        <h5 class="fw-bold text-dark">No stock records</h5>
        <p class="text-muted small">There are no items matching your criteria.</p>
      </div>
    <?php else: foreach ($rows as $r): ?>
      <?php
        $q = (float)$r['quantity'];
        $min = (float)$r['min_stock_level'];
        $valClass = $q <= 0 ? 'val-out' : ($q <= $min ? 'val-low' : 'val-good');
      ?>
      <div class="stock-row">
        <div class="stock-icon"><i class="fa-solid fa-cube"></i></div>
        <div class="stock-info">
          <div class="stock-name"><?= e($r['name']) ?></div>
          <div class="stock-meta">SKU: <?= e($r['sku']) ?></div>
        </div>
        <div class="stock-values">
          <div class="stock-qty <?= $valClass ?>">
            <?= num($q, 2) ?> <span style="font-size: 0.75rem; font-weight: 600;"><?= e($r['unit']) ?></span>
          </div>
          <div class="stock-min">Min: <?= num($min, 2) ?></div>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>