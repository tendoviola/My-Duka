<?php
// employee/products.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/uploads.php';
require_role('employee');
require_permission('product.view');

$pdo        = db();
$businessId = user_business_id();

$search = get('q');
$where  = "p.business_id = ? AND p.status = 'active'";
$params = [$businessId];
if ($search !== '') {
    $where .= " AND (p.name LIKE ? OR p.sku LIKE ? OR p.barcode LIKE ?)";
    $like = "%{$search}%";
    array_push($params, $like, $like, $like);
}

$stmt = $pdo->prepare(
    "SELECT p.id, p.name, p.sku, p.barcode, p.unit, p.image_path,
            c.name AS category_name,
            COALESCE((
              SELECT SUM(inv.quantity)
              FROM inventory inv
              WHERE inv.product_id = p.id AND inv.branch_id IN (
                SELECT branch_id FROM user_branch_assignments WHERE user_id = ?
              )
            ), 0) AS my_stock
     FROM products p
     LEFT JOIN categories c ON c.id = p.category_id
     WHERE {$where}
     ORDER BY p.name
     LIMIT 200"
);
$stmt->execute(array_merge([(int)current_user()['id']], $params));
$products = $stmt->fetchAll();

$pageTitle = 'Products';
$breadcrumbs = ['Dashboard' => APP_URL . '/employee/dashboard.php', 'Products' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; }
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }
  
  .search-input-wrap { position: relative; width: 100%; max-width: 320px; }
  .search-input-wrap i { position: absolute; left: 1rem; top: 50%; transform: translateY(-50%); color: #94a3b8; }
  .search-input-wrap input { width: 100%; padding: 0.6rem 1rem 0.6rem 2.5rem; border-radius: 10px; border: 1px solid #cbd5e1; background: #fff; font-size: 0.85rem; font-weight: 500; transition: all 0.2s; }
  .search-input-wrap input:focus { outline: none; border-color: #3b82f6; box-shadow: 0 0 0 3px rgba(59,130,246,0.1); }

  .product-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 1rem; }
  
  .product-card {
    background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; padding: 1rem;
    display: flex; flex-direction: column; transition: all 0.2s ease;
  }
  .product-card:hover { box-shadow: 0 8px 20px -8px rgba(0,0,0,0.08); border-color: #cbd5e1; transform: translateY(-2px); }
  
  .product-img-wrap { width: 100%; height: 140px; background: #f8fafc; border-radius: 10px; overflow: hidden; margin-bottom: 1rem; display: flex; align-items: center; justify-content: center; }
  .product-img-wrap img { width: 100%; height: 100%; object-fit: cover; }
  .product-img-wrap i { font-size: 2.5rem; color: #cbd5e1; }
  
  .product-title { font-weight: 700; font-size: 0.95rem; color: #0f172a; margin-bottom: 0.15rem; line-height: 1.2; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .product-sku { font-size: 0.7rem; font-weight: 600; color: #94a3b8; margin-bottom: 0.75rem; }
  
  .product-footer { margin-top: auto; display: flex; justify-content: space-between; align-items: center; border-top: 1px dashed #e2e8f0; padding-top: 0.75rem; }
  .product-price { font-size: 0.75rem; font-weight: 600; color: #64748b; }
  .product-stock { font-size: 0.7rem; font-weight: 700; padding: 0.25rem 0.5rem; border-radius: 6px; }
  
  .badge-out { background: #fee2e2; color: #b91c1c; }
  .badge-low { background: #fef3c7; color: #b45309; }
  .badge-good { background: #dcfce7; color: #15803d; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>Product Catalog</h1>
      <p><?= count($products) ?> items available in your branches</p>
    </div>
    <form method="get" class="search-input-wrap">
      <i class="fa-solid fa-magnifying-glass"></i>
      <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search by name, SKU or barcode...">
    </form>
  </div>

  <?php if (!$products): ?>
    <div class="text-center py-5 bg-white rounded-3 border">
      <i class="fa-solid fa-box-open text-muted mb-3" style="font-size: 3rem; opacity: 0.3;"></i>
      <h5 class="fw-bold text-dark">No products found</h5>
      <p class="text-muted small">Try adjusting your search term.</p>
    </div>
  <?php else: ?>
    <div class="product-grid">
      <?php foreach ($products as $p): ?>
        <?php 
          $stock = (float)$p['my_stock'];
          $badgeClass = $stock <= 0 ? 'badge-out' : ($stock <= 5 ? 'badge-low' : 'badge-good');
          $badgeText = $stock <= 0 ? 'Out of Stock' : num($stock, 0) . ' ' . e($p['unit']);
        ?>
        <div class="product-card">
          <div class="product-img-wrap">
            <?php if ($p['image_path'] && ($u = upload_url($p['image_path']))): ?>
              <img src="<?= e($u) ?>" alt="<?= e($p['name']) ?>">
            <?php else: ?>
              <i class="fa-solid fa-box"></i>
            <?php endif; ?>
          </div>
          <div class="product-title" title="<?= e($p['name']) ?>"><?= e($p['name']) ?></div>
          <div class="product-sku"><?= e($p['sku']) ?></div>
          
          <div class="product-footer">
            <div class="product-price text-truncate" style="max-width: 100px;" title="<?= e($p['category_name'] ?: 'Uncategorized') ?>">
              <?= e($p['category_name'] ?: 'Uncategorized') ?>
            </div>
            <div class="product-stock <?= $badgeClass ?>"><?= $badgeText ?></div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>