<?php
// employee/sales_history.php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_role('employee');

$pdo        = db();
$userId     = (int)current_user()['id'];

$from = get('from', date('Y-m-d', strtotime('-14 days')));
$to   = get('to',   date('Y-m-d'));

$stmt = $pdo->prepare(
    "SELECT s.*, b.name AS branch_name
     FROM sales s JOIN branches b ON b.id = s.branch_id
     WHERE s.user_id = ? AND DATE(s.sale_date) BETWEEN ? AND ?
     ORDER BY s.sale_date DESC LIMIT 200"
);
$stmt->execute([$userId, $from, $to]);
$sales = $stmt->fetchAll();

$totals = $pdo->prepare(
    "SELECT COALESCE(SUM(total_amount),0) AS revenue,
            COUNT(*) AS n,
            COALESCE(SUM(gross_profit),0) AS profit
     FROM sales
     WHERE user_id = ? AND DATE(sale_date) BETWEEN ? AND ? AND status IN ('completed','credit')"
);
$totals->execute([$userId, $from, $to]);
$totals = $totals->fetch();

$pageTitle = 'Sales History';
$breadcrumbs = ['Dashboard' => APP_URL . '/employee/dashboard.php', 'Sales History' => null];
require __DIR__ . '/../includes/header.php';
?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
  .page-wrap { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; max-width: 900px; }
  .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
  .page-header h1 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin: 0; letter-spacing: -0.02em; }
  .page-header p { margin: 0; font-size: 0.85rem; color: #64748b; font-weight: 500; }
  
  .filter-form { display: flex; gap: 0.5rem; background: #fff; padding: 0.35rem; border-radius: 10px; border: 1px solid #cbd5e1; }
  .filter-form input { border: none; border-radius: 6px; padding: 0.35rem 0.5rem; font-size: 0.8rem; font-weight: 500; color: #0f172a; background: transparent; }
  .filter-form input:focus { outline: none; background: #f8fafc; }
  .filter-form button { border: none; background: #0f172a; color: #fff; border-radius: 6px; padding: 0.4rem 0.75rem; font-size: 0.8rem; font-weight: 700; transition: background 0.2s; }
  .filter-form button:hover { background: #1e293b; }

  .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
  .kpi-card { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; padding: 1.25rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
  .kpi-label { font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b; margin-bottom: 0.25rem; }
  .kpi-value { font-size: 1.5rem; font-weight: 800; color: #0f172a; line-height: 1.2; }
  
  .history-panel { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
  
  .history-row { display: flex; align-items: center; padding: 1rem 1.25rem; border-bottom: 1px solid #f1f5f9; transition: background 0.15s; text-decoration: none; color: inherit; }
  .history-row:last-child { border-bottom: none; }
  .history-row:hover { background: #f8fafc; }
  
  .history-icon { width: 40px; height: 40px; border-radius: 10px; background: #f1f5f9; color: #64748b; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; margin-right: 1rem; }
  
  .history-info { flex: 1; min-width: 0; }
  .history-title { font-weight: 700; font-size: 0.9rem; color: #0f172a; margin-bottom: 0.1rem; }
  .history-meta { font-size: 0.75rem; font-weight: 500; color: #64748b; display: flex; align-items: center; gap: 0.5rem; }
  
  .history-values { text-align: right; }
  .history-amount { font-weight: 800; font-size: 0.95rem; color: #0f172a; margin-bottom: 0.15rem; }
  .history-status { font-size: 0.65rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; }
  
  .status-success { color: #16a34a; }
  .status-warning { color: #d97706; }
  .status-danger { color: #dc2626; }
  .status-gray { color: #64748b; }
</style>

<div class="page-wrap">
  <div class="page-header">
    <div>
      <h1>Sales History</h1>
      <p>Your recorded transactions</p>
    </div>
    <form class="filter-form" method="get">
      <input type="date" name="from" value="<?= e($from) ?>">
      <span class="text-muted align-self-center small">to</span>
      <input type="date" name="to" value="<?= e($to) ?>">
      <button type="submit">Filter</button>
    </form>
  </div>

  <div class="kpi-grid">
    <div class="kpi-card">
      <div class="kpi-label">Total Revenue</div>
      <div class="kpi-value"><?= money((float)$totals['revenue']) ?></div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Gross Profit</div>
      <div class="kpi-value text-success"><?= money((float)$totals['profit']) ?></div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Transactions</div>
      <div class="kpi-value"><?= (int)$totals['n'] ?></div>
    </div>
  </div>

  <div class="history-panel">
    <?php if (!$sales): ?>
      <div class="text-center py-5">
        <i class="fa-solid fa-receipt text-muted mb-3" style="font-size: 3rem; opacity: 0.2;"></i>
        <h5 class="fw-bold text-dark">No sales found</h5>
        <p class="text-muted small">There are no sales recorded in this date range.</p>
      </div>
    <?php else: foreach ($sales as $s): ?>
      <?php 
        $statusClass = 'status-gray';
        if ($s['status'] === 'completed') $statusClass = 'status-success';
        elseif ($s['status'] === 'credit') $statusClass = 'status-warning';
        elseif ($s['status'] === 'returned') $statusClass = 'status-danger';
      ?>
      <a href="<?= e(APP_URL) ?>/receipt.php?id=<?= (int)$s['id'] ?>" target="_blank" class="history-row">
        <div class="history-icon"><i class="fa-solid fa-file-invoice-dollar"></i></div>
        <div class="history-info">
          <div class="history-title"><?= e($s['sale_number']) ?></div>
          <div class="history-meta">
            <span><i class="fa-regular fa-clock me-1"></i><?= human_datetime($s['sale_date']) ?></span>
            <span><i class="fa-solid fa-store me-1"></i><?= e($s['branch_name']) ?></span>
          </div>
        </div>
        <div class="history-values">
          <div class="history-amount"><?= money((float)$s['total_amount']) ?></div>
          <div class="history-status <?= $statusClass ?>"><?= e($s['status']) ?></div>
        </div>
      </a>
    <?php endforeach; endif; ?>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>