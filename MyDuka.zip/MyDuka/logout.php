<?php
// logout.php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

logout();
flash('success', 'You have been logged out.');
redirect('login.php');