// assets/js/purchases.js
(function () {
  const form = document.getElementById('purchaseForm');
  if (!form) return;

  const products = window.__RP_PRODUCTS__ || [];
  const container = document.getElementById('lineItems');
  const totalEl = document.getElementById('grandTotal');

  window.addLine = function () {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>
        <select name="item_product[]" class="form-select form-select-sm" required>
          <option value="">— Select product —</option>
          ${products.map(p => `<option value="${p.id}" data-cost="${p.cost}">${p.label}</option>`).join('')}
        </select>
      </td>
      <td><input type="number" step="0.001" min="0.001" name="item_qty[]" class="form-control form-control-sm" required></td>
      <td><input type="number" step="0.01" min="0" name="item_cost[]" class="form-control form-control-sm" required></td>
      <td class="line-total">UGX 0</td>
      <td><button type="button" class="btn btn-sm btn-outline-danger" onclick="this.closest('tr').remove(); window.recalcTotal();">&times;</button></td>
    `;
    container.appendChild(row);
    bindRow(row);
    recalcTotal();
  };

  function bindRow(row) {
    const sel = row.querySelector('select');
    const qty = row.querySelector('input[name="item_qty[]"]');
    const cost = row.querySelector('input[name="item_cost[]"]');
    sel.addEventListener('change', () => {
      const opt = sel.selectedOptions[0];
      if (opt && opt.dataset.cost) {
        cost.value = opt.dataset.cost;
      }
      recalc();
    });
    qty.addEventListener('input', recalc);
    cost.addEventListener('input', recalc);

    function recalc() {
      const t = (parseFloat(qty.value) || 0) * (parseFloat(cost.value) || 0);
      row.querySelector('.line-total').textContent = 'UGX ' + t.toLocaleString(undefined, {minimumFractionDigits: 2});
      window.recalcTotal();
    }
  }

  window.recalcTotal = function () {
    let total = 0;
    document.querySelectorAll('#lineItems tr').forEach(row => {
      const qty = parseFloat(row.querySelector('input[name="item_qty[]"]')?.value) || 0;
      const cost = parseFloat(row.querySelector('input[name="item_cost[]"]')?.value) || 0;
      const t = qty * cost;
      row.querySelector('.line-total').textContent = 'UGX ' + t.toLocaleString(undefined, {minimumFractionDigits: 2});
      total += t;
    });
    totalEl.textContent = 'UGX ' + total.toLocaleString(undefined, {minimumFractionDigits: 2});
  };

  addLine();

  // Pay modal wiring
  const payModal = document.getElementById('payModal');
  if (payModal) {
    payModal.addEventListener('show.bs.modal', ev => {
      const btn = ev.relatedTarget;
      if (!btn) return;
      document.getElementById('payId').value = btn.dataset.id;
      document.getElementById('payNumber').textContent = btn.dataset.number;
      const bal = parseFloat(btn.dataset.balance) || 0;
      document.getElementById('payBalance').textContent = 'UGX ' + bal.toLocaleString(undefined, {minimumFractionDigits: 2});
      const amt = document.getElementById('payAmount');
      amt.value = bal.toFixed(2);
      amt.max = bal.toFixed(2);
    });
  }
})();