// assets/js/main.js
(function () {
  const burger = document.getElementById('rpBurger');
  const sidebar = document.getElementById('rpSidebar');
  if (burger && sidebar) {
    burger.addEventListener('click', function () {
      sidebar.classList.toggle('open');
      document.body.classList.toggle('rp-sidebar-open');
    });
    document.addEventListener('click', function (ev) {
      if (window.innerWidth < 992 &&
          !sidebar.contains(ev.target) &&
          !burger.contains(ev.target)) {
        sidebar.classList.remove('open');
        document.body.classList.remove('rp-sidebar-open');
      }
    });
  }

  // Auto-dismiss alerts
  document.querySelectorAll('.alert-dismissible').forEach(function (el) {
    setTimeout(function () {
      if (el && el.classList.contains('show')) {
        new bootstrap.Alert(el).close();
      }
    }, 6000);
  });
})();