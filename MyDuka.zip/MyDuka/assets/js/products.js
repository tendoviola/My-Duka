// assets/js/products.js
function openProduct(p) {
  const set = (id, val) => { const el = document.getElementById(id); if (el) el.value = val ?? ''; };
  document.getElementById('pId').value         = p ? p.id : 0;
  document.getElementById('pTitle').textContent = p ? 'Edit Product' : 'New Product';
  set('pName',        p ? p.name : '');
  set('pSku',         p ? p.sku : '');
  set('pBarcode',     p ? p.barcode : '');
  set('pCategory',    p ? p.category_id : 0);
  set('pSupplier',    p ? p.supplier_id : 0);
  set('pUnit',        p ? p.unit : 'pcs');
  set('pBuying',      p ? p.buying_price : '');
  set('pSelling',     p ? p.selling_price : '');
  set('pMinStock',    p ? p.min_stock_level : 0);
  set('pDescription', p ? p.description : '');
  new bootstrap.Modal(document.getElementById('productModal')).show();
}