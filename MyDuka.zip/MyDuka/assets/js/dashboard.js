// assets/js/dashboard.js
(function () {
  if (!window.Chart) return;

  // Shared Font
  Chart.defaults.font.family = "'Plus Jakarta Sans', system-ui, sans-serif";
  Chart.defaults.color = '#64748b';
  
  // --- TREND CHART ---
  const trendEl = document.getElementById('salesTrendChart');
  if (trendEl && window.__RP_TREND__) {
    const t = window.__RP_TREND__;
    const ctx = trendEl.getContext('2d');
    
    // Create Gradients
    const gradientRevenue = ctx.createLinearGradient(0, 0, 0, 300);
    gradientRevenue.addColorStop(0, 'rgba(37, 99, 235, 0.2)');
    gradientRevenue.addColorStop(1, 'rgba(37, 99, 235, 0)');

    const gradientProfit = ctx.createLinearGradient(0, 0, 0, 300);
    gradientProfit.addColorStop(0, 'rgba(16, 185, 129, 0.2)');
    gradientProfit.addColorStop(1, 'rgba(16, 185, 129, 0)');

    new Chart(trendEl, {
      type: 'line',
      data: {
        labels: t.labels,
        datasets: [
          {
            label: 'Revenue',
            data: t.revenue,
            borderColor: '#2563eb',
            backgroundColor: gradientRevenue,
            fill: true,
            tension: 0.4,
            borderWidth: 3,
            pointRadius: 0,
            pointHoverRadius: 6,
            pointBackgroundColor: '#fff',
            pointBorderColor: '#2563eb',
            pointBorderWidth: 2
          },
          {
            label: 'Gross Profit',
            data: t.profit,
            borderColor: '#10b981',
            backgroundColor: gradientProfit,
            fill: true,
            tension: 0.4,
            borderWidth: 3,
            pointRadius: 0,
            pointHoverRadius: 6,
            pointBackgroundColor: '#fff',
            pointBorderColor: '#10b981',
            pointBorderWidth: 2
          }
        ]
      },
      options: {
        responsive: true, 
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: { 
          legend: { 
            position: 'top', 
            align: 'end',
            labels: { usePointStyle: true, boxWidth: 8, font: { size: 12, weight: 600 }, padding: 20 } 
          },
          tooltip: {
            backgroundColor: '#0f172a',
            padding: 12,
            cornerRadius: 8,
            titleFont: { size: 13, weight: 700 },
            bodyFont: { size: 13, weight: 500 },
            displayColors: true,
            boxPadding: 4
          }
        },
        scales: {
          y: { 
            beginAtZero: true, 
            ticks: { 
              callback: v => 'UGX ' + Number(v).toLocaleString(),
              font: { size: 11, weight: 500 },
              padding: 10
            },
            border: { display: false },
            grid: { color: '#f1f5f9', drawTicks: false }
          },
          x: { 
            grid: { display: false },
            ticks: { font: { size: 11, weight: 500 }, padding: 10 },
            border: { display: false }
          }
        }
      }
    });
  }

  // --- BRANCH DOUGHNUT CHART ---
  const branchEl = document.getElementById('branchChart');
  if (branchEl && window.__RP_BRANCH__) {
    const b = window.__RP_BRANCH__;
    new Chart(branchEl, {
      type: 'doughnut',
      data: {
        labels: b.labels,
        datasets: [{
          data: b.revenue,
          backgroundColor: ['#2563eb', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444', '#0ea5e9'],
          borderWidth: 4,
          borderColor: '#ffffff',
          hoverOffset: 6
        }]
      },
      options: {
        responsive: true, 
        maintainAspectRatio: false,
        cutout: '75%',
        plugins: { 
          legend: { 
            position: 'bottom', 
            labels: { usePointStyle: true, boxWidth: 8, padding: 20, font: { size: 12, weight: 600 } } 
          },
          tooltip: {
            backgroundColor: '#0f172a',
            padding: 12,
            cornerRadius: 8,
            bodyFont: { size: 13, weight: 600 },
            callbacks: {
              label: function(context) {
                return ' UGX ' + Number(context.parsed).toLocaleString();
              }
            }
          }
        }
      }
    });
  }
})();