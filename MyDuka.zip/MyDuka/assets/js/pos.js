// assets/js/pos.js
(function () {
  const cfg = window.__RP_POS__;
  if (!cfg) return;

  const $grid     = document.getElementById('posGrid');
  const $search   = document.getElementById('posSearch');
  const $cart     = document.getElementById('posCart');
  const $subtotal = document.getElementById('posSubtotal');
  const $taxEl    = document.getElementById('posTax');
  const $total    = document.getElementById('posTotal');
  const $discount = document.getElementById('posDiscount');
  const $json     = document.getElementById('posCartJson');
  const $checkout = document.getElementById('posCheckoutBtn');
  const $clear    = document.getElementById('posClear');
  const $payBtns  = document.querySelectorAll('#posPayMethods .pay-btn');
  const $method   = document.getElementById('posPayMethod');

  let cart = []; 
  let activeCategory = 0;
  let productsCache = [];
  let submitting = false;

  const fmt = n => 'UGX ' + Number(n || 0).toLocaleString(undefined, {minimumFractionDigits: 2});

  // -------- Product Grid --------
  async function loadProducts(q = '') {
    $grid.innerHTML = `
      <div class="w-100 text-center py-5 text-muted d-flex flex-column align-items-center">
        <div class="spinner-border text-primary mb-3" role="status" style="width: 2.5rem; height: 2.5rem;"></div>
        <h6 class="fw-bold">Loading catalog...</h6>
      </div>`;
    
    try {
      const base = cfg.searchUrl || `${cfg.appUrl}/employee/pos.php?api=search`;
      const res  = await fetch(`${base}&q=${encodeURIComponent(q)}`);
      const data = await res.json();
      productsCache = data.items || [];
      renderGrid();
    } catch (e) {
      $grid.innerHTML = '<div class="w-100 text-center py-5 text-danger fw-bold">Error loading products.</div>';
    }
  }

  function renderGrid() {
    const items = activeCategory === 0
      ? productsCache
      : productsCache.filter(p => String(p.category_id) === String(activeCategory));

    if (!items.length) {
      $grid.innerHTML = `
        <div class="w-100 text-center py-5 text-muted d-flex flex-column align-items-center">
          <i class="fa-solid fa-box-open mb-3" style="font-size: 3rem; opacity: 0.2;"></i>
          <h6 class="fw-bold">No products found</h6>
          <p class="small">Try searching for a different term.</p>
        </div>`;
      return;
    }
    
    $grid.innerHTML = items.map(p => {
      const stock = Number(p.stock);
      const out = stock <= 0;
      return `
        <button type="button" class="pos-card ${out ? 'out' : ''}" data-id="${p.id}" ${out ? 'disabled' : ''}>
          <div>
            <div class="pos-card-title">${escapeHtml(p.name)}</div>
            <div class="pos-card-sku">${escapeHtml(p.sku)}</div>
          </div>
          <div>
            <div class="pos-card-price">${fmt(p.selling_price)}</div>
            <div class="pos-card-stock">
              <span>In Stock:</span>
              <span class="${out ? 'text-danger' : 'text-dark'}">${stock} ${escapeHtml(p.unit)}</span>
            </div>
          </div>
        </button>
      `;
    }).join('');

    $grid.querySelectorAll('.pos-card').forEach(btn => {
      btn.addEventListener('click', () => addToCart(Number(btn.dataset.id)));
    });
  }

  function escapeHtml(s) {
    return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  // -------- Filter & Search --------
  document.querySelectorAll('#posCategories .pos-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#posCategories .pos-tab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeCategory = Number(btn.dataset.cat) || 0;
      renderGrid();
    });
  });

  let searchTimer;
  $search.addEventListener('input', () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => loadProducts($search.value.trim()), 250);
  });

  // -------- Cart Logic --------
  function findIndex(id) { return cart.findIndex(l => l.id === id); }

  function addToCart(id) {
    const p = productsCache.find(x => Number(x.id) === id);
    if (!p) return;
    const idx = findIndex(id);
    const stock = Number(p.stock);
    
    if (idx >= 0) {
      if (cart[idx].qty + 1 > stock) {
        flash('Cannot exceed available stock.');
        return;
      }
      cart[idx].qty += 1;
    } else {
      if (stock <= 0) { flash('Out of stock.'); return; }
      cart.push({id, name: p.name, price: Number(p.selling_price), qty: 1, stock, unit: p.unit});
    }
    renderCart();
  }

  function setQty(id, qty) {
    const idx = findIndex(id);
    if (idx < 0) return;
    if (qty <= 0) { cart.splice(idx, 1); }
    else if (qty > cart[idx].stock) { flash('Exceeds available stock.'); return; }
    else { cart[idx].qty = qty; }
    renderCart();
  }

  function removeLine(id) {
    const idx = findIndex(id);
    if (idx >= 0) cart.splice(idx, 1);
    renderCart();
  }

  // -------- Render Cart --------
  function renderCart() {
    if (!cart.length) {
      $cart.innerHTML = `
        <div class="empty-cart-state">
          <i class="fa-solid fa-cart-shopping"></i>
          <h6 class="fw-bold mb-1">Cart is empty</h6>
          <p class="small text-center px-3">Scan a barcode or click a product on the left to start.</p>
        </div>`;
    } else {
      $cart.innerHTML = cart.map(l => `
        <div class="cart-receipt-item">
          <div class="cart-item-info">
            <div class="cart-item-name">${escapeHtml(l.name)}</div>
            <div class="cart-item-meta">${fmt(l.price)} / ${escapeHtml(l.unit)}</div>
          </div>
          
          <div class="cart-qty-controls">
            <button type="button" data-act="dec" data-id="${l.id}"><i class="fa-solid fa-minus" style="font-size:0.7rem;"></i></button>
            <input type="number" value="${l.qty}" readonly>
            <button type="button" data-act="inc" data-id="${l.id}"><i class="fa-solid fa-plus" style="font-size:0.7rem;"></i></button>
          </div>
          
          <div class="cart-item-price">${fmt(l.price * l.qty)}</div>
          
          <button type="button" class="cart-item-remove" data-act="del" data-id="${l.id}">&times;</button>
        </div>
      `).join('');

      $cart.querySelectorAll('button[data-act]').forEach(b => {
        const id = Number(b.dataset.id);
        if (b.dataset.act === 'inc') {
          b.addEventListener('click', () => {
            const i = findIndex(id);
            if (i >= 0) setQty(id, cart[i].qty + 1);
          });
        }
        if (b.dataset.act === 'dec') {
          b.addEventListener('click', () => {
            const i = findIndex(id);
            if (i >= 0) setQty(id, cart[i].qty - 1);
          });
        }
        if (b.dataset.act === 'del') b.addEventListener('click', () => removeLine(id));
      });
    }
    recalcTotals();
    $checkout.disabled = cart.length === 0 || submitting;
  }

  function recalcTotals() {
    const subtotal = cart.reduce((s, l) => s + l.price * l.qty, 0);
    const discount = Math.min(Math.max(0, Number($discount.value) || 0), subtotal);
    const taxable  = subtotal - discount;
    const tax      = taxable * (Number(cfg.taxRate) / 100);
    const total    = taxable + tax;

    $subtotal.textContent = fmt(subtotal);
    if ($taxEl) $taxEl.textContent = fmt(tax);
    $total.textContent = fmt(total);
    $json.value = JSON.stringify(cart.map(l => ({product_id: l.id, quantity: l.qty})));
  }

  $discount.addEventListener('input', recalcTotals);

  // -------- Payment Method --------
  $payBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      $payBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      $method.value = btn.dataset.method;
    });
  });

  // -------- Clear & Checkout --------
  $clear.addEventListener('click', () => {
    if (!cart.length) return;
    if (!confirm('Clear the cart?')) return;
    cart = [];
    renderCart();
  });

  const $form = document.getElementById('posForm');
  if ($form) {
    $form.addEventListener('submit', e => {
      if (submitting) { e.preventDefault(); return; }
      if (!cart.length) { e.preventDefault(); flash('Cart is empty.'); return; }
      submitting = true;
      $checkout.disabled = true;
      $checkout.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Processing...';
    });
  }

  // -------- Shortcuts --------
  document.addEventListener('keydown', e => {
    if (e.key === 'F2') { e.preventDefault(); $search.focus(); }
    if (e.key === 'F4') {
      e.preventDefault();
      if (!$checkout.disabled && !submitting) $checkout.click();
    }
  });

  // -------- Toast --------
  function flash(msg) {
    const el = document.createElement('div');
    el.className = 'alert alert-danger position-fixed top-0 start-50 translate-middle-x mt-3 shadow-lg fw-bold border-0';
    el.style.zIndex = 2000;
    el.style.pointerEvents = 'none';
    el.style.borderRadius = '50px';
    el.style.padding = '0.75rem 1.5rem';
    el.innerHTML = '<i class="fa-solid fa-circle-exclamation me-2"></i>' + msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
  }

  // -------- Init --------
  loadProducts();
  renderCart();
})();