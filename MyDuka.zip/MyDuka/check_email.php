<?php
// check_email.php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) redirect('index.php');

$email = $_SESSION['pending_verification_email'] ?? 'your email address';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Check Your Email · <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

  body {
    font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
    background-color: #f4f6fb;
    margin: 0; padding: 0; min-height: 100vh; display: flex;
  }

  .login-wrapper { display: flex; min-height: 100vh; width: 100vw; }

  /* LEFT PANEL - BRANDING */
  .login-left {
    display: none; flex: 1;
    background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%);
    position: relative; overflow: hidden; padding: 4rem;
    flex-direction: column; justify-content: space-between; align-items: center;
    color: #fff;
  }

  @media (min-width: 992px) { .login-left { display: flex; } }

  .login-left::before {
    content: ''; position: absolute; inset: 0;
    background-image: linear-gradient(rgba(255, 255, 255, 0.05) 1px, transparent 1px),
                      linear-gradient(90deg, rgba(255, 255, 255, 0.05) 1px, transparent 1px);
    background-size: 25px 25px;
    mask-image: linear-gradient(to bottom, black, transparent);
    -webkit-mask-image: linear-gradient(to bottom, black, transparent);
  }
  
  .login-left::after {
    content: ''; position: absolute; top: -20%; right: -10%;
    width: 500px; height: 500px;
    background: radial-gradient(circle, rgba(59, 130, 246, 0.4) 0%, transparent 70%);
    filter: blur(50px); border-radius: 50%;
  }

  .brand-content {
    text-align: center; position: relative; z-index: 2;
    display: flex; flex-direction: column; align-items: center;
    margin-top: auto; margin-bottom: auto;
  }

  .login-logo-wrap {
    margin-bottom: 3rem; display: inline-block; text-decoration: none;
    transition: transform 0.2s ease;
  }
  .login-logo-wrap:hover { transform: scale(1.05); }
  
  .login-logo-img {
    height: 100px; width: auto; max-width: 320px;
    object-fit: contain; transform: scale(1.3); 
  }

  .login-left h1 {
    font-weight: 800; font-size: 3rem;
    letter-spacing: -0.03em; line-height: 1.1; margin-bottom: 1.5rem;
  }
  
  .login-left p { color: #94a3b8; font-size: 1.1rem; line-height: 1.6; max-width: 450px; margin: 0 auto; }

  /* RIGHT PANEL */
  .login-right {
    flex: 1; display: flex; align-items: center; justify-content: center;
    padding: 2rem; background: #fff; position: relative;
  }

  .form-wrapper { width: 100%; max-width: 480px; text-align: center; }

  /* Animated Envelope Icon */
  .mail-icon-wrap {
    position: relative;
    width: 100px; height: 100px;
    margin: 0 auto 2rem;
    display: flex; align-items: center; justify-content: center;
  }
  .mail-icon-bg {
    position: absolute; inset: 0;
    background: #eff6ff; border-radius: 50%;
    animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
  }
  .mail-icon {
    position: relative; z-index: 2;
    width: 72px; height: 72px; border-radius: 50%;
    background: linear-gradient(135deg, #2563eb, #1d4ed8);
    color: #fff; display: flex; align-items: center; justify-content: center;
    font-size: 2rem;
    box-shadow: 0 8px 24px rgba(37,99,235,.3);
  }
  
  @keyframes pulse {
    0%, 100% { transform: scale(1); opacity: 0.6; }
    50% { transform: scale(1.2); opacity: 0.3; }
  }

  .form-header { margin-bottom: 2rem; }
  .form-header h3 { font-weight: 800; font-size: 1.85rem; color: #0f172a; letter-spacing: -0.02em; margin-bottom: 0.75rem; }
  .form-header p { color: #64748b; font-size: 1rem; line-height: 1.6; }
  
  .email-highlight {
    display: inline-block;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    padding: 0.4rem 1rem;
    border-radius: 8px;
    color: #0f172a;
    font-weight: 700;
    margin-top: 0.75rem;
    font-size: 0.95rem;
    word-break: break-all;
  }

  /* Action Buttons */
  .btn-primary-custom {
    display: flex; align-items: center; justify-content: center; gap: 0.5rem;
    width: 100%;
    background: #0f172a; color: #fff; text-decoration: none;
    font-weight: 700; padding: 0.95rem; border-radius: 10px;
    transition: all 0.2s;
    font-size: 1rem;
  }
  .btn-primary-custom:hover { background: #1e293b; color: #fff; transform: translateY(-1px); box-shadow: 0 6px 15px rgba(15, 23, 42, 0.2); }

  .back-link {
    display: inline-flex; align-items: center; gap: 0.4rem;
    font-size: 0.9rem; color: #64748b; text-decoration: none;
    margin-top: 1.5rem; font-weight: 500;
    transition: color 0.2s;
  }
  .back-link:hover { color: #0f172a; }
  .back-link i { font-size: 0.7rem; }

  /* Divider */
  .helper-divider {
    display: flex; align-items: center; text-align: center;
    color: #94a3b8; font-size: 0.8rem; font-weight: 500;
    margin: 2rem 0 1.25rem;
  }
  .helper-divider::before, .helper-divider::after {
    content: ''; flex: 1; border-bottom: 1px solid #e2e8f0;
  }
  .helper-divider::before { margin-right: 1rem; }
  .helper-divider::after { margin-left: 1rem; }

  .helper-text { font-size: 0.85rem; color: #64748b; line-height: 1.6; }
  .helper-text a { color: #2563eb; font-weight: 700; text-decoration: none; }
  .helper-text a:hover { text-decoration: underline; }
</style>
</head>
<body>

<div class="login-wrapper">
  <!-- LEFT SIDE: BRANDING -->
  <div class="login-left">
    <div class="brand-content">
      <a href="index.php" class="login-logo-wrap" title="Back to Home">
        <img src="<?= e(APP_URL) ?>/assets/logo/logo.png" alt="<?= e(APP_NAME) ?> Logo" class="login-logo-img">
      </a>
      <h1>One step closer.</h1>
      <p>We just need to make sure it's really you. Click the link in your email to activate your workspace.</p>
    </div>
    <div style="position: relative; z-index: 2;">
      <p class="small mb-0" style="opacity: 0.6;">&copy; <?= date('Y') ?> <?= e(APP_NAME) ?>. All rights reserved.</p>
    </div>
  </div>

  <!-- RIGHT SIDE -->
  <div class="login-right">
    <div class="form-wrapper">
      
      <!-- Animated Envelope Icon -->
      <div class="mail-icon-wrap">
        <div class="mail-icon-bg"></div>
        <div class="mail-icon">
          <i class="fa-solid fa-envelope-open-text"></i>
        </div>
      </div>

      <!-- Header -->
      <div class="form-header">
        <h3>Check your email</h3>
        <p>We've sent a verification link to:</p>
        <div class="email-highlight"><?= e($email) ?></div>
      </div>

      <!-- Primary Action -->
      <a href="login.php" class="btn-primary-custom">
        <i class="fa-solid fa-arrow-right-to-bracket"></i> Go to Login
      </a>

      <!-- Divider + Helper -->
      <div class="helper-divider">Didn't receive it?</div>
      <p class="helper-text">
        Check your <strong>spam folder</strong> or wait a few minutes.<br>
        Still nothing? <a href="register.php">Try registering again</a>.
      </p>

      <!-- Back Link -->
      <a href="index.php" class="back-link">
        <i class="fa-solid fa-arrow-left"></i> Back to Home
      </a>

    </div>
  </div>
</div>

</body>
</html>