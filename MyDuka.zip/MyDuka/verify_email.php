<?php
// verify_email.php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

$token   = get('token', '');
$success = false;
$error   = '';
$user    = null;

if ($token === '') {
    $error = 'Invalid verification link.';
} else {
    // 1. Find the user by token
    $stmt = db()->prepare(
        "SELECT id, full_name, business_id FROM users 
         WHERE verification_token = ? AND email_verified_at IS NULL 
         LIMIT 1"
    );
    $stmt->execute([$token]);
    $user = $stmt->fetch();

    if (!$user) {
        $error = 'This verification link is invalid or has already been used.';
    } else {
        // 2. Mark verified and CLEAR the token
        $updated = db()->prepare(
            "UPDATE users 
             SET email_verified_at = NOW(), verification_token = NULL 
             WHERE id = ?"
        );
        $updated->execute([$user['id']]);

        if ($updated->rowCount() > 0) {
            $success = true;

            // 3. Auto-login (still, but now we stay on this page)
            session_regenerate_id(true);
            $userFull = db()->prepare(
                "SELECT u.*, r.name AS role_name FROM users u 
                 JOIN roles r ON r.id = u.role_id 
                 WHERE u.id = ? LIMIT 1"
            );
            $userFull->execute([$user['id']]);
            $u = $userFull->fetch();

            $_SESSION['user_id']     = (int)$u['id'];
            $_SESSION['role']        = $u['role_name'];
            $_SESSION['business_id'] = $u['business_id'] ? (int)$u['business_id'] : null;
        } else {
            $error = 'Could not verify your email. Please try again or contact support.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Verifying Email · <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

  body {
    font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
    background-color: #f4f6fb;
    margin: 0; padding: 0; min-height: 100vh; display: flex;
  }

  .login-wrapper { display: flex; min-height: 100vh; width: 100vw; }

  /* LEFT PANEL */
  .login-left {
    display: none; flex: 1;
    background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%);
    position: relative; overflow: hidden; padding: 4rem;
    flex-direction: column; justify-content: space-between; align-items: center;
    color: #fff;
  }

  @media (min-width: 992px) { .login-left { display: flex; } }

  .login-left::before {
    content: ''; position: absolute; inset: 0;
    background-image: linear-gradient(rgba(255, 255, 255, 0.05) 1px, transparent 1px),
                      linear-gradient(90deg, rgba(255, 255, 255, 0.05) 1px, transparent 1px);
    background-size: 25px 25px;
    mask-image: linear-gradient(to bottom, black, transparent);
    -webkit-mask-image: linear-gradient(to bottom, black, transparent);
  }
  
  .login-left::after {
    content: ''; position: absolute; top: -20%; right: -10%;
    width: 500px; height: 500px;
    background: radial-gradient(circle, rgba(59, 130, 246, 0.4) 0%, transparent 70%);
    filter: blur(50px); border-radius: 50%;
  }

  .brand-content {
    text-align: center; position: relative; z-index: 2;
    display: flex; flex-direction: column; align-items: center;
    margin-top: auto; margin-bottom: auto;
  }

  .login-logo-wrap { margin-bottom: 3rem; display: inline-block; text-decoration: none; transition: transform 0.2s ease; }
  .login-logo-wrap:hover { transform: scale(1.05); }
  .login-logo-img { height: 100px; width: auto; max-width: 320px; object-fit: contain; transform: scale(1.3); }

  .login-left h1 { font-weight: 800; font-size: 3rem; letter-spacing: -0.03em; line-height: 1.1; margin-bottom: 1.5rem; }
  .login-left p { color: #94a3b8; font-size: 1.1rem; line-height: 1.6; max-width: 450px; margin: 0 auto; }

  /* RIGHT PANEL */
  .login-right {
    flex: 1; display: flex; align-items: center; justify-content: center;
    padding: 2rem; background: #fff; position: relative;
  }

  .form-wrapper { width: 100%; max-width: 480px; }

  /* Animated Icon */
  .icon-wrap {
    position: relative;
    width: 100px; height: 100px;
    margin: 0 auto 2rem;
    display: flex; align-items: center; justify-content: center;
  }
  
  .icon-bg {
    position: absolute; inset: 0;
    border-radius: 50%;
    animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
  }
  .icon-bg.success { background: #dcfce7; }
  .icon-bg.error { background: #fee2e2; }
  
  .icon-circle {
    position: relative; z-index: 2;
    width: 72px; height: 72px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 2rem;
  }
  .icon-circle.success {
    background: linear-gradient(135deg, #22c55e, #16a34a);
    color: #fff;
    box-shadow: 0 8px 24px rgba(22,163,74,.3);
  }
  .icon-circle.error {
    background: linear-gradient(135deg, #ef4444, #dc2626);
    color: #fff;
    box-shadow: 0 8px 24px rgba(220,38,38,.3);
  }
  
  @keyframes pulse {
    0%, 100% { transform: scale(1); opacity: 0.6; }
    50% { transform: scale(1.2); opacity: 0.3; }
  }

  /* Content */
  .content-wrap { text-align: center; margin-bottom: 2rem; }
  .content-wrap h3 { font-weight: 800; font-size: 1.85rem; color: #0f172a; letter-spacing: -0.02em; margin-bottom: 0.75rem; }
  .content-wrap p { color: #64748b; font-size: 1rem; line-height: 1.6; margin: 0 0 1rem 0; }

  /* Countdown pill */
  .countdown-pill {
    display: inline-flex; align-items: center; gap: 0.5rem;
    background: #f8fafc; border: 1px solid #e2e8f0;
    padding: 0.6rem 1rem; border-radius: 10px;
    color: #475569; font-size: 0.85rem; font-weight: 600;
    margin-top: 0.5rem;
  }
  .countdown-pill strong { color: #2563eb; }

  /* Buttons */
  .action-wrap {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 1rem;
    margin-top: 1rem;
  }

  .btn-primary-custom {
    display: flex; align-items: center; justify-content: center; gap: 0.5rem;
    width: 100%;
    background: #2563eb; color: #fff; text-decoration: none;
    font-weight: 700; padding: 0.95rem; border-radius: 10px;
    transition: all 0.2s; font-size: 1rem;
    border: none;
  }
  .btn-primary-custom:hover {
    background: #1d4ed8; color: #fff;
    transform: translateY(-1px);
    box-shadow: 0 6px 15px rgba(37, 99, 235, 0.25);
  }

  .back-link {
    display: inline-flex; align-items: center; gap: 0.4rem;
    font-size: 0.9rem; color: #64748b; text-decoration: none;
    font-weight: 500;
    transition: color 0.2s;
    margin: 0;
  }
  .back-link:hover { color: #0f172a; }
  .back-link i { font-size: 0.7rem; }
</style>
</head>
<body>

<div class="login-wrapper">
  <!-- LEFT SIDE -->
  <div class="login-left">
    <div class="brand-content">
      <a href="index.php" class="login-logo-wrap" title="Back to Home">
        <img src="<?= e(APP_URL) ?>/assets/logo/logo.png" alt="<?= e(APP_NAME) ?> Logo" class="login-logo-img">
      </a>
      
      <?php if ($success): ?>
        <h1>You're all set!</h1>
        <p>Your account is now active and secure. Let's get you back to running your shop.</p>
      <?php else: ?>
        <h1>Something went wrong.</h1>
        <p>Don't worry, these things happen. You can try logging in again or contact support if the issue persists.</p>
      <?php endif; ?>
    </div>
    <div style="position: relative; z-index: 2;">
      <p class="small mb-0" style="opacity: 0.6;">&copy; <?= date('Y') ?> <?= e(APP_NAME) ?>. All rights reserved.</p>
    </div>
  </div>

  <!-- RIGHT SIDE -->
  <div class="login-right">
    <div class="form-wrapper">
      
      <?php if ($success): ?>
        <!-- SUCCESS -->
        <div class="icon-wrap">
          <div class="icon-bg success"></div>
          <div class="icon-circle success">
            <i class="fa-solid fa-check"></i>
          </div>
        </div>

        <div class="content-wrap">
          <h3>Email Verified!</h3>
          <p>Your account is now active. You can continue to your dashboard.</p>
          <div class="countdown-pill">
            Auto-redirecting in <strong id="countdown">3</strong>s
          </div>
        </div>

        <div class="action-wrap">
          <a href="<?= e(APP_URL) ?>/index.php" class="btn-primary-custom">
            <i class="fa-solid fa-gauge-high"></i> Go to Dashboard
          </a>
          <a href="index.php" class="back-link">
            <i class="fa-solid fa-arrow-left"></i> Back to Home
          </a>
        </div>

      <?php else: ?>
        <!-- ERROR -->
        <div class="icon-wrap">
          <div class="icon-bg error"></div>
          <div class="icon-circle error">
            <i class="fa-solid fa-xmark"></i>
          </div>
        </div>

        <div class="content-wrap">
          <h3>Verification Failed</h3>
          <p><?= e($error) ?></p>
        </div>

        <div class="action-wrap">
          <a href="login.php" class="btn-primary-custom">
            <i class="fa-solid fa-arrow-right-to-bracket"></i> Go to Login
          </a>
          <a href="index.php" class="back-link">
            <i class="fa-solid fa-arrow-left"></i> Back to Home
          </a>
        </div>
      <?php endif; ?>

    </div>
  </div>
</div>

<?php if ($success): ?>
<script>
  // Countdown from 3 → redirect to index.php (which routes to the correct dashboard)
  let seconds = 3;
  const el = document.getElementById('countdown');

  const timer = setInterval(() => {
    seconds--;
    if (el) el.textContent = seconds;
    if (seconds <= 0) {
      clearInterval(timer);
      window.location.href = <?= json_encode(APP_URL . '/index.php') ?>;
    }
  }, 1000);
</script>
<?php endif; ?>

</body>
</html>