<?php
// register.php
declare(strict_types=1);

require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/config/mailer.php';

if (is_file(__DIR__ . '/includes/auth.php')) require_once __DIR__ . '/includes/auth.php';

// If already logged in, bounce
if (session_status() === PHP_SESSION_ACTIVE && !empty($_SESSION['user_id'])) {
    redirect('index.php');
}

$errors = [];
$form = [
    'business_name' => '',
    'owner_name'    => '',
    'email'         => '',
    'phone'         => '',
    'branch_name'   => 'Main Branch',
    'address'       => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    foreach ($form as $k => $_) $form[$k] = post($k);

    // ---- Validate ----
    if ($form['business_name'] === '') $errors['business_name'] = 'Business name is required.';
    if ($form['owner_name'] === '')    $errors['owner_name']    = 'Your full name is required.';
    if (!valid_email($form['email']))  $errors['email']         = 'A valid email is required.';
    if (!valid_phone($form['phone']))  $errors['phone']         = 'A valid phone number is required.';
    if (strlen(post('password')) < PASSWORD_MIN_LEN) {
        $errors['password'] = 'Password must be at least ' . PASSWORD_MIN_LEN . ' characters.';
    }
    if (post('password') !== post('password_confirm')) {
        $errors['password_confirm'] = 'Passwords do not match.';
    }

    // Email uniqueness
    if (!$errors) {
        $stmt = db()->prepare("SELECT 1 FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$form['email']]);
        if ($stmt->fetchColumn()) {
            $errors['email'] = 'This email is already registered.';
        }
    }

    if (!$errors) {
        $pdo = db();
        try {
            $pdo->beginTransaction();

            // 1. Insert business
            $stmt = $pdo->prepare(
                "INSERT INTO businesses (name, phone, email, address, status)
                 VALUES (?, ?, ?, ?, 'active')"
            );
            $stmt->execute([$form['business_name'], $form['phone'], $form['email'], $form['address']]);
            $businessId = (int)$pdo->lastInsertId();

            // 2. Generate verification token
            $verificationToken = bin2hex(random_bytes(32));

            // 3. Insert owner user (unverified)
            $hash = password_hash(post('password'), PASSWORD_DEFAULT);
            $stmt = $pdo->prepare(
                "INSERT INTO users (role_id, business_id, full_name, email, phone, password_hash, status, verification_token, email_verified_at)
                 VALUES (2, ?, ?, ?, ?, ?, 'active', ?, NULL)"
            );
            $stmt->execute([$businessId, $form['owner_name'], $form['email'], $form['phone'], $hash, $verificationToken]);
            $ownerId = (int)$pdo->lastInsertId();

            // 4. Link owner to business
            $pdo->prepare("UPDATE businesses SET owner_id = ? WHERE id = ?")
                ->execute([$ownerId, $businessId]);

            // 5. Main branch
            $pdo->prepare(
                "INSERT INTO branches (business_id, name, is_main, status)
                 VALUES (?, ?, 1, 'active')"
            )->execute([$businessId, $form['branch_name'] ?: 'Main Branch']);

            // 6. Business settings
            $pdo->prepare("INSERT INTO business_settings (business_id) VALUES (?)")
                ->execute([$businessId]);

            // 7. Default expense categories
            $defaults = ['Rent', 'Utilities', 'Salaries', 'Transport', 'Packaging', 'Other'];
            $stmt = $pdo->prepare("INSERT INTO expense_categories (business_id, name) VALUES (?, ?)");
            foreach ($defaults as $cat) $stmt->execute([$businessId, $cat]);

            $pdo->commit();

            // 8. Send verification email
            $verifyUrl = APP_URL . '/verify_email.php?token=' . $verificationToken;
            $htmlBody = "
                <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 30px; background: #f8fafc; border-radius: 12px;'>
                    <h2 style='color: #0f172a;'>Welcome to My Duka, " . htmlspecialchars($form['owner_name']) . "!</h2>
                    <p style='color: #475569; font-size: 15px; line-height: 1.6;'>Your business account for <strong>" . htmlspecialchars($form['business_name']) . "</strong> has been created successfully.</p>
                    <p style='color: #475569; font-size: 15px; line-height: 1.6;'>To activate your account and start using the platform, please verify your email by clicking the button below.</p>
                    <div style='text-align: center; margin: 30px 0;'>
                        <a href='$verifyUrl' style='background: #2563eb; color: #fff; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;'>Verify My Email</a>
                    </div>
                    <p style='color: #94a3b8; font-size: 13px;'>If the button doesn't work, copy this link into your browser:<br><a href='$verifyUrl' style='color: #2563eb;'>$verifyUrl</a></p>
                    <hr style='border: none; border-top: 1px solid #e2e8f0; margin: 20px 0;'>
                    <p style='color: #94a3b8; font-size: 12px; text-align: center;'>&copy; " . date('Y') . " My Duka. All rights reserved.</p>
                </div>
            ";

            try {
                send_email($form['email'], $form['owner_name'], 'Verify Your Email · My Duka', $htmlBody);
            } catch (Throwable $ex) {
                error_log("Verification email failed for {$form['email']}: " . $ex->getMessage());
            }

            // Show the "check your email" page
            $_SESSION['pending_verification_email'] = $form['email'];
            redirect('check_email.php');

        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $errors['general'] = APP_ENV === 'development'
                ? 'Registration failed: ' . $ex->getMessage()
                : 'Registration failed. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Register · <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

  body {
    font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
    background-color: #f4f6fb;
    margin: 0; padding: 0; min-height: 100vh; display: flex;
  }

  .login-wrapper { display: flex; min-height: 100vh; width: 100vw; }

  /* LEFT PANEL - BRANDING */
  .login-left {
    display: none; flex: 1;
    background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%);
    position: relative; overflow: hidden; padding: 4rem;
    flex-direction: column; justify-content: space-between; align-items: center;
    color: #fff;
  }

  @media (min-width: 992px) { .login-left { display: flex; } }

  .login-left::before {
    content: ''; position: absolute; inset: 0;
    background-image: linear-gradient(rgba(255, 255, 255, 0.05) 1px, transparent 1px),
                      linear-gradient(90deg, rgba(255, 255, 255, 0.05) 1px, transparent 1px);
    background-size: 25px 25px;
    mask-image: linear-gradient(to bottom, black, transparent);
    -webkit-mask-image: linear-gradient(to bottom, black, transparent);
  }
  
  .login-left::after {
    content: ''; position: absolute; top: -20%; right: -10%;
    width: 500px; height: 500px;
    background: radial-gradient(circle, rgba(59, 130, 246, 0.4) 0%, transparent 70%);
    filter: blur(50px); border-radius: 50%;
  }

  .brand-content {
    text-align: center; position: relative; z-index: 2;
    display: flex; flex-direction: column; align-items: center;
    margin-top: auto; margin-bottom: auto;
  }

  .login-logo-wrap {
    margin-bottom: 3rem;
    display: inline-block;
    text-decoration: none;
    transition: transform 0.2s ease;
  }
  .login-logo-wrap:hover { transform: scale(1.05); }
  
  .login-logo-img {
    height: 100px; width: auto; max-width: 320px;
    object-fit: contain; transform: scale(1.3); 
  }

  .login-left h1 {
    font-weight: 800; font-size: 3rem;
    letter-spacing: -0.03em; line-height: 1.1; margin-bottom: 1.5rem;
  }
  
  .login-left p { color: #94a3b8; font-size: 1.1rem; line-height: 1.6; max-width: 450px; margin: 0 auto; }

  /* RIGHT PANEL - FORM */
  .login-right {
    flex: 1.2; display: flex; align-items: center; justify-content: center;
    padding: 2rem; background: #fff; position: relative; overflow-y: auto;
  }

  .form-wrapper { width: 100%; max-width: 540px; padding: 2rem 0; }

  .form-header { margin-bottom: 2rem; text-align: center; }
  .form-header h3 { font-weight: 800; font-size: 1.75rem; color: #0f172a; letter-spacing: -0.02em; margin-bottom: 0.5rem; }
  .form-header p { color: #64748b; font-size: 0.95rem; }

  .form-group { margin-bottom: 1.25rem; }
  .form-group label { display: block; font-size: 0.85rem; font-weight: 700; color: #334155; margin-bottom: 0.4rem; }

  .input-wrapper { position: relative; }
  .input-wrapper input {
    width: 100%; padding: 0.85rem 1rem; padding-right: 3rem;
    border-radius: 10px; border: 1px solid #cbd5e1;
    font-size: 0.95rem; font-weight: 500; color: #0f172a;
    background: #f8fafc; transition: all 0.2s;
  }
  .input-wrapper input:focus {
    outline: none; background: #fff; border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
  }
  .input-wrapper input.is-invalid { border-color: #ef4444; }

  .toggle-password {
    position: absolute; right: 0.85rem; top: 50%; transform: translateY(-50%);
    background: none; border: none; color: #94a3b8; cursor: pointer; padding: 0.25rem;
    font-size: 1.1rem; transition: color 0.2s;
  }
  .toggle-password:hover { color: #475569; }

  .alert-custom {
    background: #fef2f2; color: #991b1b; border: 1px solid #fecaca;
    border-radius: 10px; padding: 0.85rem 1rem; font-size: 0.85rem; font-weight: 600;
    margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.5rem;
  }

  .invalid-feedback-custom {
    display: block; width: 100%; margin-top: 0.25rem;
    font-size: 0.8rem; font-weight: 500; color: #dc2626;
  }

  .btn-submit {
    width: 100%; background: #0f172a; color: #fff; border: none;
    border-radius: 10px; padding: 0.9rem; font-weight: 700; font-size: 1rem;
    transition: all 0.2s; margin-top: 1rem; display: flex; justify-content: center; align-items: center; gap: 0.5rem;
  }
  .btn-submit:hover { background: #1e293b; transform: translateY(-1px); box-shadow: 0 6px 15px rgba(15, 23, 42, 0.2); }

  .footer-text { text-align: center; font-size: 0.9rem; color: #64748b; margin-top: 2rem; }
  .footer-text a { font-weight: 700; color: #2563eb; text-decoration: none; }
  .footer-text a:hover { text-decoration: underline; }

  .back-link {
    display: block; text-align: center; font-size: 0.85rem; color: #94a3b8;
    text-decoration: none; margin-top: 1.5rem; transition: color 0.2s;
  }
  .back-link:hover { color: #0f172a; }
</style>
</head>
<body>

<div class="login-wrapper">
  <!-- LEFT SIDE: BRANDING -->
  <div class="login-left">
    <div class="brand-content">
      <a href="index.php" class="login-logo-wrap" title="Back to Home">
        <img src="<?= e(APP_URL) ?>/assets/logo/logo.png" alt="<?= e(APP_NAME) ?> Logo" class="login-logo-img">
      </a>
      
      <h1>Start managing <br> your retail today.</h1>
      <p>Join thousands of businesses using <?= e(APP_NAME) ?> to streamline inventory, sales, and daily operations.</p>
    </div>
    
    <div style="position: relative; z-index: 2;">
      <p class="small mb-0" style="opacity: 0.6;">&copy; <?= date('Y') ?> <?= e(APP_NAME) ?>. All rights reserved.</p>
    </div>
  </div>

  <!-- RIGHT SIDE: FORM -->
  <div class="login-right">
    <div class="form-wrapper">
      <div class="form-header">
        <h3>Create your account</h3>
        <p>Set up your business workspace in under a minute.</p>
      </div>

      <?= render_flashes() ?>
      <?php if (!empty($errors['general'])): ?>
        <div class="alert-custom">
          <i class="fa-solid fa-circle-exclamation fs-5"></i> <?= e($errors['general']) ?>
        </div>
      <?php endif; ?>

      <form method="post" novalidate>
        <?= csrf_field() ?>
        
        <div class="row g-3">
          <div class="col-md-6">
            <div class="form-group">
              <label for="business_name">Business Name</label>
              <input type="text" name="business_name" id="business_name" class="form-control <?= isset($errors['business_name']) ? 'is-invalid' : '' ?>"
                     value="<?= e($form['business_name']) ?>" placeholder="e.g. ABC Retail Enterprises" required>
              <?php if (isset($errors['business_name'])): ?>
                <div class="invalid-feedback-custom"><?= e($errors['business_name']) ?></div>
              <?php endif; ?>
            </div>
          </div>

          <div class="col-md-6">
            <div class="form-group">
              <label for="branch_name">Main Branch Name</label>
              <input type="text" name="branch_name" id="branch_name" class="form-control"
                     value="<?= e($form['branch_name']) ?>" placeholder="Main Branch">
            </div>
          </div>

          <div class="col-md-6">
            <div class="form-group">
              <label for="owner_name">Your Full Name</label>
              <input type="text" name="owner_name" id="owner_name" class="form-control <?= isset($errors['owner_name']) ? 'is-invalid' : '' ?>"
                     value="<?= e($form['owner_name']) ?>" required>
              <?php if (isset($errors['owner_name'])): ?>
                <div class="invalid-feedback-custom"><?= e($errors['owner_name']) ?></div>
              <?php endif; ?>
            </div>
          </div>

          <div class="col-md-6">
            <div class="form-group">
              <label for="phone">Phone Number</label>
              <input type="text" name="phone" id="phone" class="form-control <?= isset($errors['phone']) ? 'is-invalid' : '' ?>"
                     value="<?= e($form['phone']) ?>" placeholder="+256 7XX XXX XXX" required>
              <?php if (isset($errors['phone'])): ?>
                <div class="invalid-feedback-custom"><?= e($errors['phone']) ?></div>
              <?php endif; ?>
            </div>
          </div>

          <div class="col-12">
            <div class="form-group">
              <label for="email">Email Address</label>
              <input type="email" name="email" id="email" class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>"
                     value="<?= e($form['email']) ?>" required>
              <?php if (isset($errors['email'])): ?>
                <div class="invalid-feedback-custom"><?= e($errors['email']) ?></div>
              <?php endif; ?>
            </div>
          </div>

          <div class="col-md-6">
            <div class="form-group">
              <label for="password">Password</label>
              <div class="input-wrapper">
                <input type="password" name="password" id="password" class="form-control <?= isset($errors['password']) ? 'is-invalid' : '' ?>"
                       minlength="<?= PASSWORD_MIN_LEN ?>" required>
                <button type="button" class="toggle-password" data-target="password">
                  <i class="fa-regular fa-eye"></i>
                </button>
              </div>
              <?php if (isset($errors['password'])): ?>
                <div class="invalid-feedback-custom"><?= e($errors['password']) ?></div>
              <?php endif; ?>
            </div>
          </div>

          <div class="col-md-6">
            <div class="form-group">
              <label for="password_confirm">Confirm Password</label>
              <div class="input-wrapper">
                <input type="password" name="password_confirm" id="password_confirm" class="form-control <?= isset($errors['password_confirm']) ? 'is-invalid' : '' ?>" required>
                <button type="button" class="toggle-password" data-target="password_confirm">
                  <i class="fa-regular fa-eye"></i>
                </button>
              </div>
              <?php if (isset($errors['password_confirm'])): ?>
                <div class="invalid-feedback-custom"><?= e($errors['password_confirm']) ?></div>
              <?php endif; ?>
            </div>
          </div>

          <div class="col-12">
            <div class="form-group">
              <label for="address">Business Address <span class="text-muted" style="font-weight:500;">(optional)</span></label>
              <input type="text" name="address" id="address" class="form-control" value="<?= e($form['address']) ?>">
            </div>
          </div>
        </div>

        <button type="submit" class="btn-submit">
          Create Account <i class="fa-solid fa-arrow-right"></i>
        </button>
      </form>

      <p class="footer-text">
        Already have an account? <a href="login.php">Sign in</a>
      </p>

      <a href="index.php" class="back-link">
        <i class="fa-solid fa-arrow-left me-1" style="font-size: 0.75rem;"></i> Back to Home
      </a>
    </div>
  </div>
</div>

<script>
  document.querySelectorAll('.toggle-password').forEach(btn => {
    btn.addEventListener('click', function() {
      const targetId = this.dataset.target;
      const input = document.getElementById(targetId);
      const icon = this.querySelector('i');
      
      if (input.type === 'password') {
        input.type = 'text';
        icon.classList.replace('fa-eye', 'fa-eye-slash');
        this.style.color = '#2563eb';
      } else {
        input.type = 'password';
        icon.classList.replace('fa-eye-slash', 'fa-eye');
        this.style.color = '#94a3b8';
      }
    });
  });
</script>

</body>
</html>