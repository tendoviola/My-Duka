<?php
// reset_password.php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) redirect('index.php');

$token = get('token', '');
$error = '';
$success = false;
$user = null;

if ($token === '') {
    $error = 'Invalid or missing reset token.';
} else {
    $stmt = db()->prepare(
        "SELECT id, full_name, email, password_hash FROM users 
         WHERE reset_token = ? AND reset_expires_at > NOW() AND status = 'active' 
         LIMIT 1"
    );
    $stmt->execute([$token]);
    $user = $stmt->fetch();

    if (!$user) {
        $error = 'This reset link is invalid or has expired. Please request a new one.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $user) {
    verify_csrf();
    $password = post('password');
    $confirm  = post('password_confirm');

    if (strlen($password) < PASSWORD_MIN_LEN) {
        $error = 'Password must be at least ' . PASSWORD_MIN_LEN . ' characters.';
    } elseif (!preg_match('/[A-Z]/', $password) || !preg_match('/[a-z]/', $password)) {
        $error = 'Password must contain both uppercase and lowercase letters.';
    } elseif (!preg_match('/[0-9]/', $password)) {
        $error = 'Password must contain at least one number.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } elseif (password_verify($password, $user['password_hash'])) {
        $error = 'Your new password cannot be the same as your old password. Please choose a different one.';
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        db()->prepare("UPDATE users SET password_hash = ?, reset_token = NULL, reset_expires_at = NULL, must_change_password = 0 WHERE id = ?")
            ->execute([$hash, $user['id']]);
        
        audit_log('user.password_reset', 'users', (int)$user['id']);
        $success = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Reset Password · <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

  body {
    font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
    background-color: #f4f6fb;
    margin: 0; padding: 0; min-height: 100vh; display: flex;
  }

  .login-wrapper { display: flex; min-height: 100vh; width: 100vw; }

  /* LEFT PANEL */
  .login-left {
    display: none; flex: 1;
    background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%);
    position: relative; overflow: hidden; padding: 4rem;
    flex-direction: column; justify-content: space-between; align-items: center;
    color: #fff;
  }

  @media (min-width: 992px) { .login-left { display: flex; } }

  .login-left::before {
    content: ''; position: absolute; inset: 0;
    background-image: linear-gradient(rgba(255, 255, 255, 0.05) 1px, transparent 1px),
                      linear-gradient(90deg, rgba(255, 255, 255, 0.05) 1px, transparent 1px);
    background-size: 25px 25px;
    mask-image: linear-gradient(to bottom, black, transparent);
    -webkit-mask-image: linear-gradient(to bottom, black, transparent);
  }
  
  .login-left::after {
    content: ''; position: absolute; top: -20%; right: -10%;
    width: 500px; height: 500px;
    background: radial-gradient(circle, rgba(59, 130, 246, 0.4) 0%, transparent 70%);
    filter: blur(50px); border-radius: 50%;
  }

  .brand-content {
    text-align: center; position: relative; z-index: 2;
    display: flex; flex-direction: column; align-items: center;
    margin-top: auto; margin-bottom: auto;
  }

  .login-logo-wrap { margin-bottom: 3rem; display: inline-block; text-decoration: none; transition: transform 0.2s ease; }
  .login-logo-wrap:hover { transform: scale(1.05); }
  
  .login-logo-img { height: 100px; width: auto; max-width: 320px; object-fit: contain; transform: scale(1.3); }

  .login-left h1 { font-weight: 800; font-size: 3rem; letter-spacing: -0.03em; line-height: 1.1; margin-bottom: 1.5rem; }
  .login-left p { color: #94a3b8; font-size: 1.1rem; line-height: 1.6; max-width: 450px; margin: 0 auto; }

  /* RIGHT PANEL */
  .login-right {
    flex: 1; display: flex; align-items: center; justify-content: center;
    padding: 2rem; background: #fff; position: relative;
  }

  .form-wrapper { width: 100%; max-width: 440px; }

  .form-icon-wrap {
    width: 56px; height: 56px;
    border-radius: 14px;
    background: #eff6ff;
    color: #2563eb;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    margin: 0 auto 1.5rem;
  }

  .form-header { margin-bottom: 2rem; text-align: center; }
  .form-header h3 { font-weight: 800; font-size: 1.75rem; color: #0f172a; letter-spacing: -0.02em; margin-bottom: 0.5rem; }
  .form-header p { color: #64748b; font-size: 0.95rem; }

  .form-group { margin-bottom: 1.25rem; }
  .form-group label { display: block; font-size: 0.85rem; font-weight: 700; color: #334155; margin-bottom: 0.4rem; }

  .input-wrapper { position: relative; }
  .input-wrapper input {
    width: 100%; padding: 0.85rem 2.75rem 0.85rem 1rem;
    border-radius: 10px; border: 1px solid #cbd5e1;
    font-size: 0.95rem; font-weight: 500; color: #0f172a;
    background: #f8fafc; transition: all 0.2s;
  }
  .input-wrapper input:focus {
    outline: none; background: #fff; border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
  }

  .toggle-password {
    position: absolute; right: 0.85rem; top: 50%; transform: translateY(-50%);
    background: none; border: none; color: #94a3b8; cursor: pointer; padding: 0.25rem;
    font-size: 1rem; transition: color 0.2s;
  }
  .toggle-password:hover { color: #475569; }

  .btn-submit {
    width: 100%; background: #0f172a; color: #fff; border: none;
    border-radius: 10px; padding: 0.9rem; font-weight: 700; font-size: 1rem;
    transition: all 0.2s; display: flex; justify-content: center; align-items: center; gap: 0.5rem;
  }
  .btn-submit:hover:not(:disabled) { background: #1e293b; transform: translateY(-1px); box-shadow: 0 6px 15px rgba(15, 23, 42, 0.2); }
  .btn-submit:disabled { background: #cbd5e1; cursor: not-allowed; }

  .alert-custom {
    border-radius: 10px; padding: 0.85rem 1rem; font-size: 0.85rem; font-weight: 500;
    margin-bottom: 1.5rem; display: flex; align-items: flex-start; gap: 0.5rem; line-height: 1.5;
  }
  .alert-custom.danger { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }
  .alert-custom.success { background: #f0fdf4; color: #166534; border: 1px solid #bbf7d0; }

  .footer-text { text-align: center; font-size: 0.9rem; color: #64748b; margin-top: 2rem; }
  .footer-text a { font-weight: 700; color: #2563eb; text-decoration: none; }
  .footer-text a:hover { text-decoration: underline; }

  .back-link {
    display: block; text-align: center; font-size: 0.85rem; color: #94a3b8;
    text-decoration: none; margin-top: 1.5rem; transition: color 0.2s;
  }
  .back-link:hover { color: #0f172a; }

  /* Password Requirement Styles */
  .requirements {
    list-style: none; padding: 0; margin: 0.75rem 0 0 0;
  }
  .requirements li {
    font-size: 0.8rem; font-weight: 500; color: #94a3b8;
    margin-bottom: 0.35rem; display: flex; align-items: center; gap: 0.5rem;
    transition: all 0.2s ease;
  }
  .requirements li i { font-size: 0.85rem; color: #cbd5e1; transition: all 0.2s ease; }
  .requirements li.met { color: #16a34a; }
  .requirements li.met i { color: #16a34a; }

  /* Success Card */
  .success-card {
    text-align: center;
    padding: 1.5rem 0;
  }
  .success-icon {
    width: 72px; height: 72px; border-radius: 50%;
    background: #dcfce7; color: #16a34a;
    display: inline-flex; align-items: center; justify-content: center;
    font-size: 2rem; margin-bottom: 1.5rem;
  }
  .success-card h3 { font-weight: 800; font-size: 1.5rem; color: #0f172a; margin-bottom: 0.5rem; }
  .success-card p { color: #64748b; font-size: 0.95rem; margin-bottom: 2rem; }
  
  .btn-primary-custom {
    display: block; width: 100%; background: #2563eb; color: #fff;
    text-decoration: none; font-weight: 700; padding: 0.9rem; border-radius: 10px;
    transition: all 0.2s;
  }
  .btn-primary-custom:hover { background: #1d4ed8; color: #fff; transform: translateY(-1px); }
</style>
</head>
<body>

<div class="login-wrapper">
  <!-- LEFT SIDE -->
  <div class="login-left">
    <div class="brand-content">
      <a href="index.php" class="login-logo-wrap" title="Back to Home">
        <img src="<?= e(APP_URL) ?>/assets/logo/logo.png" alt="<?= e(APP_NAME) ?> Logo" class="login-logo-img">
      </a>
      <h1>Almost there.</h1>
      <p>Choose a strong, unique password to secure your My Duka account. You'll be back to running your shop in no time.</p>
    </div>
    <div style="position: relative; z-index: 2;">
      <p class="small mb-0" style="opacity: 0.6;">&copy; <?= date('Y') ?> <?= e(APP_NAME) ?>. All rights reserved.</p>
    </div>
  </div>

  <!-- RIGHT SIDE -->
  <div class="login-right">
    <div class="form-wrapper">
      
      <?php if ($success): ?>
        <!-- Success State -->
        <div class="success-card">
          <div class="success-icon"><i class="fa-solid fa-check"></i></div>
          <h3>Password Updated!</h3>
          <p>Your password has been successfully changed.<br>You can now log in with your new credentials.</p>
          <a href="login.php" class="btn-primary-custom">
            Go to Login <i class="fa-solid fa-arrow-right ms-1"></i>
          </a>
        </div>

      <?php else: ?>
        <!-- Form State -->
        <div class="form-icon-wrap"><i class="fa-solid fa-lock"></i></div>
        <div class="form-header">
          <h3>Create New Password</h3>
          <p>Choose a strong password to secure your account.</p>
        </div>

        <?php if ($error): ?>
          <div class="alert-custom danger">
            <i class="fa-solid fa-circle-exclamation mt-1"></i> <div><?= e($error) ?></div>
          </div>
        <?php endif; ?>

        <?php if ($user): ?>
          <form method="post" id="resetForm">
            <?= csrf_field() ?>
            
            <div class="form-group">
              <label>New Password</label>
              <div class="input-wrapper">
                <input type="password" name="password" id="password" class="form-control" required minlength="<?= PASSWORD_MIN_LEN ?>">
                <button type="button" class="toggle-password" data-target="password"><i class="fa-regular fa-eye"></i></button>
              </div>
              
              <ul class="requirements" id="reqList">
                <li id="req-length"><i class="fa-solid fa-circle"></i> At least <?= PASSWORD_MIN_LEN ?> characters</li>
                <li id="req-upper"><i class="fa-solid fa-circle"></i> Contains uppercase & lowercase letters</li>
                <li id="req-number"><i class="fa-solid fa-circle"></i> Contains at least one number</li>
                <li id="req-match"><i class="fa-solid fa-circle"></i> Passwords match</li>
              </ul>
            </div>
            
            <div class="form-group">
              <label>Confirm New Password</label>
              <div class="input-wrapper">
                <input type="password" name="password_confirm" id="password_confirm" class="form-control" required>
                <button type="button" class="toggle-password" data-target="password_confirm"><i class="fa-regular fa-eye"></i></button>
              </div>
            </div>
            
            <button type="submit" class="btn-submit" id="submitBtn" disabled>
              Update Password <i class="fa-solid fa-check ms-1"></i>
            </button>
          </form>
        <?php endif; ?>

        <a href="login.php" class="back-link">
          <i class="fa-solid fa-arrow-left me-1" style="font-size: 0.75rem;"></i> Back to Login
        </a>
      <?php endif; ?>

    </div>
  </div>
</div>

<script>
  // Toggle Password Visibility
  document.querySelectorAll('.toggle-password').forEach(btn => {
    btn.addEventListener('click', function() {
      const input = document.getElementById(this.dataset.target);
      const icon = this.querySelector('i');
      if (input.type === 'password') {
        input.type = 'text';
        icon.classList.replace('fa-eye', 'fa-eye-slash');
        this.style.color = '#2563eb';
      } else {
        input.type = 'password';
        icon.classList.replace('fa-eye-slash', 'fa-eye');
        this.style.color = '#94a3b8';
      }
    });
  });

  // Live Validation
  const newPass = document.getElementById('password');
  if (newPass) {
    const confirmPass = document.getElementById('password_confirm');
    const submitBtn = document.getElementById('submitBtn');
    
    const reqLength = document.getElementById('req-length');
    const reqUpper = document.getElementById('req-upper');
    const reqNumber = document.getElementById('req-number');
    const reqMatch = document.getElementById('req-match');

    function validate() {
      const val = newPass.value;
      const confirmVal = confirmPass.value;
      
      const isLength = val.length >= <?= PASSWORD_MIN_LEN ?>;
      const isUpper = /[A-Z]/.test(val) && /[a-z]/.test(val);
      const isNumber = /[0-9]/.test(val);
      const isMatch = val.length > 0 && val === confirmVal;

      reqLength.classList.toggle('met', isLength);
      reqUpper.classList.toggle('met', isUpper);
      reqNumber.classList.toggle('met', isNumber);
      reqMatch.classList.toggle('met', isMatch);

      [reqLength, reqUpper, reqNumber, reqMatch].forEach(li => {
        const icon = li.querySelector('i');
        if (li.classList.contains('met')) icon.classList.replace('fa-circle', 'fa-circle-check');
        else icon.classList.replace('fa-circle-check', 'fa-circle');
      });

      submitBtn.disabled = !(isLength && isUpper && isNumber && isMatch);
    }

    newPass.addEventListener('input', validate);
    confirmPass.addEventListener('input', validate);
  }
</script>
</body>
</html>