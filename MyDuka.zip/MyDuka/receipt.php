<?php
// receipt.php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/uploads.php';
require_login();

$pdo = db();
$user = current_user();
$saleId = (int)get('id', '0');
if ($saleId <= 0) { http_response_code(404); exit('Receipt not found.'); }

$stmt = $pdo->prepare(
    "SELECT s.*, b.name AS branch_name, b.address AS branch_address, b.phone AS branch_phone,
            bu.name AS business_name, bu.phone AS business_phone, bu.address AS business_address,
            bu.logo_path, bu.currency, u.full_name AS attendant
     FROM sales s
     JOIN branches b ON b.id = s.branch_id
     JOIN businesses bu ON bu.id = s.business_id
     JOIN users u ON u.id = s.user_id
     WHERE s.id = ? LIMIT 1"
);
$stmt->execute([$saleId]);
$sale = $stmt->fetch();
if (!$sale) { http_response_code(404); exit('Receipt not found.'); }

// Access check
$role = $user['role_name'];
$allowed = false;
if ($role === 'admin') {
    $allowed = true;
} elseif ($role === 'owner') {
    $allowed = ((int)$user['business_id'] === (int)$sale['business_id']);
} elseif ($role === 'employee') {
    $allowed = ((int)$sale['user_id'] === (int)$user['id']) || has_permission('sale.view');
}
if (!$allowed) { http_response_code(403); exit('Access denied.'); }

$items = $pdo->prepare("SELECT * FROM sale_items WHERE sale_id = ? ORDER BY id");
$items->execute([$saleId]);
$items = $items->fetchAll();

$payments = $pdo->prepare("SELECT * FROM sale_payments WHERE sale_id = ?");
$payments->execute([$saleId]);
$payments = $payments->fetchAll();

// Determine which logo to show (business logo, or fallback to app logo)
$logoSrc = APP_URL . '/assets/logo/logo.png'; // Fallback default
if (!empty($sale['logo_path'])) {
    $uploadedUrl = upload_url($sale['logo_path']);
    if ($uploadedUrl) {
        $logoSrc = $uploadedUrl;
    }
}

$print = isset($_GET['print']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Receipt <?= e($sale['sale_number']) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap');

  body { 
    background: #f4f6fb; 
    font-family: 'Outfit', sans-serif;
    color: #1e293b;
  }
  
  .receipt {
    max-width: 400px; 
    margin: 2rem auto; 
    background: #fff;
    padding: 2rem 1.75rem; 
    border-radius: 16px;
    box-shadow: 0 10px 40px -10px rgba(15,30,61,.15);
    position: relative;
  }

  /* Logo Header */
  .receipt-header {
    text-align: center;
    margin-bottom: 1.5rem;
  }
  
  .receipt-logo {
    max-height: 60px;
    max-width: 200px;
    object-fit: contain;
    margin-bottom: 0.75rem;
  }

  .receipt h1 { 
    font-size: 1.25rem; 
    font-weight: 800; 
    margin: 0 0 0.25rem 0;
    color: #0f172a;
  }
  
  .receipt .sub { 
    font-size: 0.8rem; 
    color: #64748b; 
    line-height: 1.4;
  }

  /* Meta Grid */
  .meta-grid {
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.75rem;
    margin-bottom: 1.25rem;
  }
  .meta-row {
    display: flex;
    justify-content: space-between;
    padding: 0.15rem 0;
  }
  .meta-label { color: #64748b; }
  .meta-value { font-weight: 500; color: #0f172a; }

  /* Dotted Divider */
  .receipt-divider {
    border-top: 2px dashed #e2e8f0;
    margin: 1rem 0;
  }

  /* Item Table */
  .items-table {
    width: 100%;
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.75rem;
    border-collapse: collapse;
  }
  
  .items-table th {
    text-align: left;
    font-weight: 700;
    color: #94a3b8;
    text-transform: uppercase;
    font-size: 0.65rem;
    letter-spacing: 0.05em;
    padding-bottom: 0.5rem;
    border-bottom: 1px solid #e2e8f0;
  }
  
  .items-table td {
    padding: 0.4rem 0;
    vertical-align: top;
  }
  
  .item-name {
    font-weight: 500;
    color: #0f172a;
    line-height: 1.2;
    padding-bottom: 0.15rem !important;
  }
  
  .item-qty-price {
    color: #64748b;
    font-size: 0.7rem;
    padding-top: 0 !important;
  }
  
  .item-total {
    text-align: right;
    font-weight: 500;
  }

  /* Totals Section */
  .totals-table {
    width: 100%;
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.8rem;
  }
  
  .totals-table td { padding: 0.25rem 0; }
  .totals-table .label { color: #64748b; }
  .totals-table .value { text-align: right; font-weight: 500; }
  
  .grand-total {
    border-top: 2px solid #0f172a;
    border-bottom: 2px solid #0f172a;
    margin: 0.75rem 0;
    padding: 0.5rem 0;
  }
  
  .grand-total td {
    font-size: 1.1rem;
    font-weight: 800;
    color: #0f172a;
  }

  /* Footer */
  .receipt-footer {
    text-align: center;
    margin-top: 1.5rem;
    font-size: 0.8rem;
    color: #64748b;
    font-weight: 500;
  }

  /* Print settings */
  @media print {
    body { background: #fff; }
    .receipt { 
      box-shadow: none; 
      margin: 0 auto; 
      border-radius: 0; 
      padding: 1rem;
      max-width: 100%;
    }
    .no-print { display: none !important; }
  }
</style>
</head>
<body>

<div class="receipt">
  
  <!-- HEADER -->
  <div class="receipt-header">
    <img src="<?= e($logoSrc) ?>" alt="Logo" class="receipt-logo">
    <h1><?= e($sale['business_name']) ?></h1>
    <div class="sub">
      <?= e($sale['branch_name']) ?><br>
      <?= e($sale['branch_address'] ?: $sale['business_address']) ?><br>
      <?= e($sale['branch_phone'] ?: $sale['business_phone']) ?>
    </div>
  </div>

  <div class="receipt-divider"></div>

  <!-- META -->
  <div class="meta-grid">
    <div class="meta-row">
      <span class="meta-label">Receipt #</span>
      <span class="meta-value"><?= e($sale['sale_number']) ?></span>
    </div>
    <div class="meta-row">
      <span class="meta-label">Date</span>
      <span class="meta-value"><?= date('d M Y, H:i', strtotime($sale['sale_date'])) ?></span>
    </div>
    <div class="meta-row">
      <span class="meta-label">Cashier</span>
      <span class="meta-value"><?= e($sale['attendant']) ?></span>
    </div>
  </div>

  <div class="receipt-divider"></div>

  <!-- ITEMS -->
  <table class="items-table">
    <thead>
      <tr>
        <th>Item</th>
        <th class="text-end">Amount</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($items as $it): ?>
        <tr>
          <td colspan="2" class="item-name"><?= e($it['product_name']) ?></td>
        </tr>
        <tr>
          <td class="item-qty-price">
            <?= num((float)$it['quantity'], 2) ?> × <?= number_format((float)$it['unit_price'], 0) ?>
          </td>
          <td class="item-total"><?= number_format((float)$it['line_total'], 0) ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <div class="receipt-divider"></div>

  <!-- TOTALS -->
  <table class="totals-table">
    <tr>
      <td class="label">Subtotal</td>
      <td class="value"><?= number_format((float)$sale['subtotal'], 0) ?></td>
    </tr>
    <?php if ((float)$sale['discount'] > 0): ?>
      <tr>
        <td class="label">Discount</td>
        <td class="value text-success">−<?= number_format((float)$sale['discount'], 0) ?></td>
      </tr>
    <?php endif; ?>
    <?php if ((float)$sale['tax'] > 0): ?>
      <tr>
        <td class="label">Tax</td>
        <td class="value"><?= number_format((float)$sale['tax'], 0) ?></td>
      </tr>
    <?php endif; ?>
  </table>

  <table class="totals-table grand-total">
    <tr>
      <td>Total</td>
      <td class="value"><?= e($sale['currency']) ?> <?= number_format((float)$sale['total_amount'], 0) ?></td>
    </tr>
  </table>

  <table class="totals-table">
    <?php foreach ($payments as $p): ?>
      <tr>
        <td class="label">Paid (<?= e(str_replace('_', ' ', $p['method'])) ?>)</td>
        <td class="value"><?= number_format((float)$p['amount'], 0) ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if ((float)$sale['total_amount'] > (float)$sale['paid_amount']): ?>
      <tr>
        <td class="label text-danger fw-bold">Balance Due</td>
        <td class="value text-danger fw-bold"><?= number_format((float)$sale['total_amount'] - (float)$sale['paid_amount'], 0) ?></td>
      </tr>
    <?php endif; ?>
  </table>

  <div class="receipt-divider"></div>
  
  <div class="receipt-footer">
    <p class="mb-1">Thank you for shopping with us!</p>
    <p class="mb-0" style="font-size: 0.7rem; opacity: 0.7;">Powered by <?= e(APP_NAME) ?></p>
  </div>
</div>

<div class="text-center no-print mb-5">
  <button class="btn btn-dark fw-bold px-4 py-2" onclick="window.print()" style="border-radius: 8px;">
    <i class="fa-solid fa-print me-2"></i>Print Receipt
  </button>
  <a class="btn btn-light border fw-bold px-4 py-2" href="<?= e(APP_URL) ?>/employee/pos.php" style="border-radius: 8px;">
    Back to POS
  </a>
</div>

<?php if ($print): ?>
<script>window.addEventListener('load', () => window.print());</script>
<?php endif; ?>
</body>
</html>